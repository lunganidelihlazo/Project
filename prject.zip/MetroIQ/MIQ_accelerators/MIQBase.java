package MIQ_accelerators;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;


public class MIQBase {
	public static WebDriver driver;
	
	public static boolean bResult;
	public static String sBrowserName;
	public static String sBrowserVersion;

	//public static String sReportPath;

	/*public  Base(WebDriver driver){
		Base.driver = driver;
		Base.bResult = true;
	}
	 */
	//	static {
	//		OpenBrowser();        
	//	}
	//	
	//@Before
	//@SuppressWarnings("deprecation")
	public static WebDriver OpenBrowser() {
	     sBrowserName= 		MIQUtils.getProperty("browserName");
	      //  System.out.println(sBrowserName);
	        System.out.println("BrowserType: "+sBrowserName);
	    //    sBrowserName="Chrome";
//	        sBrowserName="Firefox";
		try {
			if(sBrowserName.equalsIgnoreCase("Chrome")) {
				ChromeOptions options = new ChromeOptions();
				Map<String, Object> prefs = new HashMap<String, Object>();
				prefs.put("download.default_directory",  System.getProperty("user.dir")+"//Downloads");
//				options.setExperimentalOption("prefs", prefs);
//				options.addArguments("--use-fake-ui-for-media-stream");
//				options.addArguments("--disable-user-media-security");	
//				options.addArguments("--use-fake-device-for-media-stream");
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				sBrowserVersion=capabilities.getVersion();
				options.addArguments("--incognito");
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		        capabilities.setCapability (CapabilityType.ACCEPT_INSECURE_CERTS, true);
				sBrowserVersion=(String) capabilities.getCapability("version");
				System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe"); 
				driver = new ChromeDriver(capabilities);
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
				driver.manage().deleteAllCookies();
				//driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				MIQLog.info("Chrome driver initialized");
				  
			}
			else if(sBrowserName.equalsIgnoreCase("Firefox")) {             
				System.setProperty("webdriver.gecko.driver", "Drivers/geckodriver.exe");
//				ProfilesIni prof = new ProfilesIni();				
//				FirefoxProfile ffProfile= prof.getProfile ("myProfile");
//				ffProfile.setAcceptUntrustedCertificates(true) ;
//				ffProfile.setAssumeUntrustedCertificateIssuer(false);
//				driver = new FirefoxDriver((Capabilities) ffProfile);
				driver = new FirefoxDriver();
				driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
				driver.manage().window().maximize();
//				sBrowserVersion=cap.getVersion();
				MIQLog.info("Firefox driver initialized");
			}
			else if(sBrowserName.equalsIgnoreCase("Edge")) {             
				System.setProperty("webdriver.edge.driver", "Drivers/MicrosoftWebDriver.exe");
				driver = new EdgeDriver();
				driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				MIQLog.info("Edge driver initialized");
			}
			else if (sBrowserName.equalsIgnoreCase("IE")) {

				System.setProperty("webdriver.ie.driver", "Drivers/IEDriverServer.exe");
				// Initialize InternetExplorerDriver Instance.
				driver = new InternetExplorerDriver();

				driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				MIQLog.info("IE Explorer  driver initialized");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return driver;
	}

	//	 private static final Thread CLOSE_THREAD = new Thread() {
	//	        @Override
	//	        public void run() {
	//	            driver.quit();
	//	        }
	//	    };

	/*private static WebDriver instantiateDriver() {

	      //numFork will be passed in the maven command line or eclipse 
	      //--- clean install -DnumFork=${surefire.forkNumber}
	      int browserType = Integer.parseInt(Utils.getProperty("numFork"));

	      System.out.println("BROWSER TYPE "+browserType);

	      if(browserType == 1)
	    	  driver= instantiateChromeDriver();

	      else if (browserType == 2)
	    	  driver= instantiateFirefoxDriver();

	      else if (browserType == 3) {    
	    	  driver= instantiateIEDriver();
	      }       
	      return driver;
	  }

	  private static WebDriver instantiateIEDriver() {
		  driver = new FirefoxDriver();
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			Log.info("Firefox driver initialized"); 
			 return driver;
	  }

	  private static WebDriver instantiateFirefoxDriver() {
			System.setProperty("webdriver.gecko.driver", "Drivers/geckodriver.exe");

		  driver = new FirefoxDriver();
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			Log.info("Firefox driver initialized"); 
			 return driver;
	  }

	  private static WebDriver instantiateChromeDriver() {

		  System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			Log.info("Chrome driver initialized");
			 return driver;
	  }
	 */

}
