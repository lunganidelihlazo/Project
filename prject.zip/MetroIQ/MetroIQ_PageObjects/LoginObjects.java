package MetroIQ_PageObjects;
import org.openqa.selenium.By;
public class LoginObjects {

	
	public static final By email = By.id("Email");
	public static final By password = By.id("Password");
	public static final By login_submit = By.name("btnLogin");
	public static final By login_error = By.id("errorMsg");
	public static final By login_UserName_TxtField = By.id("Email");
	public static final By login_Password_TxtField = By.id("Password");
	public static final By login_ForgotPassword_Link= By.xpath("//a[text()='Forgot Password?']");
	public static final By ContactUs_Link= By.xpath("//a[contains(text(),'Contact Us')]");
	public static final By contactUs_Send_Button = By.id("sendContactUs");
	public static final By contactUs_Popup_Dialog = By.id("dialogMessage");
	public static final By contactUs_Popup_Dialog_OK_Button = By.xpath("//button[text()='Ok']");
	public static final By contactUs_Name_TxtField = By.id("ContactName");
	public static final By contactUs_Email_TxtField = By.id("ContactEmailAddress");
	public static final By contactUs_ContactNumber_TxtField = By.id("ContactNumber");
	public static final By contactUs_Comments_TxtField = By.id("Comments");
	public static final By contactUs_Reset_Link = By.id("resetContactUs");
	
	
	//a[contains(text(),"Contact Us")]
	
	//Forgot Password Page
	public static final By forgotPassword_Email_TxtField = By.id("txtEmail");
	public static final By forgotPassword_Page = By.xpath("//div[@class='right_changepassword']");
	public static final By forgotPassword_Notificatin_Message = By.id("successMsg");
	public static final By forgotPassword_RequstLink_Button= By.xpath("//input[@type='submit']");
	
	public static final By login_UserProfile = By.xpath("//div[text()='Profile']");
	public static final By mapView = By.id("concreteMap");
	
	//Webmail
	public static final By webmail_UserTxtBox = By.id("user");
	public static final By webmail_PasswordTxtBox = By.id("pass");
	public static final By webmail_loginBtn = By.name("login");
	public static final By webmail_RegistrationEmail=By.xpath("(//span[text()='Get started with Lexis®Sign']/parent::a/ancestor::td[@class='subject'])[1]");
	public static final By webmail_ResetPasswordEmail=By.xpath("(//span[text()='MetroIQ - Update password']/parent::a/ancestor::td[@class='subject'])[1]");
	public static final By webmail_EmailFrame = By.className("mail_client_roundcube");
	public static final By webmail_PasswordLink = By.xpath("//a[text()='Please click here']");
	public static final By webmail_GotItButton=By.id("btnNavbarOverlayConfirm");
	public static final By webmail_RoundCubeSetasDefault=By.id("lnkroundcubeSetDefault");
	public static final By webmail_RoundCubeBlock=By.xpath("//div[@id='roundcube']//div[@class='mail-client-preview']");
	public static final By webmail_UserNotFound=By.xpath("(//span[text()='User not found']/parent::a/ancestor::td[@class='subject'])[1]");
	public static final By webmail_PasswordReset_Link=By.xpath("//a[contains(@href,'https://metroiq.calivetest01.korbitec.int/Account/SetNewPassword')]");
	public static final By webmail_Search_TextField=By.id("quicksearchbox");
	
	
	//Password Reset Page
	public static final By resetPassword_NewPassword_TxtField = By.id("txtNewPassword");
	public static final By resetPassword_ConfirmPassword_TxtField = By.id("txtConfirmPassword");
	//footer
	public static final By login_Footer_LexisLogo_Link = By.xpath("//img[@class='lexisnexis_logo']");
	public static final By login_Footer_RelxLogo_Link = By.xpath("//img[@class='relx_logo']");
	
	public static final String login_Footer_Headers_Value1= "//h4[text()='";
	
	public static final String login_Footer_Headers_Value2= "']";
	public static final By login_Footer_AboutMetroIQ_Link = By.xpath("//a[text()='About Lexis MetroIQ']");
	public static final By login_Footer_PrivacyPolicy_Link = By.xpath("//a[text()='Privacy Policy']");
	public static final By login_Footer_TermsAndConditions_Link = By.xpath("//a[text()='Terms and Conditions']");
	public static final By login_Footer_DocumentPdF_Link = By.xpath("//a[contains(text(),'download PDF')]");
	
	
	//PropertySearch
	public static final By propertySearch_Icon = By.xpath("//a[text()='Property Search']");
	public static final By propertySearch_StreetName_Dropdown = By.id("StreetInformationInput_StreetName");
	public static final By propertySearch_Type_Dropdown = By.id("StreetInformationInput_StreetType");
	public static final By propertySearch_Suburb_TextFiled = By.id("StreetInformationInput_Suburb");
	public static final By propertySearch_StreetName_TextFiled = By.id("StreetInformationInput_StreetNumber");
	
	public static final By propertyDescritionType = By.xpath("//select[@id='PropertyType']");
	public static final By propertyDescriptionDeedsOffice = By.xpath("//select[@id='OfficialDescriptionInput_DeedsOffice']");
	public static final By propertyDescriptionTownship = By.xpath("//input[@id='OfficialDescriptionInput_AreaName']");
	public static final By propertyDescriptionErfNumber = By.xpath("//input[@id='OfficialDescriptionInput_AreaNumber']");
	public static final By propertyDescriptionResetButton = By.xpath("//input[@value='Reset fields']");
	public static final By propertyDescritionTypeDefaultValue = By.xpath("//select[@id='PropertyType']//following-sibling::option[contains(text(),'All')]");
	public static final By propertyDescriptionDeedsOfficeDefaultValue = By.xpath("//select[@id='OfficialDescriptionInput_DeedsOffice']//following-sibling::option[contains(text(),'All')]");

	public static final By propertySearch_PropertyType_Dropdown = By.id("PropertyType");
	public static final By propertySearch_HoldingArea= By.name("OfficialDescriptionInput.AreaName");
	
	public static final String propertySearch_HoldingArea_AutoComplete= "//ul/li/div[contains(text(),'";
	
	public static final By propertySearch_DeedsOffice_Dropdown = By.id("OfficialDescriptionInput_DeedsOffice");
	public static final By propertySearch_Township= By.name("OfficialDescriptionInput.AreaName");
	public static final By propertySearch_Next_Button= By.xpath("//input[@type='submit' and @value = 'Next']");
	public static final By propertySearch_ReturnToSearch_Button= By.xpath("//a[text()='Return to Search ']");
	public static final By propertySearch_Result_Grid= By.xpath("//div[@class='ui-jqgrid ui-widget ui-widget-content ui-corner-all']");
	public static final By propertySearch_PropertyDescrtipionGrid_TextField = By.id("gs_PropertyDescriptionString");
	public static final By propertySearch_PropertyDescrtipionGrid_Sortable = By.id("jqgh_AdvancedListResultTable_PropertyDescriptionString");
	public static final By propertySearch_FarmName= By.name("OfficialDescriptionInput.FarmName");
	public static final By propertyDescriptionRegistrationDivision = By.id("OfficialDescriptionInput_AreaName");
	public static final By propertyDescriptionFarmNumber = By.id("OfficialDescriptionInput_AreaNumber");
	
	public static final By label_propetry_Description_Farm_Name = By.xpath("//div[@class='column']/label[@id='FarmNameLabel']");
	public static final By label_propetry_Description_Holding_Area = By.xpath("//div[@class='column']/label[@id='AreaNameLabel']");
	public static final By label_property_Description_Holding_Number = By.xpath("//div[@class='column']/label[@id='AreaNumberLabel']");
	public static final By label_property_Description_Portion_Number = By.xpath("//div[@class='column']/label[@id='AreaPortionNumberLabel']");
	public static final By propertySearch_PropertyDescrtipionGrid_ResultsTable = By.id("AdvancedListResultTable");
	public static final By propertySearch_PropertyDescrtipionGrid_EastPanel = By.id("tabContainer");
	public static final By propertySearch_EastPanel_PropertyInformation = By.xpath("//li[@title='Property Information']");
	public static final By propertySearch_EastPanel_ReportsGenerated = By.xpath("//li[@title='Reports Generated']");
	public static final By propertySearch_PropertyDescrtipionGrid_PersonalNotes = By.xpath("//li[@title='Personal Notes']");
	public static final By propertySearch_PropertyReport_Email_button = By.xpath("//input[@value='Email']");
	public static final By generateReport = By.xpath("//input[@value='Generate Report']");
	public static final By propertySearch_ReportGeneration_Label = By.xpath("(//div[@id='reportHistorySummary']//span)[1]");
	public static final By propertySearch_ReportGeneration_PropertyReport_Message = By.xpath("//div[@id='reportsContainer']//div//p");
	public static final By propertySearch_ReportGeneration_ReportHistory_Link = By.xpath("//a[text()='Report history']");
	
	
	public static final By propertySearch_PropertyReport_EastPanel = By.id("emailReportContent");
	public static final By propertySearch_PropertyReport_EastPanel_Email_TextBox = By.id("email_textbox");
	public static final By propertySearch_PropertyReport_EastPanel_Plus_Button = By.id("addEmailBtn");
	public static final By propertySearch_PropertyReport_EastPanel_Save_Button = By.name("btnSendEmail");
	
	public static final By pdfVersion = By.xpath("//input[@value='PDF VERSION']");
	public static final By Email = By.xpath("//input[@value='Email']");
	public static final By PdfReport_propertyName = By.xpath("//div[@class='report_expert_erf_line']/div");
	public static final By PdfReport_Address = By.xpath("//div[@class='report_expert_address_line']/div");
	public static final By properReportTitle = By.id("pageTitle");
    public static final By propertyInformationName = By.id("PropertyDescription");
    public static final By propertyDescriptionName = By.xpath("//div[@class='report_expert_erf_line']");
    
    public static final By propertySearch_PropertyInformation_QuestionMark_Label = By.xpath("//div[@id='PopupHeader']//div[@class='helpSliderIcon right_adjust']");
    
    
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_PropertyInformation_Label =  By.xpath("//div[@id='actionLinkConfirmationDialogText']//span");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_Available_Label =  By.xpath("(//div[@id='actionLinkConfirmationDialogText']//p)[1]");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_ThisIncludes_Label =  By.xpath("(//div[@id='actionLinkConfirmationDialogText']//p)[2]");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_StreetAddress_Label =  By.xpath("(//div[@id='actionLinkConfirmationDialogText']//ul//li)[1]");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_OfficialDescription_Label =  By.xpath("(//div[@id='actionLinkConfirmationDialogText']//ul//li)[2]");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_Owners_Label =  By.xpath("(//div[@id='actionLinkConfirmationDialogText']//ul//li)[3]");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_RegistrationDetails_Label =  By.xpath("(//div[@id='actionLinkConfirmationDialogText']//ul//li)[4]");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_AreaOfInterest_Label =  By.xpath("(//div[@id='actionLinkConfirmationDialogText']//p)[3]");
    public static final By propertyInformationEastPanel_QuestionMark_Dialog_Cancel_Button = By.id("actionLinkBtnCancel");
    public static final By propertyInformationEastPanel_QuestionMark_DialogBox = By.id("actionLinkConfirmationDialog");
	
	
	//Admin
		public static final By admin_Icon = By.xpath("//a[text()='Admin']");
		public static final By admin_ReportBrandingManager_Link = By.xpath("//span[text()='Report Branding Manager']");
		public static final By admin_ReportBrandingManager_ChangeHeader_UploadButton = By.id("headerUploadButton");
		public static final By admin_ReportBrandingManager_ChangeFooter_UploadButton = By.id("footerUploadButton");
		public static final By admin_ReportBrandingManager_ChangeHeader_Discard_Button = By.xpath("//a[@class='uploaderControlBackToPreviewButton button_primary' and @title=' Discard the previewed custom report header.']");
		public static final By admin_ReportBrandingManager_ChangeFooter_Discard_Button = By.xpath("//a[@class='uploaderControlBackToPreviewButton button_primary' and @title=' Discard the previewed custom report footer.']");
		public static final By admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox = By.id("headerDefaultImageCheckBox");
		public static final By admin_ReportBrandingManager_ChangeFooter_SetFooterSubscriptionDefault_CheckBox = By.id("footerDefaultImageCheckBox");
		public static final By admin_ReportBrandingManager_ChangeHeader_SaveHeader_Button = By.xpath("//a[text()='Save header']");
		public static final By admin_ReportBrandingManager_ChangeHeader_SaveFooter_Button = By.xpath("//a[text()='Save footer']");
		
		public static final By admin_ReportBrandingManager_NotificationMessage = By.xpath("//div[@class='notificationBanner successBanner']//p");
		public static final By admin_ReportBrandingManager_ChangeHeader_ResetHeader_link = By.xpath("//div[@class='resetDiv alternative_btn']//p//a[contains(text(),'to subscription default')]");
		public static final By admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog = By.id("actionLinkConfirmationDialog");
		public static final By admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Cancel_Button = By.id("actionLinkBtnCancel");
		public static final By admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Confirm_Button = By.id("actionLinkConfirmationBtnConfirm");


		// Area Of interest
				public static final By AOI_NoMunicipalAOIDialog = By.id("noMunicipalAOIDialog");
				public static final By AOI_SetMunicipalAoi_Button = By.id("btnSetMunicipalAoi");
				public static final String AOI_DisabledMenu = "//li[@class='disabled-li']/a[contains(text(),'";
				public static final String AOI_EnabledMenu = "//li/a[contains(text(),'";
				
				
				

				public static final By propertySearch_PropertyDescrtipionGrid_ReportsTab = By.xpath("//li[@title='Reports Generated']");
				public static final By personalNotesSave = By.id("btnSaveChanges");
				   public static final By personalNotesTextbox = By.id("Notes");
				   public static final By personalNotesSaveNotification = By.id("eastPanelNotesBanner");
				   public static final By personalNotes_SaveNotification_Message = By.xpath("//div[@id='eastPanelNotesBanner']/p");
				   
		//Transfer report	   
				   public static final By transferReprot_Icon = By.xpath("//a[text()='Transfer Report']");
				   public static final By transferReprot_Page_Title=By.id("pageTitle");
				   public static final By transferReprot_GenerateReport_Button=By.id("submitbtn");
				   public static final By transferReprot_GenerateReport_Error_Message=By.id("reportError");
				   public static final By transferReprot_SpecifiedDateRange_Checkbox=By.xpath("//input[@name='SelectableDateRange']//following-sibling::label[@for='custom']");
				   public static final By transferReprot_FileTransfer_Dropdown=By.id("DateFilter");
				   public static final By transferReprot_SpecifiedDateRange_From_DatePicker=By.id("fromDatePicker");
				   public static final By transferReprot_SpecifiedDateRange_To_DatePicker=By.id("toDatePicker");
				  // public static final By transferReprot_SpecifiedDateRange_DatePicker_Month=By.className("ui-datepicker-month");
				   
				   public static final By transferReprot_SpecifiedDateRange_DatePicker_Month=By.xpath("//div[@id='ui-datepicker-div']//div[@class='ui-datepicker-title']//select[@class='ui-datepicker-month']");
				  // public static final By transferReprot_SpecifiedDateRange_DatePicker_Year=By.className("ui-datepicker-year");
				   public static final By transferReprot_SpecifiedDateRange_DatePicker_Year=By.xpath("//div[@id='ui-datepicker-div']//div[@class='ui-datepicker-title']//select[@class='ui-datepicker-year']");
				   
				   public static final String transferReprot_PropertyTypes_Label1="//input[@name='PropertyTypes' and @value='";
				   public static final String transferReprot_PropertyTypes_Label2="']//following-sibling::label";
				   public static final By transferReprot_RefineReport_Button=By.id("backBtn");
				   public static final By transferReprot_CurrentReportDescription_TextField=By.id("CurrentReportDescription");
				   public static final By transferReport_CreateCurrentReport_Checkbox = By.xpath("//input[@id='CreateCurrentReport']//following-sibling::label");
				   public static final By transferReport_OfflineProcess_Checkbox = By.xpath("//input[@id='GenerateOffline']//following-sibling::label");
					 
				   public static final By transferReprot_ResetFields_Button=By.id("resetbtn");
				   public static final By transferReprot_ResultsPage=By.id("transfersTableResponse");
				   public static final By transferReprot_ResultsTable_StreetName_SearchField=By.id("gs_Street");
				   public static final By transferReprot_ResultsTable_Suburb_Dropdown=By.id("gs_Suburb");
				   public static final By transferReprot_ResultsTable_PropertyType_Dropdown=By.id("gs_PropertyType");
				   public static final By transferReprot_ResultsTable_OfficilDescription_Dropdown=By.id("gs_OfficialDescription");
				   
				   
				   public static final By transferReport_SummarySection_OfficialDescription_Label=By.id("jqgh_transfersResultTable_OfficialDescription");
				   public static final By transferReport_SummarySection_ErfPortion_Label=By.id("jqgh_transfersResultTable_ErfPortion");
				   public static final By transferReport_SummarySection_Type_Label=By.id("jqgh_transfersResultTable_PropertyType");
				   public static final By transferReport_SummarySection_FarmNameORSchemeYear_Label=By.id("jqgh_transfersResultTable_AdditionalInfo");
				   public static final By transferReport_SummarySection_StreetName_Label=By.id("jqgh_transfersResultTable_Street");
				   public static final By transferReport_SummarySection_StreetAddress_Label=By.id("jqgh_transfersResultTable_StreetAddress");
				   public static final By transferReport_SummarySection_Suburb_Label=By.id("jqgh_transfersResultTable_Suburb");
				   public static final By transferReport_SummarySection_TitleDeed_Label=By.id("jqgh_transfersResultTable_DocumentNumber");
				   public static final By transferReport_SummarySection_ExtentSQM_Label=By.id("jqgh_transfersResultTable_ExtentInSQM");
				   public static final By transferReport_SummarySection_Price_Label=By.id("jqgh_transfersResultTable_Price");
				   public static final By transferReport_SummarySection_PurchaseDate_Label=By.id("jqgh_transfersResultTable_PurchaseDate");
				   public static final By transferReport_SummarySection_RegistrationDate_Label=By.id("jqgh_transfersResultTable_RegistrationDate");
				   public static final By transferReport_SummarySection_TotalNumberofRecords_Label=By.xpath("//td[@id='transfersResultPager_right']//div");
				   public static final By transferReport_SummarySection_Nextpage_Scroll=By.id("next_transfersResultPager");
				   public static final By transferReport_SummarySection_LastPage_Scroll=By.id("last_transfersResultPager");
				   public static final By transferReprot_SummarySection_Export_Dropdown=By.id("reportExportSelection");
				   public static final By transferReprot_SummarySection_Property_CheckBox=By.id("jqg_transfersResultTable_1");
				   public static final By transferReprot_SummarySection_Export_PDF_Button=By.xpath("//span[@class='exportButton']//following-sibling::input[@value='PDF']");
				   public static final By transferReprot_SummarySection_Export_CSV_Button=By.xpath("//span[@class='exportButton']//following-sibling::input[@value='CSV']");
				   public static final By transferReprot_SummarySection_Export_CSV_ErrorMessage=By.xpath("//div[@id='reportErrorBanner' and @style='display: block;']");
				   public static final By transferReprot_SummarySection_Export_CSV_ErrorMessageDisappear=By.xpath("//div[@id='reportErrorBanner' and @style='display: none;']");
				
				   
				   //Report history
				   
				   public static final By reportHistory_FirstReport = By.xpath("(//td[@aria-describedby ='ReportHistoryResultTable_Description'])[1]");
				   
				   //Current Reports Lungani
				   
				
				   //public static final By reportPage_CurrentReports = By.xpath("//a[@href='/Subscriber/ReportHistory']");
				   public static final By reportPage_CurrentReports = By.xpath("//a[@href='/Report']");
				   
				   public static final By transferReport_Description =By.xpath("//div[@id='jqgh_reportsResultTable_Description']");
				   public static final By transferReport_ReportType =By.xpath("//div[@id='jqgh_reportsResultTable_ReportType']");
				   public static final By transferReport_AreaOfInterest =By.xpath("//div[@id='jqgh_reportsResultTable_AreaOfInterest']");
				   public static final By transferReport_LastNotificationDate =By.xpath("jqgh_reportsResultTable_LastNotificationDate");
				   public static final By transferReport_Enabled =By.xpath("//div[@id='jqgh_reportsResultTable_Enabled']");
				   public static final By transferReport_New =By.xpath("//div[@id='jqgh_reportsResultTable_NewRecords']");
				   public static final By transferReport_All =By.xpath("jqgh_reportsResultTable_TotalRecords");
				   public static final By transferReport_Visible =By.xpath("//table[@class='ui-jqgrid-htable']//child::div");
				   public static final By transferReport_VerifyCreated =By.xpath("//td[@aria-describedby='reportsResultTable_Description']");
				   public static final By transferReport_ListGrid = By.xpath("//th[@class='ui-state-default ui-th-column ui-th-ltr textAlignLeft']");
				   public static final By transferReport_Refine_Report = By.xpath("//a[@id='backBtn']");
				   
				   
				   
				   public static final By deleteReport_CurrentReport =By.xpath("//a[@href='/Report']");
				   public static final By deleteReport_CurrentReport_expected =By.xpath("//div[@id='pageTitle']");
				   public static final By deleteReport_CurrentReport_Displayed = By.xpath("//div[@id='pageTitle']");
				   public static final By deletReport_transferReport_Description =By.xpath("//div[@id='jqgh_reportsResultTable_Description']");
				   public static final By deletReport_transferReport_ReportType =By.xpath("//div[@id='jqgh_reportsResultTable_ReportType']");
				   public static final By deletReport_transferReport_AreaOfInterest =By.xpath("//div[@id='jqgh_reportsResultTable_AreaOfInterest']");
				   public static final By deletReport_transferReport_LastNotificationDate =By.xpath("jqgh_reportsResultTable_LastNotificationDate");
				   public static final By deletReport_transferReport_Enabled =By.xpath("//div[@id='jqgh_reportsResultTable_Enabled']");
				   public static final By deletReport_transferReport_New =By.xpath("//div[@id='jqgh_reportsResultTable_NewRecords']");
				   public static final By deletReport_transferReport_All =By.xpath("jqgh_reportsResultTable_TotalRecords");
				   public static final By deletReport_transferReport_Visible =By.xpath("//table[@class='ui-jqgrid-htable']//child::div");
				   public static final By deletReport_transferReport_VerifyCreated =By.xpath("//td[@aria-describedby='reportsResultTable_Description']");
				   //public static final By deleteReport_transferReport_NameHCC = By.xpath("//tr[@id='3']");
				   public static final By deleteReport_transferReport_Disable = By.xpath("//tr[@id='3']//td[@aria-describedby='reportsResultTable_Description']//parent::td");
				   public static final By deleteReport_transferReport_Click = By.xpath("//tr[@id='3']//td[@title='Disable']//a ");
				   public static final By deleteReport_transferReport_PopUp  =By.xpath("//span[@id='ui-id-1']");
				   public static final By deleteReport_transferReport_Validate = By.xpath("//button[contains(text(),'Confirm')] | //button[contains(text(),'Cancel')]");
				   public static final By deleteReport_transferReport_Confirm  = By.xpath("//button[contains(text(),'Confirm')]");
				   public static final By deleteReport_transfer_Notification =By.xpath("//div[@id='generalDialog']//p");
				   public static final By deleteReport_transfer_OK = By.xpath("//button[contains(text(),'Ok')]");
				   public static final By deleteReport_transfer_Deleted = By.xpath("//td[@aria-describedby='reportsResultTable_Description']");
				   
				   public static final By viewNewUpades_transferReport_MapView =By.xpath("//a[@title='Map View']");
				   public static final By viewNewUpades_transferReport_PropertySearch =By.xpath("//a[@title='Property Search']");
				   public static final By viewNewUpades_transferReport_TransferReport = By.xpath("//a[@title='Transfer Report']");
				   public static final By viewNewUpades_transferReport_Notifications = By.xpath("//a[@title='Notifications']");
				   public static final By viewNewUpades_transferReport_PropertyList =By.xpath("//a[@title='Property List']");
				   public static final By viewNewUpades_transferReport_UnlocatedProperty = By.xpath("//a[@title='Unlocated Property List']");
				   public static final By viewNewUpades_transferReport_CurrentReports = By.xpath("//li[@id='EX_currentReports']");
				   public static final By viewNewUpdates_transferReport_Admin  = By.xpath("//a[@title='Admin']");
				   public static final By viewNewUpdates_transferReport_clickCurrent =By.xpath("//a[@title='Current Reports']");
				   public static final By viewNewUpdates_transferReport_veriGet= By.xpath("//div[contains(text(),'Last Notification Date')]");
				   public static final By viewNewUpdates_transferReport_visible= By.xpath("//div[@id='jqgh_reportsResultTable_LastNotificationDate']");
				   public static final By viewAllUpdates_transferReport_click = By.xpath("//tr[@id='2']//td[@aria-describedby='reportsResultTable_TotalRecords']//a");
				   public static final By viewAllUpdates_transferReport_clickPage =By.xpath("//div[@id='analysis']");
				   public static final By viewAllUpdates_transferReport_Reports = By.xpath("//tr[@id='3']");
				   
				   public static final By viewAllUpdates_transferReport_Refine =By.xpath("//a[contains(text(),'Refine Report')] ");
     			   public static final By viewAllUpdates_transferReport_Official = By.xpath("//div[contains(text(),'Official Description')]");
				   public static final By viewAllUpdates_transferReport_ErfPotion = By.xpath("//div[@id='jqgh_transfersResultTable_ErfPortion']");
            	   public static final By viewAllUpdates_transferReport_Type = By.xpath("//div[@id='jqgh_transfersResultTable_PropertyType']");
     			   public static final By viewAllUpdates_transferReport_FarmName = By.xpath("//div[@id='jqgh_transfersResultTable_AdditionalInfo']");
				   public static final By viewAllUpdates_transferReport_Street =By.xpath("//div[@id='jqgh_transfersResultTable_Street']");
				   public static final By viewAllUpdates_transferReport_validateDispla = By.xpath("//tr[@id='1']");
				   
				   public static final By reportPage_Genarate = By.xpath("//input[@id='submitbtn']");
				   public static final By reportPage_Description = By.xpath("//input[@id='CurrentReportDescription']");
				   public static final By transferReport = By.xpath("//a[@href='/Report/TransferReportIndex?refineReport=False']");
				   public static final By transferReport_History_clickOk = By.xpath("//button[contains(text(),'Ok')]");
				   public static final By transferReport_History_ReportsName  = By.xpath("//td[@aria-describedby='ReportHistoryResultTable_Description']");
				   public static final By transferReport_History_Verify  = By.xpath("//div[@id='currentReportCreatedDialog']");
				   public static final By transferReport_History_textArea = By.xpath("//textarea[@id='txtNewCurrentReportName']");
                   public static final By transferReport_History_Confirm = By.xpath("//button[contains(text(),'Confirm')]");
                   public static final By transferReport_History_Notification =By.xpath("//span[contains(text(),'Report creation succeeded')]");
                   
                   public static final By transferReport_History_Page = By.xpath("//a[@title='Report History']");
                   public static final By transferReport_History_Enter = By.xpath("//input[@class='ui-pg-input']");
                   public static final By transferReport_History_navigate = By.xpath("//div[contains(text(),'Report history')]");
                   public static final By transferReport_History_clickLink = By.xpath("//td[@title='Create Current Report']//a");
                   public static final By transferReport_History_PopUp = By.xpath("//span[contains(text(),'Create a new Current Report')]");
}
