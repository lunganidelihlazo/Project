package MetroIQ_PageObjects;

import org.openqa.selenium.By;

public class MIQ_AdminObjects {
	public static final By Admin_Icon = By.xpath("//a[text()='Admin']");
	public static final String ManageOption = "//a[@title='";
	public static final String ManageUser1 = "//td[text()='";
	public static final String ManageUser2 = "']//following-sibling::td[@title='";
	public static final By ConfirmAction = By.xpath("//div/input[@id='confirmAdditionalUserButton']");
	public static final By ConfirmActionMessage = By.xpath("//div[@id='additionalUserConfirmationDialog']//p");
	public static final String disableUser ="']//preceding-sibling::td/div[@title='";
	public static final String adminMenu ="//span[contains(text(),'";
	public static final String adminMenu1 ="//div[contains(text(),'";
	public static final By Admin_EditArea = By.xpath("//a[contains(text(),'Edit Area')]");
	public static final String reportsNumber ="')]//following-sibling::a/span";
	public static final By ReportType = By.name("ReportType");
	public static final By ReportHistory_NoOfReports = By.xpath("//td[@id='ReportHistoryResultPager_right']/div");
	public static final By CurrentReport_NoOfReports = By.xpath("//td[@id='reportsResultTable_toppager_right']/div");
	public static final By CurrentReport_ReortTable_FirstReport = By.xpath("(//td[@aria-describedby='reportsResultTable_Description'])[1]");
	public static final By RoleManager = By.xpath("//div[contains(text(),'ROLE MANAGER')]");
	public static final String RoleManager_Role ="//td[contains(text(),'";
	public static final String RoleManager_Action ="')]//following-sibling::td/input[@value='";
	public static final By Role_textBox = By.xpath("//input[@id='txtRoleName']");
	public static final By Role_textBox_Save = By.xpath("//button[contains(text(),'Save')]");
	public static final String RoleManager_RoleName ="//td[@aria-describedby='userGroupRoleResultTable_RoleName'][contains(text(),'";
	public static final By Role_textBox_Cancel = By.xpath("//button[contains(text(),'Cancel')]");
	public static final By Role_delete_Cancel = By.xpath("//div[@id='divDeleteRole']//following-sibling::div//button[contains(text(),'Cancel')]");
	public static final By Role_delete_Message = By.xpath("//div[@id='divDeleteRole']/p");
	public static final By Role_dailog = By.xpath("//span[@class='ui-dialog-title']");
	public static final By RoleDelete_dailog = By.xpath("//div[@aria-describedby='divDeleteRole']//span[@class='ui-dialog-title']");
	
}
