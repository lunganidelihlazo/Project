package MetroIQ_PageObjects;
import org.openqa.selenium.By;

public class MIQ_AreaOfInterestObjects {
	// Area Of interest
	public static final By setMuncipalArea_Button = By.id("btnSetMunicipalAoi");
	public static final By setMuncipalArea_Disrict_Dropdown = By.id("District");
	public static final By setMuncipalArea_Disrict_AllWards = By.xpath("//div[@class='aoi_callapse_levelone collapse show']");
	public static final By setMuncipalArea_LocalMunicipalities_Radio_Button = By.xpath("//label[@class='radio_container']//input[@id='chkAllowLocalMunicipalities']");
	public static final By AOI_SetMunicipalAoi_Pane = By.xpath("//div/span[contains(text(),'Area of Interest')]");
	public static final By ReviewSelection_Pane = By.xpath("//div/span[contains(text(),'Review Selection')]");     
	public static final By setMuncipalArea_SaveConfirm= By.id("btnToAoiSaveConfirmation");
	public static final By setMuncipalArea_AreaName= By.id("areaName");
	public static final By setMuncipalArea_SaveName= By.id("btnAOIConfirmationSave");
	public static final By selectedAoi= By.name("CurrentlySelectedAoiId");
	public static final By AreaOfInterest_Pane = By.xpath("//div/span[contains(text(),'Areas of Interest')]");
	public static final By AreaOfInterest_SelectedDistrict_Dropdown = By.xpath("//select[@id='areasOfInterest']//option");
	public static final String AreaOfInterest_SelectedDistrict= "//select//option[contains(text(),'";
	public static final By Profiledropdown= By.xpath("//div[contains(text(),'Profile')]//parent::a");
	public static final By MaintainArea=By.xpath("//li/a[contains(text(),'Maintain Areas' )]");
	public static final By DeleteMoi_Button= By.id("btnAOIDelete");
	public static final By DeleteMoi_ConfirmButton= By.id("btnAOIDeleteConfirmation");
	public static final By setMuncipal_EditAreaName= By.id("municipalDivHeading");
	public static final By EditMaoi_Warning=By.xpath("//div[@id='EditWarningUsedReports']//following-sibling::p[contains(text(),'By continuing you acknowledge that the these Current Reports will be ')]");
	public static final By EditMAOI_continue= By.id("btnAOIEditWarningContinue");
	public static final By EditMaoi_Pane=By.xpath("//div[@class='east_heading_basic']//span[contains(text(),'Edit area:')]");
	public static final By SelectMAOI_Button= By.id("btnAOISelect");
	public static final By NewMAOI_Button= By.id("btnAOINew");
	public static final By new_Moi_Button= By.id("btnAOINew");
	public static final By deleteArea_Warning_Message_Label1A = By.xpath("//*[@id=\"aoiEditWarning\"]/div[2]/p[1]");
    public static final By deleteArea_Warning_Message_Label2B = By.xpath("//*[@id=\"aoiEditWarning\"]/div[2]/p[2]");
    
	
	
//	public static final By setMuncipalArea_Wards_Radio_Button= By.id("chkAllowWards");
	public static final String setMuncipalArea_CheckBox_Wards_Value1 = "//label[@class='chkbox_container']//input[@value='";
	public static final String setMuncipalArea_CheckBox_Wards_Value2 = "']//following-sibling::span";
	//public static final By setMuncipalArea_Wards_Radio_Button= By.xpath("//label[@class='radio_container'][2]");
	public static final By setMuncipalArea_Wards_Radio_Button= By.xpath("//label[contains(text(),'Wards')]");
	public static final By setMuncipalArea_ConfirmationCancel_Button= By.id("btnAOIConfirmationCancel");
	public static final By setMuncipalArea_Reset_Button= By.id("btnReset");
	public static final By setMuncipalArea_Cancel_Button= By.id("btnAOICancel");
	public static final By EditMoi_Button= By.id("btnAOIEdit");
	public static final By MAOI_LocalMunicipalities= By.xpath("//div[@class='layer_selection_container']//label[contains(text(),'Local Municipalities')]");
	
	
	
	public static final By ErrorMessage_Unable = By.xpath("//span[text() = 'Unable to perform action']");
	public static final By Back_Button = By.id("btnAoiNoPermissionMessageBack");
	
	public static final By deleteArea_Message_Label = By.xpath("//div[@id='deleteAOIConfirmation']//div[@class='aoi_eastpanel_body_pad']/p");
	public static final By New_Button = By.id("btnAOINew");
    public static final By Edit_Button = By.id("btnAOIEdit");
    public static final By Select_Button = By.id("btnAOISelect");
    public static final By Delete_Button = By.id("btnAOIDelete");
    public static final By deleteArea_Warning_Message_Label1 = By.xpath("//div[@id='aoiDeleteWarning']//div[@class='aoi_eastpanel_body_pad']/p[1]");
    public static final By deleteArea_Warning_Message_Label2 = By.xpath("//div[@id='aoiDeleteWarning']//div[@class='aoi_eastpanel_body_pad']/p[2]");
    
    public static final By menu_Admin = By.xpath("//a[@title='Admin']");
	public static final By menu_ConsolidationReport = By.xpath("//a[@title='Consolidation Report']");
	
	public static final By deleteArea_Label = By.xpath("//div[@id='deleteAOIConfirmation']//span[contains(text(),'Delete Area')]");
	public static final By additionalUser_DeleteArea_Label = By.xpath("//div[@id='aoiDeleteWarning']//span[contains(text(),'Delete Area')]");
	
	public static final By noCurrentReport=By.xpath("//option[text() = 'No Current Report']");
	
	public static final By DeleteArea_Pane = By.xpath("//div/span[contains(text(),'Delete Area')]");
	public static final String setMuncipalArea_CheckBox_LoaclMuncipality_Value1 = "//label[@class='chkbox_container inline']//input[@value='";

	public static final By deselectWard61 = By.xpath("(//span[@class='chkbox_checkmark'])[1]");
	public static final By EditMaoi_PaneWarning=By.xpath("//div[@class='east_heading_basic']//span[contains(text(),'Edit Area')]");
	
	public static final By AreaOfInterest_Review_East_Pane = By.xpath("//div[@id='SaveAOIConfirmation']//span");
	public static final By setMuncipalArea_SaveConfirm2= By.xpath("//button[@id='btnToAoiSaveConfirmation']");
	public static final By setMuncipal_EditAreaName_areasOfInterest= By.xpath("//div[@class='east_heading_basic']//span[text()[contains(.,'Areas of Interest')]]");
	public static final By setMuncipalArea_ConfirmationCancel_Button_AreaOfInterest= By.id("btnAOICancel");
	
	public static final By Selectdropdown= By.xpath("//div[contains(text(),'Select Area')]//parent::a");
	public static final By home_Default_Dropdown= By.xpath("//div[contains(@onclick,'MetroIQ.Client.ClientSettings.setSelectedAreaOfInterest')]");
	public static final By defaultDropdown= By.xpath("//a[text() = 'Default *']");
	
	public static final String defaultDropdown_Value1 = "//div[contains(text(),'";
	public static final String defaultDropdown_Value2 = "')]";
	

}	
	
	