package MetroIQ_PageObjects;
import org.openqa.selenium.By;

public class MIQ_MapViewObjects {
	public static final By pageSearchBar_Input = By.id("startsWith");
	public static final By pageSearchBar_InputButton = By.id("mapSearchButton");
	public static final By eastPaneTitile_PropertyInformation = By.xpath("//div[@class='east_heading_basic']/span");
	public static final By propertyInformation_ViewUnits = By.id("schemeButton");
    public static final By propertyInformation_SchemeButton = By.id("confirmMultiPhaseButton");
    public static final By MapVIew_searchMap = By.id("startsWith");
	public static final By MapVIew_searchButton = By.id("mapSearchButton");
	public static final By MapVIew_GenerateReportButton = By.xpath("//input[@value='Generate Report']");
	public static final By MapVIew_PropertyInformation= By.xpath("//span[contains(text(),'Property information')]");
	public static final By MapVIew_PropertyAddress = By.id("PropertyStreetAddress");
	public static final By MapVIew_PropertyDescription = By.id("PropertyDescription");
	public static final By MapVIew_PropertyDecReport = By.xpath("//div[@class='report_expert_erf_line']/div");
	public static final By MapVIew_PropertyAddressReport = By.xpath("//div[@class='report_expert_address_line']/div");
	public static final By MapVIew_PropertyReport = By.id("pageTitle");
	public static final String zoomIn1 = "//a[@id='";
    public static final String zoomIn2 = "']";
    public static final By mapView_ZoomSlider = By.xpath("//div[@id='zoom-path']//span");
    public static final By mapView_ZoomIn = By.id("zoom-control-plus");
    public static final By mapView_ZoomOut = By.id("zoom-control-minus");
    public static final By mapView_Satellite_Button = By.id("btnSatellite");
    public static final By mapView_Map_Button = By.id("btnStreetMap");
    
	public static final By zoomIn = By.id("zoom-control-plus");
	public static final String errorMessage1 = "//div[contains(text() ,'";
	public static final String errorMessage2 = "')]";
	public static final By errorMessage = By.xpath("//div[contains(text() ,'Unable to find property data at location.')]");
	public static final By errorMessageSea = By.xpath("//div[contains(text() ,'The location you have selected is outside the boundary of South Africa.')]");
	public static final By menuMapView = By.id("EX_mapsearch");
	public static final By mapView_ShowERfNumber_Checkbox = By.xpath("//input[@id='chkErfNumbers']//following-sibling::span[@class='chkbox_checkmark']");
	
	public static final By mapView_PropertyInformation_StreetAddress_Label = By.id("PropertyStreetAddress");
	public static final By mapView_PropertyInformation_PropertyDescription_Label = By.id("PropertyDescription");
	public static final By mapView_PropertyInformation_OwnerName_Label = By.id("OwnerName");
	public static final By mapView_PropertyInformation_RegisteredSize_Label = By.id("PropertySize");
	public static final By mapView_PropertyInformation_RegisteredSalesDate_Label = By.id("SalesDate");
	public static final By mapView_PropertyInformation_RegistrationDate_Label = By.id("RegistrationDate");
	public static final By mapView_PropertyInformation_RegisteredSalesPrice_Label = By.id("SalesPrice");
	public static final By mapView_PropertyInformation_CurrentBond_Label = By.id("BondExists");
	
}
