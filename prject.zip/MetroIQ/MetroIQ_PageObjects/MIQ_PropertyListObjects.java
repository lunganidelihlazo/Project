package MetroIQ_PageObjects;

import org.openqa.selenium.By;

public class MIQ_PropertyListObjects {
	public static final By propertyList_Icon = By.xpath("//a[text()='Property List']");
	public static final By currentAOI = By.xpath("//div[@class='float-left maintainarea_icon_pad']//following-sibling::div");
	public static final By pageTitle = By.xpath("//div[@class='title']");
	public static final By pageDescription = By.xpath("//div[@class='description']");
	public static final By PropertyListAOI = By.xpath("//div[@class='description']/b");
	public static final By PropertyListTable = By.id("gview_propertiesResultTable");
	public static final By PropertyListTableRow_1 = By.id("jqg_propertiesResultTable_1");
	public static final By PropertyListTableRow_2 = By.id("jqg_propertiesResultTable_2");
	public static final By PropertyListTableRow_1_Title = By.xpath("//td/input[@id='jqg_propertiesResultTable_1']//parent::td//following-sibling::td[@aria-describedby='propertiesResultTable_Suburb']");
	public static final By PropertyListTableRow_2_Title = By.xpath("//td/input[@id='jqg_propertiesResultTable_2']//parent::td//following-sibling::td[@aria-describedby='propertiesResultTable_Suburb']");
	public static final By ExportSelection_Dropdown = By.id("reportExportSelection");
	public static final String ExportSelection = "//input[@value='";
	public static final By PropertyType_Dropdown = By.name("PropertyType");
	public static final By LocalAuthority_Dropdown = By.name("LocalAuthority");
	public static final By Suburb_Dropdown = By.name("Suburb");
	
	public static final By PropertyListPageStart = By.xpath("//td[@id='propertiesResultPager_center']//td/input");
	public static final By PropertyListFooter = By.xpath("//td[@id='propertiesResultPager_right']/div");
	public static final By PropertyListPageDropdown = By.xpath("//select[@role='listbox']");
	public static final By PropertyListSuburb = By.xpath("//td[@aria-describedby='propertiesResultTable_Suburb']");
	public static final By PropertyListLeftPagination = By.id("next_propertiesResultPager");
	public static final By PropertyListLastPagination = By.id("last_propertiesResultPager");
	public static final By PropertyListPrevPagination = By.id("prev_propertiesResultPager");
	public static final By PropertyListFirstPagination = By.id("first_propertiesResultPager");
	
//	Unlocated Properties
	public static final By UnlocatedpropertyList_Icon = By.xpath("//a[text()='Unlocated Properties']");
	public static final By PropertyListLPICode_row1 = By.xpath("//td/input[@id='jqg_propertiesResultTable_1']//parent::td//following-sibling::td[@aria-describedby='propertiesResultTable_LPICode']");
	public static final By PropertyListLPICode_row2 = By.xpath("//td/input[@id='jqg_propertiesResultTable_2']//parent::td//following-sibling::td[@aria-describedby='propertiesResultTable_LPICode']");
	public static final By TownShip_Dropdown = By.id("gs_Township");
	public static final By Error = By.xpath("//div[@id='salesReportErrorBanner']/p");
	
	//Notificatons
	public static final By notifications_Icon = By.xpath("//a[text()='Notifications']");
	public static final By notifications_Type_Lable = By.xpath("//div[@id='notifications']//th[text()='Type']");
	public static final By notifications_NewEntries_Label = By.xpath("//div[@id='notifications']//th[text()='New Entries']");
	public static final By notifications_LastNotificationDate_Label = By.xpath("//div[@id='notifications']//th[text()='Last Notification Date']");
	public static final By notifications_TransferType_link = By.xpath("(//td[2]//parent::td)[1]");
	public static final By notifications_Transfer_Link = By.xpath("//a[text()='Transfers']");
	public static final By notifications_Transfer_TransfersResultTable_Checkbox = By.id("jqg_transfersResultTable_1");
	public static final By notifications_Transfer_TransfersResultTable_SelectAll_Checkbox = By.id("cb_transfersResultTable");
	public static final By notifications_Transfer_TransfersResultTable_Second_Checkbox = By.id("jqg_transfersResultTable_2");
	public static final By notifications_Transfer_UpdateNotificationDate_Button = By.id("btnUpdateAOIDate");
	public static final By notifications_Transfer_TransfersResultTable_FirstReport = By.xpath("//table[@id='transfersResultTable']//tr[@id='1']");
	public static final By notifications_Transfer_TransfersResultTable_SecondReport = By.xpath("//table[@id='transfersResultTable']//tr[@id='2']");
	
	public static final String notifications_Transfer_TransfersResultTable_Report_ConstantLabel = "//table[@id='transfersResultTable']//tr[@id='";
	public static final String notifications_Transfer_TransfersResultTable_Report_OfficialDescription_Label="']//td[@aria-describedby='transfersResultTable_OfficialDescription']";
	public static final String notifications_Transfer_TransfersResultTable_Report_ErfPortion_Label="']//td[@aria-describedby='transfersResultTable_ErfPortion']";
	public static final String notifications_Transfer_TransfersResultTable_Report_PropertyType_Label="']//td[@aria-describedby='transfersResultTable_PropertyType']";
	public static final String notifications_Transfer_TransfersResultTable_Report_Street_Label="']//td[@aria-describedby='transfersResultTable_Street']";
	public static final String notifications_Transfer_TransfersResultTable_Report_StreetAddress_Label="']//td[@aria-describedby='transfersResultTable_StreetAddress']";
	public static final String notifications_Transfer_TransfersResultTable_Report_Suburb_Label="']//td[@aria-describedby='transfersResultTable_Suburb']";
	public static final String notifications_Transfer_TransfersResultTable_Report_TitleDeed_Label="']//td[@aria-describedby='transfersResultTable_DocumentNumber']";
	public static final String notifications_Transfer_TransfersResultTable_Report_Extent_Label="']//td[@aria-describedby='transfersResultTable_ExtentInSQM']";
	public static final String notifications_Transfer_TransfersResultTable_Report_RemainingExtent_Label="']//td[@aria-describedby='transfersResultTable_RemainingExtent']";
	public static final String notifications_Transfer_TransfersResultTable_Report_Price_Label="']//td[@aria-describedby='transfersResultTable_Price']";
	public static final String notifications_Transfer_TransfersResultTable_Report_PurchaseDate_Label="']//td[@aria-describedby='transfersResultTable_PurchaseDate']";
	public static final String notifications_Transfer_TransfersResultTable_Report_RegistrationDate_Label="']//td[@aria-describedby='transfersResultTable_RegistrationDate']";
	public static final String notifications_Transfer_TransfersResultTable_Report_CaptureDate_Label="']//td[@aria-describedby='transfersResultTable_CaptureDate']";
	
	
	//Cuurent Reports
	
	public static final By CurrentReportsFooter = By.xpath("//td[@id='reportsResultPager_right']/div");
	public static final By CurrentReportsLeftPagination = By.id("next_reportsResultPager");
	public static final By CurrentReportsLastPagination = By.id("last_reportsResultPager");
	public static final By CurrentReportsPrevPagination = By.id("prev_reportsResultPager");
	public static final By CurrentReportsFirstPagination = By.id("first_reportsResultPager");
	public static final By currentReports_TriangleIcon = By.xpath("//tr[@id='1']//span[@class='ui-icon ui-icon-triangle-1-e']");
	public static final By currentReports_TriangleIcon_ExpandableBar = By.id("gview_reportsResultTable_1_t");
	public static final By currentReports_TriangleIcon_ExpandableBar_FilterType = By.id("jqgh_reportsResultTable_1_t_FilterType");
	public static final By currentReports_TriangleIcon_ExpandableBar_FilterParameter = By.id("jqgh_reportsResultTable_1_t_FilterParameter");
	public static final By currentReports_TriangleIcon_ExpandableBar_CaptureDate = By.xpath("//table[@id='reportsResultTable_1_t']//td[@aria-describedby='reportsResultTable_1_t_FilterType' and @title = 'CaptureDate ']");
	public static final By currentReports_TriangleIcon_ExpandableBar_PropertyType = By.xpath("//table[@id='reportsResultTable_1_t']//td[@aria-describedby='reportsResultTable_1_t_FilterType' and @title = 'Property Type']");
	public static final By currentReports_TriangleIcon_ExpandableBar_AreaOfInterest = By.xpath("//table[@id='reportsResultTable_1_t']//td[@aria-describedby='reportsResultTable_1_t_FilterType' and @title = 'Area Of Interest']");
	public static final By currentReports_TriangleIcon_ExpandableBar_LastNotificationDate = By.xpath("//table[@id='reportsResultTable_1_t']//td[@aria-describedby='reportsResultTable_1_t_FilterType' and @title = 'Last Notification Date']");
	
	
	
}
