package MetroIQ_PageObjects;

import org.openqa.selenium.By;

public class MIQ_ReportHistoryObjects {
	public static final By ReportHistory_Icon = By.xpath("//a[text()='Report History']");
	public static final By report_dropdown = By.xpath("//select[@id='reportFilter']");
	public static final By show_label = By.xpath("//label[text()='Show']");
	public static final String ReportHistoryTable = "//table[@aria-labelledby='gbox_ReportHistoryResultTable']//div[text()='";
	public static final By ReportHistory_AOI = By.xpath("//td[@aria-describedby='ReportHistoryResultTable_AreaOfInterest']");
	public static final By ReportHistory_ReportType = By.xpath("//td[@aria-describedby='ReportHistoryResultTable_ReportType']");
	public static final By ReportHistory_ReportType_dropdown = By.xpath("//select[@name='ReportType']");
	public static final By ReportHistory_footer = By.xpath("//td[@id='ReportHistoryResultPager_right']/div");
	public static final By ReportHistory_currentReport = By.xpath("//td[@aria-describedby='ReportHistoryResultTable_CurrentReportCreated']//a");
	public static final By currentReport_Dailog = By.xpath("//div[@id='createCurrentReport_NameDialog']");
	public static final By currentReport_DailogMessage= By.xpath("//div[@id='createCurrentReport_NameDialog']/p");
	public static final By currentReport_DailogText= By.xpath("//div[@id='createCurrentReport_NameDialog']//textarea");
	public static final By currentReport_DailogConfirm= By.xpath("//button[contains(text(),'Confirm')]");
	
	public static final By CreatedcurrentReport_DailogMessage= By.xpath("//div[@id='currentReportCreatedDialog']/p");
	public static final By CreatedcurrentReport_DailogOK= By.xpath("//div[@id='currentReportCreatedDialog']//following-sibling::div//button");
	public static final By ReportHistory_Row1 = By.xpath("//table[@id='ReportHistoryResultTable']//tr[@id='1']");
	public static final By ReportHistory_Email = By.xpath("//input[@value='Email']");

	public static final By ReportHistory_SendEmail = By.xpath("//input[@value='Send Email']");
	public static final By ReportHistory_EmailSuccess = By.xpath("//div[@class='notificationBanner successBanner']/p");
	public static final By CurrentReport_LastPage = By.xpath("//td[@id='last_reportsResultPager']/span");
	public static final By CurrentReport_Description = By.xpath("//td[@aria-describedby='reportsResultTable_Description']");
	
	public static final By offlineProcess_Icon = By.xpath("//a[text()='Offline Process']");
	public static final By offlineProcess_ResultsTable = By.id("processListResultTable");
	public static final By offlineProcess_ResultsTable_Description_List = By.xpath("//td[@aria-describedby='processListResultTable_ReportDescription']");
	
	public static final  String offlineProcess_ResultsTable_Status1="//td[@title='";
	public static final  String offlineProcess_ResultsTable_Status2="']//following-sibling::td[2]";
	
	// Subdivison
	
		public static final By subDivisionReport_Link = By.xpath("//a[text()='Sub-Division Report']");
		public static final By consolidationReport_Link = By.xpath("//a[text()='Consolidation Report']");
	
}
