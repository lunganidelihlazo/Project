package MetroIQ_Utility;

public class MIQConstant {
	
	public static final String URL = "https://extdev.lexissign.co.za/";
	
	public static final String Username = "TechDel@onyxms.co.za";
	
	public static final String Password = "onyxMS1234!";
	
	public static final String Path_SeleniumDriver = "C://Programs//eclipse//Lib//seleniumdrivers//";
	
	public static final String Path_TestData = "C://Workspace//LexisNexisCucumber//TestData//";
	
	public static final String File_TestData = "LS_700_Access_and_Security_Login_with_correct_credentials.xlsx";
	
	public static final int Col_TestCaseName = 0;	
	
	public static final int Col_Application_URL= 1;
	
	public static final int Col_Browser = 2;
	
	public static final int Col_UserName = 3;

	public static final int Col_Password = 4;
	
	public static final int Col_Result = 5;
	
	public static final String Path_ScreenShot = "C://Workspace//LexisNexis//LexisNexisCucumber//Screenshots//";
}
