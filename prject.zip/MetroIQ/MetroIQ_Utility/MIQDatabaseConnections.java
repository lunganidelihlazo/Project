package MetroIQ_Utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import MetroIQ_Utility.MIQUtils;

public class MIQDatabaseConnections {
		public static String sDBURL=MIQUtils.getProperty("DatabaseUrl");
		public static String sDBUsername=MIQUtils.getProperty("DatabaseUsername");
		public static String sDBPassword=MIQUtils.getProperty("DatabasePassword");
		Connection conn = null; 
		Statement stmt = null; 
		ResultSet resultSet = null;
	
	public void SetUpConnection() throws SQLException, ClassNotFoundException {
		try{	
			// Register JDBC driver (JDBC driver name and Database URL)
			Class.forName("com.mysql.jdbc.Driver");
			// Open a connection
			conn = DriverManager.getConnection(sDBURL,sDBUsername,sDBPassword);
			stmt = conn.createStatement();
			}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public ResultSet executeQuery(String sQuery) throws SQLException{
		try {
			resultSet = stmt.executeQuery(sQuery);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultSet;
	}
}
