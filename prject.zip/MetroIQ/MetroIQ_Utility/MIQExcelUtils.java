package MetroIQ_Utility;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import MetroIQ_Utility.MIQConstant;
import MetroIQ_Utility.MIQUtils;
import MetroIQ_Utility.MIQLog;


public class MIQExcelUtils {
	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;

	//This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method
	public static void setExcelFile(String Path,String SheetName) throws Exception {
		try {
			// Open the Excel file
			FileInputStream ExcelFile = new FileInputStream(Path);

			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
		} catch (Exception e){
			throw (e);
		}
	}

	//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num	
	public static String getCellData(int RowNum, int ColNum) throws Exception{
		try{
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			String CellData = Cell.getStringCellValue();

			return CellData;

		}catch (Exception e){
			return"";
		}
	}

	//HT: This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num	
	public static String getCellDataByColumName(int RowNum, int ColumName) throws Exception{
		try{
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColumName);
			String CellData = Cell.getStringCellValue();

			return CellData;

		}catch (Exception e){
			return"";
		}
	}
	//This method is to write in the Excel cell, Row num and Col num are the parameters
	public static void setCellData(String Result,  int RowNum, int ColNum) throws Exception	{
		try{
			Row  = ExcelWSheet.getRow(RowNum);
			Cell = Row.getCell(ColNum);

			if (Cell == null) {
				Cell = Row.createCell(ColNum);
				Cell.setCellValue(Result);
			} else {
				Cell.setCellValue(Result);
			}

			// Constant variables Test Data path and Test Data file name
			FileOutputStream fileOut = new FileOutputStream(MIQConstant.Path_TestData + MIQConstant.File_TestData);
			ExcelWBook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		}catch(Exception e){
			throw (e);
		}
	}

	//This method will get the last used row in the data sheet
	public static int getRowUsed() throws Exception {
		try{
			int RowCount = ExcelWSheet.getLastRowNum();
			MIQLog.info("Total number of Row used return as &lt; " + RowCount + " &gt;.");		
			return RowCount;
		}catch (Exception e){
			MIQLog.error("Class ExcelUtil | Method getRowUsed | Exception desc : "+e.getMessage());
			System.out.println(e.getMessage());
			throw (e);
		}
	}

	//Get row number by test case name
	public static int getRowContains(String sTestCaseName, int colNum) throws Exception{
		int i;
		try {
			int rowCount = MIQExcelUtils.getRowUsed();
			for ( i=0 ; i <= rowCount; i++){
				if  (MIQExcelUtils.getCellData(i,colNum).equalsIgnoreCase(sTestCaseName)){
					break;
				}	
			}
			return i;
		}catch (Exception e){
			MIQLog.error("Class ExcelUtil | Method getRowContains | Exception desc : " + e.getMessage());
			throw(e);
		}
	}
	public static  XSSFSheet getSheetObj(String filepath, String sheetName) throws Exception{
		XSSFSheet sheet=null;
		try {
			FileInputStream ExcelFile = new FileInputStream(filepath);
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet= ExcelWBook.getSheet(sheetName);		
		}
		catch (Exception e) {
			MIQLog.error("Class ExcelUtil | Method getRowContains | Exception desc : " + e.getMessage());
		}
		return ExcelWSheet;
	}
	//Get Cell value based on column name
	public static String getCellValueOnColumName(XSSFSheet sheetObject, String ColumnName,int row) throws Exception
	{	
		String cellValue=null;
		try {
			int SheetColCount=sheetObject.getRow(row).getPhysicalNumberOfCells();
			for(int Colcount=0;Colcount<SheetColCount;Colcount++)
			{
				if((sheetObject.getRow(0).getCell(Colcount).toString().equalsIgnoreCase(ColumnName)))
				{
					cellValue=sheetObject.getRow(row).getCell(Colcount).toString();
				}			
			}
		}
		catch (Exception e) {
			MIQLog.error("Class ExcelUtil | Method getRowContains | Exception desc : " + e.getMessage());
		}
		return cellValue;
	}
	
	
	/*public  Map<String, String> keyValueBasedOnColumnValue(XSSFSheet sheetObject, String ColumnName,int row) {
		List<String> getValue = new ArrayList<String>();
		ArrayList<String> Keys=new ArrayList<String>();
		Map<String, String> excelConfig = new HashMap<String, String>();
		getCellValueOnColumName(sheetObject, ColumnName, row);
		ArrayList<String> values=getCellValueOnColumName(sheetObject, ColumnName, row);
		
		
		
		
		ArrayList<String> values1=re.columnData(valueColNum, sheetName, path);
		for(int i=0; i<Keys.size(); i++)
		{	
			for(int j=i; j<values1.size(); j++)
			{
				excelConfig.put(Keys.get(i), values1.get(j));
				break;
			}
		}
		return excelConfig;
	}*/
}
