package MetroIQ_Utility;

import static org.testng.Assert.fail;
import MIQ_accelerators.MIQActionsClass;

public class MIQExceptionHandle {
    
	//Function to handle exceptions
    public static void HandleException(Exception e, String sError) {
           try {
//                  System.out.println(sError);
//                  System.out.println(e.getStackTrace().toString()); 
                  MetroIQ_Utility.MIQLog.info(e.getStackTrace().toString());
                  MIQActionsClass.GetScreenShot();
                  fail(sError);
                  } catch (Exception ex) {
                        System.out.println(ex.getStackTrace().toString()); 
                  }
    }

}
