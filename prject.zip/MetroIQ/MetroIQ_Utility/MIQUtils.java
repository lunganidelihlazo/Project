package MetroIQ_Utility;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import MIQ_accelerators.MIQActionsClass;

import MIQ_accelerators.MIQBase;

import MetroIQ_Utility.MIQConstant;
import MetroIQ_Utility.MIQExcelUtils;
import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;

public class MIQUtils extends MIQBase{
	/*public Utils(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}*/

	private static WebDriver driver = null;
	public static String FILE_NAME = System.getProperty("user.dir")+"//MetroIQData//config.properties";
	public static Properties properties=null;

	

	public static WebDriver openBrowser(int iTestCaseRow) throws Exception{

		String sBrowserName;
		try {
			//sBrowserName = ExcelUtils.getCellData(iTestCaseRow, Constant.Col_Browser);
			sBrowserName="Chrome";
			if(sBrowserName.equals("Mozilla")){
				driver = new FirefoxDriver();           
				MIQLog.info("New driver instantiated");	
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				MIQLog.info("Implicit wait applied on the driver for 10 seconds");
				driver.get(MIQConstant.URL);
				MIQLog.info("Web application launched successfully");
			}
			if(sBrowserName.equals("Chrome")){
				System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
				driver = new ChromeDriver();
				MIQLog.info("New driver instantiated");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				MIQLog.info("Implicit wait applied on the driver for 10 seconds");
				driver.get(MIQConstant.URL);
				MIQLog.info("Web application launched successfully");
			}
		}catch (Exception e){

			MIQLog.error("Class Utils | Method OpenBrowser | Exception desc : "+e.getMessage());
		}

		return driver;
	}

	static {
		File f = new File(FILE_NAME);
		properties = new Properties();
		FileInputStream in;
		try {
			in = new FileInputStream(f);
			properties.load(in);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getProperty(String strKey) {
		String strValue = null;
		try{
			File f = new File(FILE_NAME);
			if(f.exists()){
				strValue=properties.getProperty(strKey);
			}
			else
				System.out.println("File not found!");
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return strValue;
	}

	public static String getTestCaseName(String sTestCase)throws Exception{
		String value = sTestCase;
		try{
			int posi = value.indexOf("@");
			value = value.substring(0, posi);
			posi = value.lastIndexOf(".");    
			value = value.substring(posi + 1);
			return value;
		}catch (Exception e){
			MIQLog.error("Class Utils | Method getTestCaseName | Exception desc : "+e.getMessage());
			throw (e);
		}
	}

	public static int getRowContains(String sTestCaseName, int colNum) throws Exception{
		int i;
		try {
			int rowCount = MIQExcelUtils.getRowUsed();
			for ( i=0 ; i<rowCount; i++){
				if  (MIQExcelUtils.getCellData(i,colNum).equalsIgnoreCase(sTestCaseName)){
					break;
				}
			}
			return i;
		}catch (Exception e){
			MIQLog.error("Class ExcelUtil | Method getRowContains | Exception desc : " + e.getMessage());
			throw(e);
		}
	}

    public static void takeScreenshot(WebDriver driver, String sTestCaseName,String path) throws Exception{
        try{
               File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
               FileUtils.copyFile(scrFile, new File(path + sTestCaseName +".jpg"));
        } catch (Exception e){
               MIQLog.error("Class Utils | Method takeScreenshot | Exception occured while capturing ScreenShot : "+e.getMessage());
               throw new Exception();
        }
 }

//	public static void takeScreenshot(WebDriver driver, String sTestCaseName,String path) throws Exception{
//		try{
//			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//			FileUtils.copyFile(scrFile, new File(path + sTestCaseName +".jpg"));
//		} catch (Exception e){
//			Log.error("Class Utils | Method takeScreenshot | Exception occured while capturing ScreenShot : "+e.getMessage());
//			throw new Exception();
//		}
//	}
	/**
	 * Description: To set the file name in file input window
	 * @param string
	 */
	public static void setClipboardData(String string) {		
		StringSelection stringSelection = new StringSelection(string);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
	}

	/**
	 * Description: To upload file in file input window using Robot class
	 * @param fileLocation
	 * @return
	 */
	public static boolean uploadFile(String fileLocation) {
		try {
			//Setting clipboard with file location
			setClipboardData(fileLocation);

			Thread.sleep(4000);
			//native key strokes for CTRL, V and ENTER keys

			Robot robot = new Robot();
			robot.delay(250);
			/*robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);*/
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.delay(100);
			robot.keyPress(KeyEvent.VK_ENTER);			
			robot.keyRelease(KeyEvent.VK_ENTER);
			//Thread.sleep(1500);
		} catch (Exception exp) {
			exp.printStackTrace();
		}
		return true;
	}

	public static void createNewFile(String sFilePath) throws IOException {
		File file = new File(sFilePath);
		file.createNewFile();
	}

	public static void copyFile(String sCopyFromFilePath,String sCopyToPath) throws Exception{
		try {
			FileInputStream Fread =new FileInputStream(sCopyFromFilePath); 
			FileOutputStream Fwrite=new FileOutputStream(sCopyToPath) ; 
			int c; 
			while((c=Fread.read())!=-1) 
				Fwrite.write((char)c); 

			Fread.close();
			Fwrite.close(); 
			System.out.println("File is Copied");          
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void writeDataIntoFile(String sFilepath,String sContent) throws IOException{
		BufferedWriter  bw=null;
		FileWriter  fw =null;
		try {
			fw = new FileWriter(sFilepath);
			bw = new BufferedWriter(fw);
			bw.write(sContent);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			bw.close();
			fw.close();
		}
	}
	
	public static String readDataFromFile(String sFilepath) throws IOException{
//		BufferedReader br=null;
//		FileReader  fr =null;
//		String sReadData="";
//		try {
//			fr = new FileReader(sFilepath);
//			br = new BufferedReader(fr);
//			 while((sReadData = br.readLine()) != null)
//		        {
//		            System.out.println(sReadData);
//		        }
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
//		finally {
//			br.close();
//			fr.close();
//		}
//		return sReadData;
		
		 BufferedReader br = new BufferedReader(new FileReader(sFilepath));
		    try {
		        StringBuilder sb = new StringBuilder();
		        String line = br.readLine();

		        while (line != null) {
		            sb.append(line);
		            sb.append("\n");
		            line = br.readLine();
		        }
		        return sb.toString();
		    } finally {
		        br.close();
		    }
	}
	public static void updateDataInFile(String sFilePath,String sKey,String sValue) throws IOException{
		try {
			if(!sKey.contains("@")) {
				sKey="@"+sKey;
			}
			Path path = Paths.get(sFilePath);
			String fileContent = new String(Files.readAllBytes(path));
			Files.write(path, fileContent.getBytes());			
			if(fileContent.contains(sKey)) {
				fileContent = fileContent.replaceAll(sKey, sValue);	
			}
			Files.write(path, fileContent.getBytes());
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	//Compare Images
	public static boolean compareImage(By locator, String sImagePath) throws Throwable {
		float percentage = 0;
		boolean result=false;
		try {
			String path=System.getProperty("user.dir")+sImagePath;
			String file=MIQActionsClass.getAttribute(locator, "src", "image");
			URL url = new URL(file);
			InputStream in = new BufferedInputStream(url.openStream());
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buf = new byte[1024];
			int n = 0;
			while (-1!=(n=in.read(buf)))
			{
				out.write(buf, 0, n);
			}
			out.close();
			in.close();
			byte[] response = out.toByteArray();
			FileOutputStream fos = new FileOutputStream(MIQUtils.getProperty("DownloadPath"));
			fos.write(response);
			fos.close();

			File fileA = new File(path);
			File fileB = new File(MIQUtils.getProperty("DownloadPath"));

			BufferedImage biA = ImageIO.read(fileA);
			DataBuffer dbA = biA.getData().getDataBuffer();
			int sizeA = dbA.getSize();
			BufferedImage biB = ImageIO.read(fileB);
			DataBuffer dbB = biB.getData().getDataBuffer();
			int sizeB = dbB.getSize();
			int count = 0;
			// compare data-buffer objects //
			if (sizeA == sizeB) {
				for (int i = 0; i < sizeA; i++) {
					if (dbA.getElem(i) == dbB.getElem(i)) {
						count = count + 1;
					}
				}
				percentage = (count * 100) / sizeA;
				if(percentage==100.0){
					result=true;	
				}
				else
				{
					result=false;	
				}
			} 
			else 
			{
				result=false;	
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return result;
	}	


	public static void updateDataUsingExcelData(XSSFSheet sheetObject, String ColumnName,int row,String sFilePath) throws Exception{

		String sValue = MIQExcelUtils.getCellValueOnColumName(sheetObject, ColumnName, row);

		updateDataInFile(sFilePath,ColumnName,sValue);
	}

	public static void deleteFile(String sFilepath) throws IOException{
		try {
			File file = new File(sFilepath);
			if(file.delete()){
				System.out.println(file.getName() + " is deleted!");
			}else{
				System.out.println("Delete operation is failed.");
			}


		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
}