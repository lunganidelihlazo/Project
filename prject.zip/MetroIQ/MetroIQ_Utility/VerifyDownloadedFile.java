package MetroIQ_Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class VerifyDownloadedFile {
	private static final int BUFFER_SIZE = 4096;

	public static boolean isFileDownloaded(String downloadPath, String fileName) {
		boolean flag = false;
		File dir = new File(downloadPath);
		File[] dir_contents = dir.listFiles();

		for (int i = 0; i < dir_contents.length; i++) {
			if (dir_contents[i].getName().equals(fileName)) {
				System.out.println(dir_contents[i].getName());
				return flag = true;
			}
		}

		return flag;
	}
	public static String isFileDownloadedName(String downloadPath, String fileName) {
//		boolean flag = false;
		File dir = new File(downloadPath);
		File[] dir_contents = dir.listFiles();

		for (int i = 0; i < dir_contents.length; i++) {
			
			if (dir_contents[i].getName().contains(fileName)) {
				System.out.println(i+"i");
				System.out.println(dir_contents[i].getName());
				return dir_contents[i].getName();
			}
		}

		return null;
	}

	/* Check the file from a specific directory with extension */
	public boolean isFileDownloaded_Ext(String dirPath, String ext) {
		boolean flag = false;
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			flag = false;
		}
		for (int i = 0; i < files.length; i++) {
			if (files[i].getName().contains(ext)) {
				System.out.println(files[i].getName());
				flag = true;
			}
		}
		return flag;
	}

	/* Get the latest file from a specific directory */
	public File getLatestFilefromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}

		System.out.println(lastModifiedFile.getName());
		return lastModifiedFile;
	}

	/* Get the latest file from a specific directory */
	public File getLatestZipFilefromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = null;
		for (int i = 0; i < files.length; i++) {
			if (files[i].getName().contains(".zip")) {
				lastModifiedFile = files[i];
			}
		}
		System.out.println(lastModifiedFile.getName());
		return lastModifiedFile;
	}
	public String getDownloadedDocumentName(String downloadDir,
			String fileExtension) {
		String downloadedFileName = null;
		boolean valid = true;
		boolean found = false;

		// default timeout in seconds
		long timeOut = 20;
		try {
			Path downloadFolderPath = Paths.get(downloadDir);
			WatchService watchService = FileSystems.getDefault()
					.newWatchService();
			downloadFolderPath.register(watchService,
					StandardWatchEventKinds.ENTRY_CREATE);
			long startTime = System.currentTimeMillis();
			do {
				WatchKey watchKey;
				watchKey = watchService.poll(timeOut, TimeUnit.SECONDS);
				long currentTime = (System.currentTimeMillis() - startTime) / 1000;
				if (currentTime > timeOut) {
					System.out
					.println("Download operation timed out.. Expected file was not downloaded");
					return downloadedFileName;
				}

				for (WatchEvent event : watchKey.pollEvents()) {
					WatchEvent.Kind kind = event.kind();
					if (kind.equals(StandardWatchEventKinds.ENTRY_CREATE)) {
						String fileName = event.context().toString();
						System.out.println("New File Created:" + fileName);
						if (fileName.endsWith(fileExtension)) {
							downloadedFileName = fileName;
							System.out
							.println("Downloaded file found with extension "
									+ fileExtension
									+ ". File name is "
									+ fileName);
							Thread.sleep(500);
							found = true;
							break;
						}
					}
				}
				if (found) {
					return downloadedFileName;
				} else {
					currentTime = (System.currentTimeMillis() - startTime) / 1000;
					if (currentTime > timeOut) {
						System.out.println("Failed to download expected file");
						return downloadedFileName;
					}
					valid = watchKey.reset();
				}
			} while (valid);
		}

		catch (InterruptedException e) {
			System.out.println("Interrupted error - " + e.getMessage());
			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out
			.println("Download operation timed out.. Expected file was not downloaded");
		} catch (Exception e) {
			System.out.println("Error occured - " + e.getMessage());
			e.printStackTrace();
		}
		return downloadedFileName;
	}

	/* Unzip a zip file */
	public long unzipFile(File zipfile, String outdir) {
		ZipEntry entry = null; long size = 0;
		try {
			//outdir="";
			System.out.println();
			File destDir = new File(outdir);
			if (!destDir.exists()) {
				destDir.mkdir();
			}
			ZipInputStream zipIn = new ZipInputStream(new FileInputStream(
					zipfile));
			entry = zipIn.getNextEntry();

			// iterates over entries in the zip file
			while (entry != null) {
				String filePath = outdir + File.separator + entry.getName();
				File file = new File(filePath);
				System.out.println("Unzip file " + entry.getName() + " to "
						+ file.getAbsolutePath());
				if (!entry.isDirectory()) {
					// if the entry is a file, extracts it
					extractFile(zipIn, file);
					size++;
				} else {
					// if the entry is a directory, make the directory
					File dir = new File(file.getAbsolutePath());
					dir.mkdir();
					size++;
				}
				zipIn.closeEntry();
				entry = zipIn.getNextEntry();
			}

			zipIn.close();	
System.out.println();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return(size);
	}

	/* Extract the file from zip folder */
	private void extractFile(ZipInputStream zipIn, File file)
			throws IOException {
		
		try{
			byte[] bytesIn = new byte[BUFFER_SIZE];

			FileOutputStream fOutput = new FileOutputStream(file);
			int count = 0;
			while ((count = zipIn.read(bytesIn)) > 0) {
				// write 'count' bytes to the file output stream
				fOutput.write(bytesIn, 0, count);
			}

			fOutput.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public static File deleteLatestFilefromDir(String dirPath) {
		System.out.println("Delete file");
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
//				files[i].delete();
			}
		}
		System.out.println(lastModifiedFile.getName());
		lastModifiedFile.delete();
		
		return lastModifiedFile;
	}
	
	/* Get the latest file from a specific directory */
	public static String getLatestFileNameFromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}

		System.out.println(lastModifiedFile.getName());
		return lastModifiedFile.getName();
	}
	
	public static String deleteLatestReportfromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		String fileName="";
		if (files == null || files.length == 0) {
			return null;
		}

//		File lastModifiedFile = files[0];
		for (int i = 0; i < files.length; i++) {
			if (files[i].getName().contains("PropertyListReportExport_")) {
				 fileName=files[i].getName();
				 System.out.println(fileName);
				files[i].delete();
			}
		}
		return fileName;
		
		
		
	}
}
