package MetroIQ_seleniumglucode;

import org.junit.Assert;
import org.openqa.selenium.By;
import MIQ_accelerators.MIQActionsClass;
import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_AdminObjects;
import MetroIQ_PageObjects.MIQ_AreaOfInterestObjects;
import MetroIQ_PageObjects.MIQ_PropertyListObjects;
import MetroIQ_Utility.MIQExceptionHandle;
import MetroIQ_Utility.MIQUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

public class MIQ_Admin {
	static String NoOfReports;
	@And("^Check admin page is opened$")
	public void verifyAdminPage() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.pageTitle, 15);
			String title=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageTitle, "pageTitle");
			Assert.assertEquals(title, "Admin");
			
			String Description=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageDescription, "pageDescription");
//		
			Assert.assertTrue(Description.contains("Manage additional users, Area of Interest, report branding and theming."));
			
		
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Admin page not opened");
		}
	}
	
	@And("^Click on \"([^\"]*)\" in admin manage options$")
	public void ClickOnPaginationLink(String sOption) throws Throwable {
		try {
			
				MIQActionsClass.clickOnElement(By.xpath(MIQ_AdminObjects.ManageOption+sOption+"']"), "Manage additional users");
		
			
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to selected the export option");
			}
	}
	
	@And("^\"([^\"]*)\" user \"(.*)\" in the additional users$")
	public void EnableOrDisableUser(String sOption , String sUser) throws Throwable {
		try {
			String email = MIQUtils.getProperty(sUser);
			email=email.toUpperCase();
			if(sOption.equalsIgnoreCase("Disable")) {
				System.out.println(MIQ_AdminObjects.ManageUser1+email+MIQ_AdminObjects.ManageUser2+sOption+"']/a");
				MIQActionsClass.clickOnElement(By.xpath(MIQ_AdminObjects.ManageUser1+email+MIQ_AdminObjects.ManageUser2+sOption+"']/a"), "Disable the user");
			} 
			else if(sOption.equalsIgnoreCase("Enable")) {
				MIQActionsClass.clickOnElement(By.xpath(MIQ_AdminObjects.ManageUser1+email+MIQ_AdminObjects.ManageUser2+sOption+"']/a"), "Enable the user");
			}
			
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to enable/disable user");
			}
	}
	
	@And("^Click on confirm button for user action$")
	public static void clickConfirm() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AdminObjects.ConfirmAction, 10);
			System.out.println("error "+MIQActionsClass.getElementText(MIQ_AdminObjects.ConfirmActionMessage, "ConfirmAction"));
			MIQActionsClass.clickOnElement(MIQ_AdminObjects.ConfirmAction, "Confirm");
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on Confirm");
		}
	}
	
	@And("^Check Confirm message \"([^\"]*)\" for the user \"(.*)\"$")
	public void CheckErrorMessage(String sMessage , String sUser) throws Throwable {
		try {
			String email = MIQUtils.getProperty(sUser);
			email=email.toLowerCase();
			String Message =MIQActionsClass.getElementText(MIQ_AdminObjects.ConfirmActionMessage, "ConfirmAction");
			Assert.assertEquals(Message, (sMessage+" "+email));
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check error message");
			}
	}
	
	@And("^Check user \"([^\"]*)\" is \"([^\"]*)\"$")
	public void CheckDisabledUser(String sUser, String sOption) throws Throwable {
		try {
			String email = MIQUtils.getProperty(sUser);
			email=email.toUpperCase();
			System.out.println(MIQ_AdminObjects.ManageUser1+email+MIQ_AdminObjects.disableUser+sOption+"']");
			Thread.sleep(3000);
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.ManageUser1+email+MIQ_AdminObjects.disableUser+sOption+"']"), "Disabled user"));
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check the disabled/enabled user");
			}
	}
	@And("^Check Confirm message \"([^\"]*)\" for the enabling user$")
	public void CheckErrorMessage(String sMessage) throws Throwable {
		try {
			
			String Message =MIQActionsClass.getElementText(MIQ_AdminObjects.ConfirmActionMessage, "ConfirmAction");
			Assert.assertEquals(Message, sMessage);
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check error message");
			}
	}
	
	@And("^Check \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" displayed in admin page$")
	public void CheckAdminPageValues(String sOrganisation, String sMetroIQReports, String sProperty, String sScheme, String sTransfer, String sCurrent, String sMAOI, String sRenewal) throws Throwable {
		try {
			
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu+sOrganisation+"')]"), "sOrganisation"));
			
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu+sProperty+"')]"), "sProperty"));

			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu+sScheme+"')]"), "sScheme"));

			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu+sTransfer+"')]"), "sTransfer"));

			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu+sCurrent+"')]"), "sCurrent"));

			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu+sMAOI+"')]"), "sMAOI"));

			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu+sRenewal+"')]"), "sRenewal"));
			
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.adminMenu1+sMetroIQReports+"')]"), "sMetroIQReports"));
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check the disabled/enabled user");
			}
	}

	@And("^Check Admin Manage Menu \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\"$")
	public void CheckManageAdminPageValues(String sManageAdditional, String sReportBranding, String sAOI, String sRoleManager) throws Throwable {
		try {
			
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.ManageOption+sManageAdditional+"']"), "sManageAdditional"));
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.ManageOption+sReportBranding+"']"), "sReportBranding"));
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.ManageOption+sAOI+"']"), "SAOI"));
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.ManageOption+sRoleManager+"']"), "sRoleManager"));

			} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check the disabled/enabled user");
			}
	}
	
	@And("^Click on Edit Area in admin manage options$")
	public static void clickOnEditArea() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AdminObjects.Admin_EditArea, 10);
			MIQActionsClass.clickOnElement(MIQ_AdminObjects.Admin_EditArea, "EditArea");
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on Confirm");
		}
	}
	
	@And("^Click on \"(.*)\" no of reports$")
	public static void clickOnNoOfReperts(String sReportType) throws Throwable {
		try {
			NoOfReports=MIQActionsClass.getElementText(By.xpath(MIQ_AdminObjects.adminMenu+sReportType+MIQ_AdminObjects.reportsNumber), sReportType);
			
			System.out.println(NoOfReports);
			MIQActionsClass.clickOnElement(By.xpath(MIQ_AdminObjects.adminMenu+sReportType+MIQ_AdminObjects.reportsNumber), sReportType);
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on Confirm");
		}
	}
	
	@And("^Check report history page is opened$")
	public void verifyReportHistoryPage() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.pageTitle, 15);
			String title=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageTitle, "pageTitle");
			Assert.assertEquals(title, "Report history");		
			System.out.println("ReportType"+MIQActionsClass.GetSelectedValue(MIQ_AdminObjects.ReportType));
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Admin page not opened");
		}
	}
	
	@And("^Check the report type \"(.*)\" and no of reports$")
	public static void checkNoOfReperts(String sReportType) throws Throwable {
		try {
			/*
			//report Type is not working as expected
			String reportType=MIQActionsClass.GetSelectedValue(MIQ_AdminObjects.ReportType);
			Assert.assertEquals(reportType, sReportType);
			*/
			
			String footer=MIQActionsClass.getElementText(MIQ_AdminObjects.ReportHistory_NoOfReports, "footer");
			if(!(footer.equalsIgnoreCase("No records to view"))) {
				System.out.println("checkNoOfReperts");
			String[] footerM=footer.split(" ");
			Assert.assertEquals(footerM[5], NoOfReports);
			Thread.sleep(3000);
			}
			else {
				Assert.assertEquals("0", NoOfReports);
			}
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check no of reports");
		}
	}
	
	@And("^Check current report page is opened$")
	public void verifyCurrentReportPage() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.pageTitle, 15);
			MIQActionsClass.waitForElement(MIQ_AdminObjects.CurrentReport_ReortTable_FirstReport, 200);
			String title=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageTitle, "pageTitle");
			Assert.assertEquals(title, "Current Report List");		
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.pageTitle, 15);
//			Thread.sleep(20000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Current Report List page not opened");
		}
	}
	@And("^Check no of reports in current reports page$")
	public static void checkNoOfCurrentReperts() throws Throwable {
		try {
			Thread.sleep(5000);
			MIQActionsClass.waitForElement(MIQ_AdminObjects.CurrentReport_NoOfReports, 30);
			String Header=MIQActionsClass.getElementText(MIQ_AdminObjects.CurrentReport_NoOfReports, "Header");
			if(!(Header.equalsIgnoreCase("No records to view"))) {
				System.out.println("checkNoOfReperts");
			String[] HeaderM=Header.split(" ");
			Assert.assertEquals(HeaderM[5], NoOfReports);
			
			}
			else {
				Assert.assertEquals("0", NoOfReports);
			}
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check no of reports");
		}
	}
	
	@When("^Check Role manager page should appear$")
	public void checkRoleManager() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AdminObjects.RoleManager, 300);
			Assert.assertTrue(MIQActionsClass.isElementVisible(MIQ_AdminObjects.RoleManager, "RoleManager"));
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check RoleManager");
		}
	}
	
	@And("^click on \"([^\"]*)\" of the role \"([^\"]*)\"$")
	public void ClickOnRoleManagerAction(String sAction,String sRole) throws Throwable {
		try {
//			System.out.println(MIQ_AdminObjects.RoleManager_Role+sRole+MIQ_AdminObjects.RoleManager_Action+sAction+"']");
				MIQActionsClass.clickOnElement(By.xpath(MIQ_AdminObjects.RoleManager_Role+sRole+MIQ_AdminObjects.RoleManager_Action+sAction+"']"), "RoleManager_Role");
				Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to do action"+sAction+" on "+sRole);
			}
	}
	
	@When("^Enter \"([^\"]*)\" in role name textbox$")
	public void enterRoleName(String sRoleName) {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AdminObjects.Role_textBox, 10);
			MIQActionsClass.typeInTextBox(MIQ_AdminObjects.Role_textBox, sRoleName, "RoleName");
			

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter Username");
		}
	}
	
	@And("^Click on \"([^\"]*)\" button for Role name$")
	public void clickOnSave(String sAction) throws Throwable {
		try {
			if (sAction.equalsIgnoreCase("Save")) {
				MIQActionsClass.waitForElement(MIQ_AdminObjects.Role_textBox_Save, 5);
				MIQActionsClass.clickOnElement(MIQ_AdminObjects.Role_textBox_Save, "Save");
				Thread.sleep(3000);
			}
			else if (sAction.equalsIgnoreCase("Cancel")) {
				MIQActionsClass.waitForElement(MIQ_AdminObjects.Role_textBox_Cancel, 5);
				MIQActionsClass.clickOnElement(MIQ_AdminObjects.Role_textBox_Cancel, "Cancel");
				Thread.sleep(3000);
			}
			else if (sAction.equalsIgnoreCase("Cancel Delete")) {
				MIQActionsClass.waitForElement(MIQ_AdminObjects.Role_delete_Cancel, 5);
				MIQActionsClass.clickOnElement(MIQ_AdminObjects.Role_delete_Cancel, "Cancel");
				Thread.sleep(3000);
			}
		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sAction );
		}
	}
	@And("^Check the updated role name \"([^\"]*)\"$")
	public void CheckRoleName(String sRoleName) throws Throwable {
		try {
			
	Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.RoleManager_RoleName+sRoleName+"')]"), "RoleManager_Role"));


		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Check role name " + sRoleName );
		}
	}

	@And("^Check the role name is not updated with \"([^\"]*)\"$")
	public void CheckRoleNameNotUpdated(String sRoleName) throws Throwable {
		try {
			
	Assert.assertFalse(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.RoleManager_RoleName+sRoleName+"')]"), "RoleManager_Role"));


		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Check role name " + sRoleName );
		}
	}
	
	@And("^Check the dailog \"([^\"]*)\" and notification message \"([^\"]*)\" for delete$")
	public void CheckDeleteRoleNotification(String sDailog, String sNotification) throws Throwable {
		try {
			
//	Assert.assertFalse(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.RoleManager_RoleName+sRoleName+"')]"), "RoleManager_Role"));
			MIQActionsClass.waitForElement(MIQ_AdminObjects.RoleDelete_dailog, 5);
			String dailogname=MIQActionsClass.getElementText(MIQ_AdminObjects.RoleDelete_dailog, "Dailog");
			System.out.println(dailogname+"dailog");
			Assert.assertTrue(dailogname.contains(sDailog));
			String sMessage=MIQActionsClass.getElementText(MIQ_AdminObjects.Role_delete_Message, "Notification");
			Assert.assertEquals(sMessage,sNotification );
		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Check role name notification message" );
		}
	}
	@And("^Check \"([^\"]*)\" dailog should display$")
	public void CheckRoleDailog(String sName) throws Throwable {
		try {
			
//	Assert.assertFalse(MIQActionsClass.isElementVisible(By.xpath(MIQ_AdminObjects.RoleManager_RoleName+sRoleName+"')]"), "RoleManager_Role"));
			MIQActionsClass.waitForElement(MIQ_AdminObjects.Role_dailog, 15);
			String dailogname=MIQActionsClass.getElementText(MIQ_AdminObjects.Role_dailog, "Dailog");
			System.out.println(dailogname+"dailog");
			Assert.assertTrue(dailogname.contains(sName));
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Check role dailog " );
		}
	}
}
