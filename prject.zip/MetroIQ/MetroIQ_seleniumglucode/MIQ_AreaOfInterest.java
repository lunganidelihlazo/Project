package MetroIQ_seleniumglucode;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;

import MIQ_accelerators.MIQActionsClass;
import MIQ_accelerators.MIQBase;
import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_AreaOfInterestObjects;
import MetroIQ_Utility.MIQExceptionHandle;
import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utility.ExceptionHandle;

import static org.junit.Assert.assertEquals;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;


public class MIQ_AreaOfInterest {
	public static WebDriver newdriver = MIQBase.driver;
	Alert alert = null;
	static String target;
	
	
	@And("^Check NoMunicipalAreaOfInterest Dialog appeared$")
	public static void checkNoMunicipalAreaOfInterest() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.AOI_NoMunicipalAOIDialog, 5);

			MIQActionsClass.isElementVisible(LoginObjects.AOI_NoMunicipalAOIDialog, "NoMunicipalAOIDialog");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the NoMunicipalAOIDialog displays");
		}
	}

	@And("^Check SetMunicipalAoi button appeared on dailog$")
	public static void checkSetMunicipalAoiButton() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.AOI_SetMunicipalAoi_Button, 5);

			MIQActionsClass.isElementVisible(LoginObjects.AOI_SetMunicipalAoi_Button, "SetMunicipalAoi Button");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the SetMunicipalAoi Button displays");
		}
	}

//	@And("^Check except admin other menu options are disabled$")
//	public static void checkDisabledMenu() throws Throwable {
//		try {
//
//			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Map View" + "')]"), "Map View");
//			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Property Search" + "')]"),
//					"Property Search");
//			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Transfer Report" + "')]"),
//					"Transfer Report");
//			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Notifications" + "')]"),
//					"Notifications");
//			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Property List" + "')]"),
//					"Property List");
//			MIQActionsClass.isElementVisible(
//					By.xpath(LoginObjects.AOI_DisabledMenu + "Unlocated Property List" + "')]"),
//					"Unlocated Property List");
//			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Current Reports" + "')]"),
//					"Current Reports");
//			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Report History" + "')]"),
//					"Report History");
//		} catch (Exception e) {
//			MIQExceptionHandle.HandleException(e, "Failed to Check the SetMunicipalAoi Button displays");
//		}
//	}
	
	@And("^Check except admin other menu options are disabled$")
	public static void checkDisabledMenu() throws Throwable {
		try {

			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Map View" + "')]"), "Map View");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Property Search" + "')]"),
					"Property Search");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Transfer Report" + "')]"),
					"Transfer Report");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Sub-Division Report" + "')]"),
					"Sub-Division Report");
			MIQActionsClass.isElementEnabled(MIQ_AreaOfInterestObjects.menu_ConsolidationReport);
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Notifications" + "')]"),
					"Notifications");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Property List" + "')]"),
					"Property List");
			MIQActionsClass.isElementVisible(
					By.xpath(LoginObjects.AOI_DisabledMenu + "Unlocated Property List" + "')]"),
					"Unlocated Property List");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Current Reports" + "')]"),
					"Current Reports");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Report History" + "')]"),
					"Report History");
			MIQActionsClass.isElementEnabled(MIQ_AreaOfInterestObjects.menu_Admin);
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the SetMunicipalAoi Button displays");
		}
	}

	@When("^Click on \"([^\"]*)\" button in MetroIQ$")
	public void clickbuttonMetroIQ(String arg1) throws Throwable {
		try {
		MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Button, 10);
		MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Button, "Login button");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on "+arg1+ " button in MetroIQ");
		}
	}

	@When("^Select a \"([^\"]*)\" from the District dropdown and the selected \"([^\"]*)\" should now be highlighted on the map$")
	public void selectDistrictDropdownAndValidate(String sDistrictValue, String sDistrict) throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Disrict_Dropdown, 5);
			MIQActionsClass.selectByVisibleText(MIQ_AreaOfInterestObjects.setMuncipalArea_Disrict_Dropdown,
					sDistrictValue);
			MIQBase.driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
			if (MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.setMuncipalArea_Disrict_AllWards,
					"All District Wards")) {

				Screen s = new Screen();
				Pattern pattern = new Pattern(
						System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sDistrict + ".PNG");
				s.exists(pattern);
				MIQLog.info("The selected " + sDistrict + " highlighted on the map");
			} else {
				Assert.fail("Failed to check selected " + sDistrict + " highlighted on the map");
				MIQLog.info("Failed to check selected " + sDistrict + " highlighted on the map");
			}

			// Thread.sleep(3000);
		} catch (Exception e) {
			ExceptionHandle.HandleException(e,
					"Failed to Select a " + sDistrictValue + "from the District dropdown and the selected " + sDistrict
							+ " should now be highlighted on the ma");
		}
	}

	@Then("^The each ward which falls within the selected \"([^\"]*)\" should now be listed in the East panel$")
	public void checkEachWardFalls(String sValue)throws Throwable {

		try {

			Thread.sleep(3000);

			List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
					"//div[@id='selectedFeaturesDiv']//label[@class='chkbox_container']//span[@class='chkbox_checkmark']"));
			if (sValue == sValue) {
				for (int i = 0; i < getList.size(); i++) {
					getList.get(i).isSelected();

				}
			} else {

				MIQLog.info("Failed to Validate the lit containing " + sValue);
				Assert.fail("Failed to Validate the lsit containing " + sValue);
			}

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Validate the lsit containing " + sValue);
		}
	}

	@Then("^Check Local Municipalities radio button should now be selected$")
	public void checkLocalMunicipalitiesRadioButton()throws Throwable {
		try {

			if ((MIQActionsClass.isCheckBoxChecked(MIQ_AreaOfInterestObjects.setMuncipalArea_LocalMunicipalities_Radio_Button))) {
				MIQLog.info("Local Municipalities radio button is selected");
			}

			else {

				MIQLog.info("Failed to check Local Municipalities radio button is selected");
				Assert.fail("Failed to check Local Municipalities radio button is selected");
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Local Municipalities radio button is selected");
		}
	}

	@And("^Click on SetMunicipalAoi button$")
	public static void clickSetMunicipalAoiButton() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.AOI_SetMunicipalAoi_Button, 5);

			MIQActionsClass.clickOnElement(LoginObjects.AOI_SetMunicipalAoi_Button, "SetMunicipalAoi Button");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the SetMunicipalAoi Button");
		}
	}

	@And("^Check Set Municipal AreaOfInterest pane displayed$")
	public static void checkSetMunicipalAoiPane() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.AOI_SetMunicipalAoi_Pane, 5);

			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.AOI_SetMunicipalAoi_Pane,
					"SetMunicipalAoi Pane");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the SetMunicipalAoi Pane displays");
		}
	}

	@And("^Click on Save button$")
	public static void clickSaveMunicipalAoiButton() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_SaveConfirm, 5);

			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.setMuncipalArea_SaveConfirm,	"setMuncipalArea_SaveConfirm");
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the setMuncipalArea_SaveConfirm Button");
		}
	}

	@When("^Check Review selection pane id displayed and selected district \"([^\"]*)\" is highlighted in the map$")
	public void checkSelectDistrictReview(String sDistrict) throws Throwable {
		try {
			Thread.sleep(20000);

			MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.ReviewSelection_Pane, 200);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.ReviewSelection_Pane, "review Selection");

			if (MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.ReviewSelection_Pane, "review Selection")) {

				Screen s = new Screen();
				Pattern pattern = new Pattern(
						System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sDistrict + ".PNG");
				s.exists(pattern);
				MIQLog.info("The selected " + sDistrict + " highlighted on the map");
			} else {
				Assert.fail("Failed to check selected " + sDistrict + " highlighted on the map");
				MIQLog.info("Failed to check selected " + sDistrict + " highlighted on the map");
			}

			// Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check selected " + sDistrict + " highlighted on the map");
		}
	}

	@And("^Enter Area name as \"([^\"]*)\"$")
	public void enterAreaName(String sAreaName) {
		try {

			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName, 3);
			MIQActionsClass.typeInTextBox(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName, sAreaName,"AreaName text field");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter AreaName");
		}
	}

	@And("^Click on Save button for Area Name$")
	public static void clickSaveAreaNameButton() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_SaveName, 5);

			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.setMuncipalArea_SaveName,	"setMuncipalArea_SaveName");
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the setMuncipalArea_SaveName Button");
		}
	}

	@When("^Check AOI selected pane with name \"([^\"]*)\" is displayed and selected district is highlighted in the map$")
	public void checkSelectedAOIPane(String sDistrict) throws Throwable {
		try {
			// Thread.sleep(60000);

			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane, 500);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane, "AreaOfInterest_Pane");
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.AreaOfInterest_SelectedDistrict_Dropdown, 5);
			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.AreaOfInterest_SelectedDistrict_Dropdown,"setMuncipalArea_SaveName");
			System.out.println(MIQActionsClass.GetSelectedValue(MIQ_AreaOfInterestObjects.selectedAoi));
			String SelectedAoi = MIQActionsClass.GetSelectedValue(MIQ_AreaOfInterestObjects.selectedAoi);
			Assert.assertEquals(SelectedAoi, sDistrict);
			if (MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane,	"AreaOfInterest_Pane")) {

				Screen s = new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sDistrict + ".PNG");
				s.exists(pattern);
				MIQLog.info("The selected " + sDistrict + " highlighted on the map");
			} else {
				Assert.fail("Failed to check selected " + sDistrict + " highlighted on the map");
				MIQLog.info("Failed to check selected " + sDistrict + " highlighted on the map");
			}

			// Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "selected district not highlighted");
		}
	}

	@And("^Check all menu options Should be enabled in westPane$")
	public static void checkEnabledMenu() throws Throwable {
		try {

			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Map View" + "')]"), "Map View");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Property Search" + "')]"),"Property Search");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Transfer Report" + "')]"),"Transfer Report");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Notifications" + "')]"),"Notifications");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Property List" + "')]"),"Property List");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Unlocated Property List" + "')]"),"Unlocated Property List");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Current Reports" + "')]"),"Current Reports");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Report History" + "')]"),"Report History");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check all menu options Should be enabled in westPane");
		}
	}

	@And("^click on profile dropdown$")
	public static void clickProfileDropdown() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.Profiledropdown, 15);

			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.Profiledropdown, "Profiledropdown");
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the Profiledropdown ");
		}
	}

	@And("^click on Maintain Area option$")
	public static void clickMaintainArea() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.MaintainArea, 5);

			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.MaintainArea, "Profiledropdown");
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the MaintainArea ");
		}
	}

	@And("^select district \"([^\"]*)\" from areaOfInterest dropdown$")
	public static void clickSelectedArea(String sDistrict) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.clickOnElement(By.xpath(MIQ_AreaOfInterestObjects.AreaOfInterest_SelectedDistrict + sDistrict + "')]"),"SelectedDistrict");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to select  "+sDistrict+ "district from areaOfInterest dropdown");
		}
	}

	@And("^Click on \"([^\"]*)\" button in AOI Pane$")
	public static void clickDeleteMunicipalAoiButton(String sAction) throws Throwable {
		 try {
	            if (sAction.equalsIgnoreCase("Delete")) {
	                MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.DeleteMoi_Button, 15);
	                MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.DeleteMoi_Button, "DeleteMoi_Button");
	            } else if (sAction.equalsIgnoreCase("Delete Confirm")) {
	            	
	                MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.DeleteMoi_ConfirmButton, 3);
	                MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.DeleteMoi_ConfirmButton, "DeleteMoi_ConfirmButton");
	                MIQActionsClass.waitForElement(LoginObjects.AOI_NoMunicipalAOIDialog, 500);
	            } else if (sAction.equalsIgnoreCase("Edit")) {
	                MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.EditMoi_Button, 15);
	                MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.EditMoi_Button, "EditMoi_Button");
	            } else if (sAction.equalsIgnoreCase("Continue")) {
	                MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.EditMAOI_continue, 15);
	                MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.EditMAOI_continue, "EditMAOI_continue");
	            } else if (sAction.equalsIgnoreCase("AU_DeleteConfirm")) {
	            	
	                MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.DeleteMoi_ConfirmButton, 3);
	                MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.DeleteMoi_ConfirmButton, "DeleteAU_ConfirmButton");            
	            }
	            else if (sAction.equalsIgnoreCase("New")) {
	                MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.new_Moi_Button, 300);
	                MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.new_Moi_Button, "New button");
	            }
	            
	        }

		catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click "+sAction +" button in AOI Pane");
		}
	}
	@Given("^Check The District dropwdown should be highlighted in \"([^\"]*)\" and user should not be able to advance to the next step$")
	public void checkDistrictDropdownColor(String sColor) throws Throwable {
		try {

			String getDistictTextBoxcolor=  MIQActionsClass.getCssValue(MIQ_AreaOfInterestObjects.setMuncipalArea_Disrict_Dropdown,"border"," District color");
			String split[] = getDistictTextBoxcolor.split("\\(");
			getDistictTextBoxcolor=split[1];
			//Convert rgd color to hexa
			getDistictTextBoxcolor= MIQActionsClass.convertRGBtoHexa(getDistictTextBoxcolor);
			if(sColor.contains("red")) {
				if(getDistictTextBoxcolor.equalsIgnoreCase("#ff0000")) {
					
					MIQActionsClass.isElementNotVisible(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName,"AreaName text field");
					MIQLog.info("District field is highlighted in "+sColor+ "and user should not be able to advance to the next step");
					
					
				}
				else {
					Assert.fail("District field  is not highlighted in "+sColor+ "and user should not be able to advance to the next step");
					MIQLog.info("District field is not highlighted in "+sColor+ "and user should not be able to advance to the next step");
				}
			}


		}catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "District field is not highlighted in "+sColor+ "and user should not be able to advance to the next step");
		}	
	}
	@When("^Click on \"([^\"]*)\" radio button and the \"([^\"]*)\" layer should now appear on the map$")
	public void clickRadioButtonShouldAppearOnMap(String arg1, String sWards) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Wards_Radio_Button, 3);
			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Wards_Radio_Button, "setMuncipalArea_SaveName");
			if(MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.setMuncipalArea_Wards_Radio_Button, "All District Wards")) {
				
				Screen s=new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sWards+".PNG");
				s.exists(pattern);
				MIQLog.info("The selected "+sWards+" highlighted on the map");
			}
			else {
				Assert.fail("Failed to check selected "+sWards+" highlighted on the map");
				MIQLog.info("Failed to check selected "+sWards+" highlighted on the map");
			}	

			// Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click on " +arg1 + "radio button and the "+sWards+" layer should now appear on the map");
		}
	}
	@Then("^Click on any of the currently selected \"([^\"]*)\" on the map$")
	public void clickSelectedWardOnMap(String sSelectedWard) throws Throwable {
		try {
		
				Thread.sleep(3000);
				Screen s=new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sSelectedWard+".PNG");
				Thread.sleep(2000);
				s.click(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sSelectedWard+".PNG");	
				MIQLog.info("The selected "+sSelectedWard+" highlighted on the map");
			
			
			// Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Click  on any of the currently selected " +sSelectedWard + "  on the map");
		}
	}

	@Then("^Check the \"([^\"]*)\" should no longer be highlighted on the map$")
	public void checkWardNotHighlighted(String sUnHighlightedWard) throws Throwable {
		try {
			
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sUnHighlightedWard+".PNG");
			s.exists(pattern);	
			MIQLog.info("The selected "+sUnHighlightedWard+" no longer be highlighted on the map");
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to check the " +sUnHighlightedWard + "   no longer be highlighted on the map");
	}
	}

	@Then("^Check The \"([^\"]*)\" checkbox should also no longer be selected in the list of currently selected wards in the \"([^\"]*)\" East panel$")
	public void checkcheckboxNoLongerSelected(String sWardValue, String arg2) throws Throwable {
	try {
		Thread.sleep(3000);
			
		if(!(MIQActionsClass.isCheckBoxChecked((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1 + sWardValue + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2))))) {

			MIQLog.info("Check the  "+sWardValue+ "checkbox should also no longer be selected in the list of currently selected wards in the" +arg2+ "East Panel");
				} 
			
		
		else {
			Assert.fail("Failed to Check the  "+sWardValue+ "checkbox should also no longer be selected in the list of currently selected wards in the" +arg2+ "East Panel");
			MIQLog.info("Failed to Check the  "+sWardValue+ "checkbox should also no longer be selected in the list of currently selected wards in the" +arg2+ "East Panel");
		}
	
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Check the  "+sWardValue+ "checkbox should also no longer be selected in the list of currently selected wards in the" +arg2+ "East Panel");
	}
	}
	
	@Then("^Click on the \"([^\"]*)\" that was deselected in the previous step on the map$")
	public void clickWarddeselectedPreviousStepOnMap(String sUnHighlightedWard) throws Throwable {
	try {
		
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sUnHighlightedWard+".PNG");
			s.exists(pattern);
			Thread.sleep(2000);
			s.click(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sUnHighlightedWard+".PNG");	
			MIQLog.info("Clicked on the "+sUnHighlightedWard+" that was deselected in the previous step on the map");

	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Click on the " +sUnHighlightedWard + "  that was deselected in the previous step on the map");
	}
	}

	@Then("^The \"([^\"]*)\" should now be highlighted on the map$")
	public void clickWardHighlightedOnMap(String sSelectedWard) throws Throwable {
		try {
			
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sSelectedWard+".PNG");
			Thread.sleep(2000);
			MIQLog.info("The selected "+sSelectedWard+" highlighted on the map");

	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Click  on any of the currently selected " +sSelectedWard + "  on the map");
	}
	}

	@Then("^Check the \"([^\"]*)\" checkbox should also be selected and displayed in the list of currently selected wards in the \"([^\"]*)\" East panel$")
	public void checkCheckboxselectedDisplayedInTheEastPanel(String sWardValue, String arg2) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.isCheckBoxChecked((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1+ sWardValue + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2)));
			MIQLog.info("Check the  "+sWardValue+ "checkbox should also be selected and displayed in the list of currently selected wards in the " +arg2+ "East Panel");
		
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Check the  "+sWardValue+ "checkbox should also be selected and displayed in the list of currently selected wards in the " +arg2+ "East Panel");
		}
	}
	@Then("^Click on any of the currently \"([^\"]*)\" \"([^\"]*)\" on the \"([^\"]*)\" East panel$")
	public void clickCurrentlyOnTheEastPanel(String arg1, String sWardValue, String arg3) throws Throwable {
		try {
			Thread.sleep(3000);		
			MIQActionsClass.clickOnElement((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1 + sWardValue + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2)), "") ;

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Click on any of the currently  "+arg1+ "on the " +arg3+ "East Panel");
		}
			
	}
	@Then("^Check the \"([^\"]*)\" in \"([^\"]*)\" page should be highlighted in \"([^\"]*)\" and user should not be able to advance to the next step$")
	public void checkHighlightedUserShouldNotAdvanceNexStep(String arg1, String arg2, String sColor) throws Throwable {
		try {

			String getDistictTextBoxcolor=  MIQActionsClass.getCssValue(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName,"border"," District color");
			String split[] = getDistictTextBoxcolor.split("\\(");
			getDistictTextBoxcolor=split[1];
			//Convert rgd color to hexa
			getDistictTextBoxcolor= MIQActionsClass.convertRGBtoHexa(getDistictTextBoxcolor);
			if(sColor.contains("red")) {
				if(getDistictTextBoxcolor.equalsIgnoreCase("#ff0000")) {
					
					MIQActionsClass.isElementNotVisible(MIQ_AreaOfInterestObjects.setMuncipalArea_Wards_Radio_Button,"Wards Radio Button");
					MIQLog.info("Area Name is highlighted in "+sColor+ "and user should not be able to advance to the next step");
					
					
				}
				else {
					Assert.fail("Area name field is not highlighted in "+sColor+ "and user should not be able to advance to the next step");
					MIQLog.info("Area name field is not highlighted in "+sColor+ "and user should not be able to advance to the next step");
				}
			}


		}catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Area name field is not highlighted in "+sColor+ "and user should not be able to advance to the next step");
		}	
	}

	
	@Then("^Check The previously selected \"([^\"]*)\" should still be highlighted on the map$")
	public void checkPreviouslySelectedShouldHighlightedOnMap(String sWards) throws Throwable {
		try {
			
			
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sWards+".PNG");
			s.exists(pattern);
			MIQLog.info("The selected "+sWards+" highlighted on the map");
		
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Check The previously selected "+sWards+" should still be highlighted on the map");
	}
	}
	@Then("^Click on \"([^\"]*)\" button at REVIEW SELECTION page$")
	public void clickREVIEWSELECTIONPage(String sScreen) throws Throwable {
		try {
			if(sScreen.equalsIgnoreCase("Cancel")) {
				MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_ConfirmationCancel_Button, 5);
				MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.setMuncipalArea_ConfirmationCancel_Button,"");
			
			}
		} catch (Exception e) {
			// TODO: handle exception
			MIQExceptionHandle.HandleException(e, "Failed to click on  "+sScreen+ " button at REVIEW SELECTION page");
		}
		}
	

	@Then("^Click on \"([^\"]*)\" button at Set Municipal AreaOfInterest page$")
	public void clickAreaOfInterestpage(String sScreen) throws Throwable {
		try {
			if(sScreen.equalsIgnoreCase("Reset")) {
				MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Reset_Button, 5);
				MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Reset_Button,"Reset Button");
			
			} else if (sScreen.equalsIgnoreCase("Cancel")) {
				MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Cancel_Button, 5);
				MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.setMuncipalArea_Cancel_Button, " Cancel Button");
			
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on  "+sScreen+ " button at Set Municipal AreaOfInterest page");
		}
	}
	@Then("^Check the previously saved \"([^\"]*)\" should be populated in the \"([^\"]*)\" input field$")
	public void checkPreviouslySavedPopulatedInputField(String sAreaName, String arg2) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName, 300);
			String AreaNameField=MIQActionsClass.getAttribute(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName,"value", "Area Name Text");
			System.out.println(AreaNameField);
			Assert.assertEquals(AreaNameField, sAreaName);
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the previously saved "+sAreaName+ " should be populated in the" +arg2+ "input field");
		}
	
	}

	@Then("^Remove the text from the \"([^\"]*)\" input field$")
	public void removeTextInput(String arg1) throws Throwable {
		try {
			
				MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName, 5);
				MIQActionsClass.clearTextbox(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName,"Clear");
						
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Remove the text from the  "+arg1+ " input field");
		}
	}
	@Then("^Check user should be redirected back to the \"([^\"]*)\" East panel$")
	public void checkUserRedirectedBackEastpanel(String sAreaName) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipal_EditAreaName, 5);
			String AreaNameField=MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.setMuncipal_EditAreaName, "Area Name Text");
			System.out.println(AreaNameField);
			Assert.assertEquals(AreaNameField, sAreaName);
	
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Check user should be redirected back to the  "+sAreaName+ " East panel");
	}
	}
	
		
	@And("^select Local Municipalities radio button in AOI pane$")
	public static void selectLoaclMuncipalitiesOption() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.MAOI_LocalMunicipalities, 5);
			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.MAOI_LocalMunicipalities, "MAOI_LocalMunicipalities");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to select Local Municipalities radio button in AOI pane ");
		}
	}
	@And("^select other muncipality \"([^\"]*)\" by clicking on the map$")
	public static void selectLoaclMuncipalitieOnMap(String sLocalMuncipality) throws Throwable {
		try {
			Thread.sleep(3000);
			Screen s = new Screen();
			s.click(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sLocalMuncipality + ".PNG");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the LocalMunicipalities");
		}
	}
	@Then("^uncheck wards \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" from MAOI$")
	public void UncheckWards(String sWardValue1, String sWardValue2, String sWardValue3) throws Throwable {
	try {
			
		MIQActionsClass.clickOnElement((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1 + sWardValue1 + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2)),"ward");
		MIQActionsClass.clickOnElement((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1 + sWardValue2 + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2)),"ward");
		MIQActionsClass.clickOnElement((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1 + sWardValue3 + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2)),"ward");

	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to uncheck wards");
	}
	}
	@Then("^drag the scroll bar in AOI pane MetroIQ$")
	public void dragScrollBar() throws Throwable {
		try {
//			Thread.sleep(2000);
			Screen s = new Screen();
			s.click(System.getProperty("user.dir") + "\\MetroIQData\\Images\\drag.png");
			s = null;
			Thread.sleep(3000);
			           
		} catch (Exception e) {
			e.printStackTrace();
			ExceptionHandle.HandleException(e, "Failed to drag the scroll bar in MetroIQ");
		}
	}
	
	@And("^check the Area name \"([^\"]*)\" should not be changed$")
	public static void checkAreaNameAfterEdit(String sAreaName) throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName, 5);
			String ActualAreaName=MIQActionsClass.getAttribute(MIQ_AreaOfInterestObjects.setMuncipalArea_AreaName, "value", "Area name");
			Assert.assertEquals(ActualAreaName, sAreaName);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the Area name   "+sAreaName+ "should not be changed");
		}
	}
	
	@When("^Verify the Mapview with selected MAOI \"([^\"]*)\"$")
	public void checkMapView(String sDistrict) throws Throwable {
		try {
			Thread.sleep(20000);
			MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
		//	target = System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sDistrict  + ".PNG";
			
			
	
				Screen s = new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sDistrict  + ".PNG");
				//s.wait(target, 10*60);
				s.exists(pattern);

		} catch (Exception e) {
			ExceptionHandle.HandleException(e, "Failed to Verify the Mapview with selected MAOI " +sDistrict);
		}
	}

	@When("^Check Area Of Interest Pane should appear$")
	public void checkAOIPane() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane, 400);
			Assert.assertTrue(MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane, "AreaOfInterest_Pane"));
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Area Of Interest Pane should appear");
		}
	}
	@When("^Current reports warning should be displayed$")
	public void checkWarning() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.EditMaoi_Warning, 15);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.EditMaoi_Warning, "EditMaoi_Warning");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check tCurrent reports warning should be displayed");
		}
	}
	@When("^Edit area pane should be displayed$")
	public void checkEditMAOIPane() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.EditMaoi_Pane, 15);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.EditMaoi_Pane, "EditMaoi_Pane");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Edit area pane should be displayed");
		}
	}
	
	@And("^Check all of the buttons on the AREAS OF INTEREST East panel should now be enabled$")
	public static void checkEastPanelButtons() throws Throwable {
		 try {
	            
	                MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.EditMoi_Button, 150);
	              Assert.assertTrue(MIQActionsClass.isElementEnabled(MIQ_AreaOfInterestObjects.DeleteMoi_Button));
	              Assert.assertTrue(MIQActionsClass.isElementEnabled(MIQ_AreaOfInterestObjects.EditMoi_Button));
	              Assert.assertTrue(MIQActionsClass.isElementEnabled(MIQ_AreaOfInterestObjects.SelectMAOI_Button));
	              Assert.assertTrue(MIQActionsClass.isElementEnabled(MIQ_AreaOfInterestObjects.NewMAOI_Button));
	                }
		 catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Faile to check all of the buttons on the AREAS OF INTEREST East panel should now be enabled");
			}
		}
	
	@Then("^Check browser dialog should popup, stating that \"([^\"]*)\"$")
	public void LocalMunicipalityInside(String sText) throws Throwable {
		try {
			Thread.sleep(2000);
			alert = MIQBase.driver.switchTo().alert();
			String textOnAlert=alert.getText();
		Assert.assertEquals(textOnAlert, sText);
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check browser dialog should popup, stating that "+sText);
		}
	}

	@Then("^Click \"([^\"]*)\" in the browser popup dialog and the the browser dialog popup should close$")
	public void checkcheckDialogPopupClose(String arg1) throws Throwable {
		try {	
			Thread.sleep(3000);
			alert.accept();
			MIQActionsClass.isAlertNotVisible();
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click "+arg1+" in the browser popup dialog and the the browser dialog popup should close");
		}
	}
	@Then("^Check \"([^\"]*)\" dropdown should not be visible$")
	public void checkDropdownShouldNotVisible(String sDistrict) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.isElementNotVisible(MIQ_AreaOfInterestObjects.AreaOfInterest_SelectedDistrict_Dropdown, "District dropdwon");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to check "+sDistrict+" dropdown should not be visible");
		}
	}

	@Then("^Check the \"([^\"]*)\" radio button should not be visible$")
	public void check_the_radio_button_should_not_be_visible(String sRadio) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.isElementNotVisible(MIQ_AreaOfInterestObjects.MAOI_LocalMunicipalities, "Local Municpalities radio button");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check "+sRadio+" radio button should not be visible");
		}
	}
	@When("^Validate if the \"([^\"]*)\" displayed$")
	public void validateMessagedisplayed(String sValidate) throws Throwable {
		
		try {
			
			Thread.sleep(2000);			
            String ErrorMessage = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.ErrorMessage_Unable, "Validate if Message is displayed");            
            assertEquals(ErrorMessage,sValidate);
            Thread.sleep(3000);
			
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Validate if Message is displayed");
	}
	}
	
@When("^Click the \"([^\"]*)\" button$")
	public void clickBackButton(String arg1) throws Throwable {
		
		try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.Back_Button, 5);
			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.Back_Button, "Click Back");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the Back Button");
		}
	}
	
	@And ("^All of the buttons on the \"(.*)\" East panel should now be enabled$")
	public static void All_Buttons_are_enabled(String sDistrict) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.New_Button, 200);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.New_Button, "NEW");
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.Select_Button, 200);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.Select_Button, "SELECT");
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.Edit_Button, 2);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.Edit_Button, "EDIT");
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.Delete_Button, 2);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.Delete_Button, "DELETE");
			
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check All of the buttons on the " +sDistrict+" East panel should now be enabled");
		}
	}
	@And("^Hover on profile dropdown$")
	public static void HoverProfileDropdown() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.Profiledropdown, 15);
			MIQActionsClass.mouseover(MIQ_AreaOfInterestObjects.Profiledropdown);
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Hover the Profile dropdown ");
		}
	}
	
	@And("^Check SetMunicipalAoi button does not appeared on dailog$")
	public static void checkIfMunicipalAoiButtonIs_NotVisiable() throws Throwable {
		try {
			Thread.sleep(2000);
			MIQActionsClass.isElementNotVisible(LoginObjects.AOI_SetMunicipalAoi_Button, "SetMunicipalAoi Button");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the SetMunicipalAoi button does not appeared on dailogs");
		}
	}
	
	@And("^Check except all menu options are disabled$")
	public static void checkAllDisabledMenu() throws Throwable {
		try {

			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Map View" + "')]"), "Map View");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Property Search" + "')]"),	"Property Search");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Transfer Report" + "')]"),"Transfer Report");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Sub-Division Report" + "')]"),"Sub-Division Report");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Notifications" + "')]"),"Notifications");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Property List" + "')]"),"Property List");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Unlocated Property List" + "')]"),"Unlocated Property List");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Current Reports" + "')]"),"Current Reports");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_DisabledMenu + "Report History" + "')]"),"Report History");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the except all menu options are disabled");
		}
	}
	@Then("^Check \"([^\"]*)\" East panel should appear$")
	public void checkEastPanelShouldAppear(String arg1) throws Throwable {
try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.deleteArea_Label, 5);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.deleteArea_Label, "Delete Area Label");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to check " +arg1+ "East panel should appear");
		}
	}

	@Then("^Validate the \"([^\"]*)\" East panel text$")
	public void validateEastPanelText(String arg1) throws Throwable {
try {
			
			Thread.sleep(2000);
			String sMessage = "Please confirm that you would like to delete the area \"No Current Report\".";
            String ConfirmationMessage = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.deleteArea_Message_Label, "Delete Area Message"); 
            System.out.println(ConfirmationMessage);
            assertEquals(ConfirmationMessage,sMessage);
            
			
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Validate the "+arg1+ " East panel text");
	}
	}
	@Then("^Check the \"([^\"]*)\" area should no longer appear in the \"([^\"]*)\" areas list$")
	public void checkAreaShouldNoLongerAppear(String sValue, String arg2) throws Throwable {
		List<String> optionList = new ArrayList<String>();
		try {
			
			Thread.sleep(3000);
				
				List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//select[@id='areasOfInterest']//option"));
				for (int i = 0; i < getList.size(); i++) {
					String s = getList.get(i).getText();
					System.out.println("abc text" + s);
					optionList.add(s);
					System.out.println("abc text" + optionList);

				}
			
			if (!optionList.toString().contains(sValue)) {
				Thread.sleep(3000);
				MIQLog.info(sValue +"area no longer appear in the "+arg2);
			} else {
			
				MIQLog.info("Failed to check" +sValue +"area no longer appear in the "+arg2);
				Assert.fail("Failed to check" +sValue +"area no longer appear in the "+arg2);
			}

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check" +sValue +"area no longer appear in the "+arg2);
		}
	}
	
	@When("^Check AOI selected pane with name \"(.*)\" is displayed and selected \"(.*)\" is highlighted in the map$")
	public void checkSelectedAOIPane(String sDistrict, String District ) throws Throwable {
		try {

			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane, 500);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane, "AreaOfInterest_Pane");
            String ErrorMessage = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.noCurrentReport, "No Current Report");            
            assertEquals(ErrorMessage,sDistrict);
            Thread.sleep(3000);		
			if (MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.AreaOfInterest_Pane,"AreaOfInterest_Pane")) {

				Screen s = new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + District + ".PNG");
				s.exists(pattern);
				MIQLog.info("The selected " + District + " highlighted on the map");
			} else {
				Assert.fail("Failed to check selected " + District + " highlighted on the map");
				MIQLog.info("Failed to check selected " + District + " highlighted on the map");
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "selected district not highlighted in the map");
		}
	}
	@Then("^Check the local muncipality \"([^\"]*)\" checkbox should also be selected and displayed in the list of currently selected wards in the \"([^\"]*)\" East panel$")
	public void checkLocalMunciplaitySelectedArea(String sWardValue, String arg2) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.isCheckBoxChecked((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_LoaclMuncipality_Value1+ sWardValue + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2)));
			MIQLog.info("Check the Local muncipality "+sWardValue+ "checkbox should also be selected and displayed in the list of currently selected wards in the " +arg2+ "East Panel");
		
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Check the  "+sWardValue+ "checkbox should also be selected and displayed in the list of currently selected wards in the " +arg2+ "East Panel");
		}
	}
	@When("^Delete Area pane should appear for confirmation$")
	public void checkDeleteAreaPane() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.DeleteArea_Pane, 15);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.DeleteArea_Pane, "DeleteArea_Pane");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to check the AOI pane");
		}
	}
	@When("^Check \"([^\"]*)\" Area of Interest should have been saved$")
	public void checkAreaOfInterestSaved(String sDistrict) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.clickOnElement(By.xpath(MIQ_AreaOfInterestObjects.AreaOfInterest_SelectedDistrict + sDistrict + "')]"),"SelectedDistrict");
			String ConfirmationMessage = MIQActionsClass.getElementText(By.xpath(MIQ_AreaOfInterestObjects.AreaOfInterest_SelectedDistrict + sDistrict + "')]") ,"SelectedDistrict");
	        System.out.println(ConfirmationMessage);
			 assertEquals(ConfirmationMessage,sDistrict);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to check " +sDistrict+ " Area of Interest should have been saved");
		}
	}
	

	@When("^Check the \"([^\"]*)\" area should be highlighted on the map$")
	public void checkAreaShouldHighlightedOnMap(String arg1) throws Throwable {
		try {

			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.DeleteArea_Pane, 15);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.DeleteArea_Pane, "DeleteArea_Pane");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to check" +arg1+" area should be highlighted on the map");
		}
	}
	
	@When("^Check all menu options Should be enabled in westPane for \"([^\"]*)\"$")
	public void checkAllMenuOptionsEnabled(String arg1) throws Throwable {
		try {
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Map View" + "')]"), "Map View");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Property Search" + "')]"),"Property Search");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Transfer Report" + "')]"),"Transfer Report");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Notifications" + "')]"),"Notifications");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Property List" + "')]"),"Property List");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Current Reports" + "')]"),"Current Reports");
			MIQActionsClass.isElementVisible(By.xpath(LoginObjects.AOI_EnabledMenu + "Report History" + "')]"),"Report History");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check all menu options Should be enabled in westPane for" +arg1);
		}
	}
	@Then("^Check warned message \"(.*)\"$")
	public void checkWarnedMessageDefault(String arg1) throws Throwable {
		try {

			Thread.sleep(3000);
			String WarnMessage=arg1.replaceAll("/", "\"");
			  String ConfirmationMessage = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.deleteArea_Warning_Message_Label1,"Warning Message");
			  assertEquals(ConfirmationMessage,WarnMessage);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to Check warned message" +arg1);
		}
	}
	@Then("^Check \"([^\"]*)\" East panel should appear for \"([^\"]*)\"$")
	public void checkEastPanelShouldAppear(String arg1, String arg2) throws Throwable {
try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.additionalUser_DeleteArea_Label, 300);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.additionalUser_DeleteArea_Label, "Delete Area Label");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to check "+arg1+ "East panel should appear for" +arg2);
		}
	}
	
	@Then("^Check the user should be warned \"([^\"]*)\"$")
	public void checkUserShouldWarned(String WarnMessage) throws Throwable {
		try {
			Thread.sleep(3000);
			  String ConfirmationMessage = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.deleteArea_Warning_Message_Label2,"Warning Message");
			  assertEquals(ConfirmationMessage,WarnMessage);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to Check the user should be warned " +WarnMessage);
		}
	}
	
//	@Then("^\"([^\"]*)\" the map$")
//	public void the_map(String arg1) throws Throwable {
//		//MIQActionsClass.zoomOut();
////		JavascriptExecutor jse = (JavascriptExecutor)MIQBase.driver;
////		jse.executeScript("document.body.style.zoom = '30%';");
//		for(int i=0; i<3; i++){
//	        Robot robot = new Robot();
//	        robot.keyPress(KeyEvent.VK_CONTROL);
//	        //robot.keyPress(KeyEvent.VK_MINUS);
//	        robot.keyPress(KeyEvent.VK_PLUS);
//	        robot.keyRelease(KeyEvent.VK_CONTROL);
//	        //robot.keyRelease(KeyEvent.VK_MINUS);
//	        robot.keyPress(KeyEvent.VK_PLUS);
//	        }
//	}
	@Then("^Check wards are disable by clicking on \"([^\"]*)\" in the list of selected MAOI$")
	public void CheckWardsAreDisabled(String sWardValue) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.clickOnElement((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1+ sWardValue + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2)),"wards");
			System.out.println(MIQActionsClass.isCheckBoxChecked((By.xpath(MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value1+ sWardValue + MIQ_AreaOfInterestObjects.setMuncipalArea_CheckBox_Wards_Value2))));
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check the  disable wards");
		}
	}
	@And("^Click on selected MAOI \"([^\"]*)\"$")
	public static void clickOnSelectedMAOI(String sLocalMuncipality) throws Throwable {
		try {

			Screen s = new Screen();			
			s.click(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sLocalMuncipality + ".PNG");
			
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on selected MAOI" +sLocalMuncipality);
		}
	}
	@And("^verify the warning popup with message \"([^\"]*)\" , \"([^\"]*)\"$")
	public static void verifyAlertMessage(String sAlertmessage1, String sAlertmessage2) throws Throwable {
		try {
			Thread.sleep(3000);
			Alert a=MIQBase.driver.switchTo().alert();
			String Alert=a.getText();
			System.out.println(Alert);
			
			Assert.assertTrue(Alert.contains(sAlertmessage1));
			Assert.assertTrue(Alert.contains(sAlertmessage2));
			Thread.sleep(2000);
			a.accept();
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check warning popup with message");
		}
	}
	
	@Then ("^Click on any of the currently selected \"(.*)\" on the list$")
	public void clickOnSelectedWard(String sWardValue) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.deselectWard61, 5);
			MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.deselectWard61, "Deselect Ward 61");
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Click On Selected Ward");
		}
	}
	@Then("^Check warned message \"([^\"]*)\" on the reports warning$")
	public void check_warned_message_on_the_reports_warning(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		try {
			Thread.sleep(3000);
			String WarnMessage=arg1.replaceAll("/", "\"");
			
			  String ConfirmationMessage = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.deleteArea_Warning_Message_Label1A,"Warning Message");
			  assertEquals(ConfirmationMessage,WarnMessage);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check warning message on the Current Report");
		}
	}

	@Then("^Check the user should be warned \"([^\"]*)\" on the reports warning$")
	public void check_the_user_should_be_warned_on_the_reports_warning(String arg1) throws Throwable {
	   
		try {
			Thread.sleep(3000);
			String WarnMessage=arg1;//.replaceAll("/", "\"");
			System.out.println(WarnMessage);
			  String ConfirmationMessage = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.deleteArea_Warning_Message_Label2B,"Warning Message");
			  assertEquals(ConfirmationMessage,WarnMessage);
			  // Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Deactivation warning warning message on the Current Report");
		}
	}
	
	@Then("^Check the Local Municipality selected areas list of all of the checkboxes should be deselected$")
	public void checkLocalMunicipalityCheckboxesDeselected() throws Throwable {
		try {
			
			
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@id='selectedFeaturesDiv']//label[@class='chkbox_container']//span[@class='chkbox_checkmark']"));
					for (int i = 0; i < getList.size(); i++) {
						
						if(!getList.get(i).isSelected()) {

				MIQLog.info("Local Municipality selected areas list of all of the checkboxes should be deselected");
			} 
				
			else  {
				
				MIQLog.info("Failed to check the Local Municipality selected areas list of all of the checkboxes should be deselected");
				Assert.fail("Failed to check the Local Municipality selected areas list of all of the checkboxes should be deselected");
			}
			
		}
		}catch (Exception e) {
e.printStackTrace();
			ExceptionHandle.HandleException(e, "Failed to check the Local Municipality selected areas list of all of the checkboxes should be deselected");
		}
}
	@When("^Edit area pane should be displayed with warning$")
	public void checkEditMAOIPaneWarning() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.EditMaoi_PaneWarning, 20);
			MIQActionsClass.isElementVisible(MIQ_AreaOfInterestObjects.EditMaoi_PaneWarning, "EditMaoi_Pane");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Edit area pane with warning be displayed");
		}
	}
	
	@Then("^Verify selected \"([^\"]*)\" in the list of currently selected areas$")
	public void verify_selected_Local_Municipality_in_the_currently_selected_areas_list(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		try {

			Thread.sleep(3000);

			List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
					"//*[@id='callapse_City_of_Cape_Town']//label[@class='chkbox_container']//input[@type='checkbox']"));
			
			Boolean selected=false;
				for (int i = 0; i < getList.size(); i++) {
					if(getList.get(i).isSelected()) {
						selected = true;
						//System.out.println("Yes Very Sure.......");
					}
					//selected = true;
					//System.out.println("Yes Not Sure.......");

				}
			
				if(selected==false) {
					MIQLog.info("Failed to Validate the Current Selected Area List ");
					Assert.fail("Failed to Validate the Current Selected Area List ");
				}
				
			

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Validate the Current Selected Area List ");
		}
	}
	
	@Then("^Check \"([^\"]*)\" in the currently selected areas$")
	public void check_in_the_currently_selected_areas(String arg1) throws Throwable {
		  // Write code here that turns the phrase above into concrete actions
				try {

					Thread.sleep(3000);

					List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
							"//*[@id='callapse_City_of_Cape_Town']//label[@class='chkbox_container']//input[@type='checkbox']"));
							
					Boolean selected=false;
						for (int i = 0; i < getList.size(); i++) {
//							System.out.println(getList.size()+"size");
							if(!(getList.get(i).isSelected())) {
								selected = true;
								break;
								//System.out.println("Yes Very Sure.......");
							}
							//selected = true;
							//System.out.println("Yes Not Sure.......");

						}
					
						if(selected==false) {
							MIQLog.info("Failed to Validate the Current Deselected Area List");
							Assert.fail("Failed to Validate the Current Deselected Area List");
						}
						
					

				} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed to Validate the Current Deselected Area List ");
				}
	}

	

	@Then("^Check \"([^\"]*)\" pane is displayed$")
	public void check_pane_is_displayed(String arg1) throws Throwable {
		try {

			Thread.sleep(3000);
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.AreaOfInterest_Review_East_Pane,150);
			String Provided_text=arg1;
			  String Expected_text = MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.AreaOfInterest_Review_East_Pane,"Review Message");
			  assertEquals(Expected_text,Provided_text);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to check the Review East pane");
		}
	   
	}

	@And("^Click on \"([^\"]*)\" on Review Selection$")
	public static void clickSaveMunicipalAoiButtonOnReviewSelction(String arg1) throws Throwable {
		try {
			Thread.sleep(3000);
			Screen s=new Screen();
//			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+arg1+".PNG");
//			Thread.sleep(2000);
			s.click(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+arg1+".PNG");	
			MIQLog.info("The selected "+arg1+" Review Selection");
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the setMuncipalArea_SaveConfirm Button");
		}
	}


	@Then("^Verify user should be redirected back to the \"([^\"]*)\" East panel$")
	public void check_user_should_be_redirected_back_to_the_East_panel_areaOfInterest(String sAreaName) throws Throwable {
		try {
			//Thread.sleep(2000);
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.setMuncipal_EditAreaName_areasOfInterest, 5);
			String AreaNameField=MIQActionsClass.getElementText(MIQ_AreaOfInterestObjects.setMuncipal_EditAreaName_areasOfInterest, "Area Name Text");
			System.out.println(AreaNameField);
			Assert.assertEquals(AreaNameField, sAreaName);
		
		
		
	} catch (Exception e) {
		// TODO: handle exception
		MIQExceptionHandle.HandleException(e, "");
	}
	}
	@And("^Hover on select dropdown$")
	public static void hoverSelectDropdown() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.home_Default_Dropdown, 5);

			MIQActionsClass.mouseover(MIQ_AreaOfInterestObjects.home_Default_Dropdown);
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Hover the Profile dropdown ");
		}
	}

@And ("^Verify if dropdown contains \"(.*)\"$")
	public static void verifyDefault(String sDefaultValue) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_AreaOfInterestObjects.home_Default_Dropdown, 5);
			MIQActionsClass.mouseover(MIQ_AreaOfInterestObjects.home_Default_Dropdown);
			
			MIQActionsClass.isElementVisible((By.xpath(MIQ_AreaOfInterestObjects.defaultDropdown_Value1 + sDefaultValue + MIQ_AreaOfInterestObjects.defaultDropdown_Value2)),sDefaultValue);

			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to verfiy Default "); 
		}
	}

@And("^Click on \"(.*)\" on the dropdown list$")
	public static void clickDefault(String sDefault) throws Throwable {
		try {
			Thread.sleep(2000);

		//	MIQActionsClass.clickOnElement(MIQ_AreaOfInterestObjects.defaultDropdown, "Default Star");
			MIQActionsClass.clickOnElement((By.xpath(MIQ_AreaOfInterestObjects.defaultDropdown_Value1 + sDefault + MIQ_AreaOfInterestObjects.defaultDropdown_Value2)),sDefault);

			
	
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click the Default ");
		}
	}
	
}
