package MetroIQ_seleniumglucode;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;


import MIQ_accelerators.MIQActionsClass;
import MIQ_accelerators.MIQBase;
import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_AreaOfInterestObjects;
import MetroIQ_PageObjects.MIQ_PropertyListObjects;
import MetroIQ_PageObjects.MIQ_ReportHistoryObjects;
import MetroIQ_Utility.MIQExceptionHandle;
import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;
import accelerators.ActionsClass;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utility.ExceptionHandle;

import static org.junit.Assert.assertEquals;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class MIQ_CurrentReports {
	static String sGenarate  ;
	static String sDisable,sText;
	static Boolean CheckboxSelected;

	
	@Then("^Enter \"(.*)\" Current Report Description textbox$") 
	public void enterReportName(String sReportName) throws Throwable {
		try { 
			sGenarate=sReportName+MIQActionsClass.generateRandomString(3);
			MIQActionsClass.waitForElement(LoginObjects.reportPage_Description, 5);
			MIQActionsClass.typeInTextBox(LoginObjects.reportPage_Description,sGenarate , "Genarate Report");
			System.out.println(sGenarate);
		
			
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Enter Report Name");
			}
		}
@And("^Click on Create Current Report checkbox$")
	public void clickCheckBox() throws Throwable {
		try { 
			
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SpecifiedDateRange_Checkbox, 5);
		 MIQActionsClass.clickOnElement(LoginObjects.transferReprot_SpecifiedDateRange_Checkbox, "CheckBox");
			Thread.sleep(1000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click the check box");
			}
		}
@Then("^Check Check box will now be ticked$")
public void checkCheckboxTicked() throws Throwable {
    try {
        
        assertEquals(CheckboxSelected,true);
        
        } catch (Exception e) {
            MIQExceptionHandle.HandleException(e, "Failed to validate checkboxe");
        }
}
	@And("^Click on the \"(.*)\" button$") 
	public void clickGenarate(String sStr) throws Throwable {
		try { 
			MIQActionsClass.waitForElement(LoginObjects.reportPage_Genarate,5);
			MIQActionsClass.clickOnElement(LoginObjects.reportPage_Genarate,sStr);
			Thread.sleep(5000);
			
		}catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click Genarate button");
			}
		}
@And("^The user must see \"(.*)\" button$")
	public void displayRefineReport(String sRefine) throws Throwable{
		try {
			MIQActionsClass.waitForElement(LoginObjects.transferReport_Refine_Report,100);
			MIQActionsClass.isElementVisible(LoginObjects.transferReport_Refine_Report, sRefine);
			
		}catch(Exception e) {
			 MIQExceptionHandle.HandleException(e, "Failed to display refine button");
		}
	}
	@And("^Click on \"(.*)\" Icon$") 
	public void clickCurrentReport(String sReport) throws Throwable {
		try { 
		    MIQActionsClass.waitForElement(LoginObjects.reportPage_CurrentReports,25);
	        MIQActionsClass.clickOnElement(LoginObjects.reportPage_CurrentReports, sReport );
			Thread.sleep(1000);
			
		}catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click Current Report Icon");
			}
		}
	@And("^Verify the \"(.*)\" List grid is displayed$") 
	public void VerifyCurrent(String sVerify) throws Throwable {
		try { 
			 MIQActionsClass.isElementVisible(LoginObjects.transferReport_Description, "Description");
			 MIQActionsClass.isElementVisible(LoginObjects.transferReport_ReportType, "Report Type");
			 MIQActionsClass.isElementVisible(LoginObjects.transferReport_AreaOfInterest,"Area of Interest");
			 MIQActionsClass.isElementVisible(LoginObjects.transferReport_LastNotificationDate, "Notificaion");
			MIQActionsClass.isElementVisible(LoginObjects.transferReport_Enabled,"Enabled");
			MIQActionsClass.isElementVisible(LoginObjects.transferReport_New , "New");
			MIQActionsClass.isElementVisible(LoginObjects.transferReport_All , "All");
		MIQActionsClass.isElementVisible(LoginObjects.transferReport_Description, "Description");
	
		}catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Report list is not dispalyed");
			}
		}
@And("^Validate Report Name 77 has been created$")
	public static void verifyReportName() throws Throwable{
		try {
			
			List<WebElement> list = MIQActionsClass.getElements(LoginObjects.transferReport_VerifyCreated);
			for (WebElement sList : list) {
			 if (sList.getText().equalsIgnoreCase(sGenarate)) {
				 System.out.print("Succesfull created" + sGenarate);
				 break;
			 }
			}
			
			 }catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Report is not created");
			
		}
	}
@And("^Validate Report Name is visible on the Current List Report$")
	public static void displayReport() throws Throwable{
		
		try {
			
			if(MIQActionsClass.isElementVisible(LoginObjects.transferReport_VerifyCreated, sGenarate)) {
			
				MIQLog.info("The current report is displayed");
			}
			
		}catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Report is not displaying");
		}
	}

@Then("^Requestor should be navigated to the application homepage with the Title \"(.*)\"$") 
public void navigate(String sList) throws Throwable{
	try {
		 MIQActionsClass.waitForElement(LoginObjects.deleteReport_CurrentReport_expected, 5);
            MIQActionsClass.isElementVisible(LoginObjects.deleteReport_CurrentReport_expected,sList);
		
	}catch(Exception e){
		MIQExceptionHandle.HandleException(e, "user not able to navigated to the application homepage ");
	}
}
@And("^The current report list details should be displayed$") 
public void currentReportDetails() throws Throwable{
	try {
		MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_Description, "Description");
		 MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_ReportType, "Report Type");
		 MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_AreaOfInterest,"Area of Interest");
		 MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_LastNotificationDate, "Notificaion");
		MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_Enabled,"Enabled");
		MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_New , "New");
		MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_All , "All");
	MIQActionsClass.isElementVisible(LoginObjects.deletReport_transferReport_Description, "Description");
		Thread.sleep(3000);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "Current Report List failed to be displayed");
	}
}
@Then("^Select any report in the list and Click on \"(.*)\" link$") 
public static void clickDisable(String sl) throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.deleteReport_transferReport_Disable,200);
		 sDisable = MIQActionsClass.getElementText(LoginObjects.deleteReport_transferReport_Disable,sl);
		 System.out.println(sDisable);
		
		MIQActionsClass.clickOnElement(LoginObjects.deleteReport_transferReport_Click, sDisable);
		
		
	}catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "failed to click any report or disable link");
	}
}
@Then("^Confirm Report Deletion dialog will pop up$")
public void confirPopUp() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.deleteReport_transferReport_PopUp, 5);
		MIQActionsClass.isElementVisible(LoginObjects.deleteReport_transferReport_PopUp, "Pop Up message");
		
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "Dialog did not pop up");
	}
}
@And("^Validate confirm and cancel button is visible$")
public void validateConfirmCancel() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.deleteReport_transferReport_Validate,5);
		MIQActionsClass.isElementVisible(LoginObjects.deleteReport_transferReport_Validate, "Confirm and Cancel");
		
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "Confirm and cancel button are not displayed");
	}
}
@Then("^Click on \"(.*)\" on the dialog$") 
public void clickConfirm(String sConfirm) throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.deleteReport_transferReport_Confirm,5);
	 MIQActionsClass.clickOnElement(LoginObjects.deleteReport_transferReport_Confirm, sConfirm);
		Thread.sleep(1000);
		
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "You failed to click confirm button");
	}
}
@And("^Notification will inform User that Current Report Deleted$")
public void userNotification() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.deleteReport_transfer_Notification, 5);
		MIQActionsClass.isElementVisible(LoginObjects.deleteReport_transfer_Notification, "Notification");
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "Notification is not displaying");
	}
}
@And("^Click on \"(.*)\" button on the dialog$") 
public void clickOk(String sOk) throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.deleteReport_transfer_OK, 5);
		MIQActionsClass.clickOnElement(LoginObjects.deleteReport_transfer_OK,sOk);
		Thread.sleep(5000);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "You failed to click OK button");
	}
}
@Then("^User disabled should not be on the list$") 
public void userDisabled()throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.deleteReport_transfer_Deleted, 5);
		
		 List<WebElement> list = MIQActionsClass.getElements(LoginObjects.deleteReport_transfer_Deleted) ;
	 for(WebElement el : list) {
		if(!(el.getText().equalsIgnoreCase(sDisable))) {
		
				 
				 MIQLog.info("The user succesfull disable the report"  + sDisable);
                }
//                else {
//                    Assert.fail("Failed to disabled the report "+ sDisable );
//                    MIQLog.info("Failed to disabled the report" + sDisable);
//                }
			 }
		 }
	catch(Throwable e) {
		e.printStackTrace();
	}
}
@Then("^Validate \"(.*)\" for Current Report List$") 
public void veriLastDate(String lastNotification) throws Throwable{
	try {
		String lastDate = MIQActionsClass.getElementText(LoginObjects.viewNewUpdates_transferReport_veriGet, "last date Notification");
		System.out.print(lastDate);
		assertEquals(lastNotification, lastDate);
		Thread.sleep(1000);
	
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to Validate if Message is displayed");
	}
}
@Then("^The \"(.*)\" is visible$") 
public static void lastNotification(String lastN) throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.viewNewUpdates_transferReport_visible, 5);
		MIQActionsClass.isElementVisible(LoginObjects.viewNewUpdates_transferReport_visible, lastN);
	}catch(Exception e) {
		
	}
}

@And("^Click on any link at \"(.*)\" records column$") 
public void clickAll(String sAll) throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_click, 25);
		MIQActionsClass.clickOnElement(LoginObjects.viewAllUpdates_transferReport_click,sAll);
		Thread.sleep(10000);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"User fail to click a link in All recods column");
	}
}
@Then("^All updates details that happens ever since the Current report was created should be displayed$") 
public void allpagedetails() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_clickPage, 5);
		MIQActionsClass.isElementVisible(LoginObjects.viewAllUpdates_transferReport_clickPage, "details");
		Thread.sleep(3000);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to show details report");
	}
}
@And("^Verify that the page contains Reports$")
public void pageContains() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_Official, 10);
		MIQActionsClass.isElementVisible(LoginObjects.viewAllUpdates_transferReport_Official, "Official description");
		MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_ErfPotion, 10);
		MIQActionsClass.isElementVisible(LoginObjects.viewAllUpdates_transferReport_ErfPotion, "Erf Portion");
		MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_FarmName,10);
		MIQActionsClass.isElementVisible(LoginObjects.viewAllUpdates_transferReport_FarmName, "Fram Name");
		MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_Street,10);
		MIQActionsClass.isElementVisible(LoginObjects.viewAllUpdates_transferReport_Street, "Street Name");
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "failed to vify any report ");
	}
}
@And("^Validate At list one report amongst list should be displayed on the page$") 
public void validateDisplay() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_validateDispla, 5);
		MIQActionsClass.isElementVisible(LoginObjects.viewAllUpdates_transferReport_validateDispla, "verify Display");
		Thread.sleep(2000);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "failed to vify atleast one report is displayed ");	
	}
}
@And("^Click \"(.*)\" icon$")
public void clickCurrent(String sCurrent) throws Throwable{
    try {
    MIQActionsClass.waitForElement(LoginObjects.deleteReport_CurrentReport, 5);
    MIQActionsClass.clickOnElement(LoginObjects.deleteReport_CurrentReport, sCurrent);
    Thread.sleep(1000);
}catch(Exception e) {
    MIQExceptionHandle.HandleException(e, "Failed to delete Report");
 }
}

@Then("^Verify the \"(.*)\" is displayed$")
public void reportDisplay(String sReport) throws Throwable{
    try {
        MIQActionsClass.waitForElement(LoginObjects.deleteReport_CurrentReport_Displayed, 5);
        MIQActionsClass.isElementVisible(LoginObjects.deleteReport_CurrentReport_Displayed, sReport);
        
    }catch(Exception e) {
        MIQExceptionHandle.HandleException(e,"The Current Report List is not displaying");
    }
}

@And("^user should see Refine button$")
public void userRefinery() throws Throwable{
    try {
        MIQActionsClass.waitForElement(LoginObjects.viewAllUpdates_transferReport_Refine, 25);
        MIQActionsClass.isElementVisible(LoginObjects.viewAllUpdates_transferReport_Refine, "Refine Button");
    }catch(Exception e) {
        MIQExceptionHandle.HandleException(e, "failed to display refine button ");
    }
}
@And("^Click on \"(.*)\" item$")
public void clickReportIcon(String sReport) throws Throwable {
    try {
        
        MIQActionsClass.waitForElement(LoginObjects.transferReport, 5);
        MIQActionsClass.clickOnElement(LoginObjects.transferReport, sReport);
            
    } catch (Exception e) {
         MIQExceptionHandle.HandleException(e, "Failed to click Transfer Report");
    }
    
 }


@And("^Requestor should be navigated to application homepage with the Title \"([^\"]*)\"$") 
public void navigateHistory(String sHistory) throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.transferReport_History_navigate, 5);
		String historyPage = MIQActionsClass.getElementText(LoginObjects.transferReport_History_navigate, sHistory);
		Assert.assertEquals(historyPage, sHistory);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"Failed to navigate into  Report History page");	
	}
}
@Then("^Select any user on the list and Click on \"(.*)\" link$") 
public void clickLink(String sLink) throws Throwable{
	try {

		MIQActionsClass.waitForElement(LoginObjects.transferReport_History_clickLink, 5);
		MIQActionsClass.clickOnElement(LoginObjects.transferReport_History_clickLink, sLink);
		
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"Failed to click Create Report link");	
	}
}

@And("^The \"(.*)\" dialog will pop up$") 

public void createPopUp(String sPopUp) throws Throwable{
	try {
		String sMessage = MIQActionsClass.getElementText(LoginObjects.transferReport_History_PopUp, sPopUp);
		 Assert.assertEquals(sMessage, sPopUp);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"New current Report Pop Up message Failed to Pop Up");	
	}
}
@Then("^Enter \"(.*)\" in the dialog$")
public void enterText(String sReport) throws Throwable{
	try {
		sText=sReport + MIQActionsClass.generateRandomString(4);
		MIQActionsClass.waitForElement(LoginObjects.transferReport_History_textArea, 5);
		MIQActionsClass.typeInTextBox(LoginObjects.transferReport_History_textArea, sText, "Report");
	
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"Failed to enter text in text area field");
	}
}
@Then("^Click on confirm button on the dialog$") 
public void confirmButton() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.transferReport_History_Confirm,5);
		MIQActionsClass.clickOnElement(LoginObjects.transferReport_History_Confirm, "Confirm");
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"Failed to click confirm button");	
	}
}
@And("^Notification will inform User that \"([^\"]*)\"$")
public void Notiification(String sNotification) throws Throwable{
	try {
		String sNotif = MIQActionsClass.getElementText(LoginObjects.transferReport_History_Notification, sNotification);
		Assert.assertEquals(sNotif, sNotification);
		
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"Failed to show notifications");		
	}
}

@Then("^verify that the report is created$") 
public static void verifyCreatedReport() throws Throwable {
	try {
		MIQActionsClass.waitForElement(LoginObjects.transferReport_History_Verify, 5);
		MIQActionsClass.isElementVisible(LoginObjects.transferReport_History_Verify, "Verify Report");
		
		}catch(Exception e) {
			MIQExceptionHandle.HandleException(e,"Failed to show that the report created succesfull");	
		}
	}
@And("^Click OK button on the dialog$") 
public void clickOk() throws Throwable{
	try {
		MIQActionsClass.waitForElement(LoginObjects.transferReport_History_clickOk,5);
		MIQActionsClass.clickOnElement(LoginObjects.transferReport_History_clickOk,"OK button");
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e,"Failed to click Ok button");
	}
}


@Then("^Verify the report name is available in the list$") 
public void reportNameVisibility() throws Throwable{
	try {
		 if (MIQActionsClass.isElementVisible(LoginObjects.transferReport_History_ReportsName, sText)) {
				MIQLog.info("The current report is displayed in the current list");
		 }
			 
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "The Report name is not displayed in the list ");
	}
}
@And("^Validate the Report name in the list which is created using Step 4 and 5$")
public void validateReport() throws Throwable{
    MIQActionsClass.waitForElement(LoginObjects.transferReport_History_ReportsName, 25);
    
     List<WebElement> list = MIQActionsClass.getElements(LoginObjects.transferReport_History_ReportsName) ;
 for(WebElement el : list) {
    if((el.getText().equalsIgnoreCase(sText))) {
    
             
             MIQLog.info("The report is available on the report lis"  + sText);
          }
          else {
              Assert.fail("The  report does not exist "+ sText );
              MIQLog.info("The  report does not exist " + sText);
           }
          }
    }

@Then("^Verify the number of items \"([^\"]*)\" per page in \"([^\"]*)\"$")
public void numberOFItemsPerPage(String sValue, String arg2) throws Throwable {
	try {
		Thread.sleep(5000);
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.CurrentReportsFooter, 25);
		String footer=MIQActionsClass.getElementText(MIQ_PropertyListObjects.CurrentReportsFooter, "footer");
		System.out.println(footer);
		String[] footerValue=footer.split(" ");
		String pagination=footerValue[1]+"-"+footerValue[3];
		
		System.out.println(pagination);
		Assert.assertEquals(pagination, sValue);
			 
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to verify the number of items "+sValue);
	}
}

@Then("^Click on \"([^\"]*)\" pagination link for \"([^\"]*)\"$")
public void clickPaginationLink(String sOption, String arg2) throws Throwable {
	try {
		if(sOption.equalsIgnoreCase("Next")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.CurrentReportsLeftPagination, 25);	
		MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.CurrentReportsLeftPagination, "LeftPagination");
		} 
		else if(sOption.equalsIgnoreCase("Last")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.CurrentReportsLastPagination, 5);	
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.CurrentReportsLastPagination, "LastPagination");
			Thread.sleep(10000);
		}
		else if(sOption.equalsIgnoreCase("First")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.CurrentReportsFirstPagination, 5);	
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.CurrentReportsFirstPagination, "FirstPagination");
			Thread.sleep(10000);
		}
		else if(sOption.equalsIgnoreCase("Prev")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.CurrentReportsPrevPagination, 5);	
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.CurrentReportsPrevPagination, "PrevPagination");
		}
		Thread.sleep(20000);
	} catch (Exception e) {
		e.printStackTrace();
		MIQExceptionHandle.HandleException(e, "Failed to Click on "+sOption+" Pagination link");
		}
}
@Then("^Click on the triangle icon for any record and it should expand$")
public void clickTriangleIcon() throws Throwable {
	try {
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentReports_TriangleIcon, 5);	
		MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.currentReports_TriangleIcon, "PrevPagination");
		MIQActionsClass.isElementVisible(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar, "")	;
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "The Report name is not displayed in the list ");
	}
}

@Then("^Verify the \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" for the Expanded item$")
public void verify_the_and_for_the_Expanded_item(String sFilterType, String sFilterParameter, String sCaptureDate, String sPropertyType, String sAreaofInterest, String sLastNotification) throws Throwable {
	try {
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_FilterType, 5);	
		String FilterType =	MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_FilterType, "Filter Type");
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_FilterParameter, 5);	
		String FilterParameter=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_FilterParameter, "Filter Parameter");
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_CaptureDate, 5);	
		String CaptureDate=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_CaptureDate, "CaptureDate").trim();
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_PropertyType, 5);	
		String PropertyType=MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_PropertyType, "Property Type");
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_AreaOfInterest, 5);	
		String AreaofInterest=MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_AreaOfInterest, "Area of Interest");
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_LastNotificationDate, 5);	
		String LastNotification=MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentReports_TriangleIcon_ExpandableBar_LastNotificationDate, "Last Notification");
		assertEquals(FilterType, sFilterType);
		assertEquals(FilterParameter, sFilterParameter);
		assertEquals(CaptureDate, sCaptureDate);
		assertEquals(PropertyType, sPropertyType);
		assertEquals(AreaofInterest, sAreaofInterest);
		assertEquals(LastNotification, sLastNotification);
	}catch(Exception e) {
		MIQExceptionHandle.HandleException(e, "The Report name is not displayed in the list ");
	}
}

@Then("^Check the validation \"([^\"]*)\" message \"([^\"]*)\" in \"([^\"]*)\"$")
public void check_the_validation_message_in(String sValue, String sMessage, String arg3) throws Throwable {
    try {
        
        //sMessage= "TransferReport "+sGenarate+" "+sMessage;
        sMessage= sValue+sGenarate+" "+sMessage;
        System.out.println(sMessage);
           MIQActionsClass.waitForElement(LoginObjects.transferReprot_GenerateReport_Error_Message, 10);
            String Text = MIQActionsClass.getElementText(LoginObjects.transferReprot_GenerateReport_Error_Message,sMessage );
           assertEquals(Text,sMessage);
    } catch (Exception e) {
        MIQExceptionHandle.HandleException(e, "Failed to check User should be direced to theb"+sMessage+ " page");
    }
}
@Then("^Click on \"([^\"]*)\"checkbox in \"([^\"]*)\" page$")
public void click_on_checkbox_in_page(String arg1, String arg2) throws Throwable {
	try { 
		
		MIQActionsClass.waitForElement(LoginObjects.transferReport_OfflineProcess_Checkbox, 5);
	 MIQActionsClass.clickOnElement(LoginObjects.transferReport_OfflineProcess_Checkbox, "CheckBox");
		Thread.sleep(1000);
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to click the offline process check box");
		}
}
@Then("^Check the text in Current Report Description textbox$")
public void check_the_text_in_Current_Report_Description_textbox() throws Throwable {
	try { 
	
	   MIQActionsClass.waitForElement(LoginObjects.reportPage_Description, 5);
		String Text = MIQActionsClass.getAttribute(LoginObjects.reportPage_Description, "value","AddedEquipment");   
        assertEquals(Text,sGenarate);
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to click the offline process check box");
		}
}
@When("^Verify the \"([^\"]*)\" results table$")
public void verify_the_results_table(String arg1) throws Throwable {
	try { 
		MIQActionsClass.isElementVisible(MIQ_ReportHistoryObjects.offlineProcess_ResultsTable, "Results Table");
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to c");
			}
}

@When("^Validate report name which is generated in \"([^\"]*)\" page and status is \"([^\"]*)\" at \"([^\"]*)\" results table$")
public void validate_report_name_which_is_generated_in_page_and_status_is_at_results_table(String arg1, String sStatus, String arg3) throws Throwable {
	try {
		
		String status= MIQActionsClass.getElementText(By.xpath(MIQ_ReportHistoryObjects.offlineProcess_ResultsTable_Status1+sGenarate+MIQ_ReportHistoryObjects.offlineProcess_ResultsTable_Status2), "Status");
		assertEquals(status,sStatus);
		List<WebElement> list = MIQActionsClass.getElements(MIQ_ReportHistoryObjects.offlineProcess_ResultsTable_Description_List);
		for (WebElement sList : list) {
		 if (sList.getText().equalsIgnoreCase(sGenarate)) {
			 System.out.print("Succesfull created" + sGenarate);
			 break;
		 }
		
		
		
		 }
	}catch(Exception e) {
		e.printStackTrace();
		MIQExceptionHandle.HandleException(e, "Report is not created");
		
	}

}}


