package MetroIQ_seleniumglucode;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.cucumber.MIQlistener.MIQReport;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
//import guaranteeHub_utility.MIQExceptionHandle;

import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_AreaOfInterestObjects;
//import winDeed_utility.MIQExceptionHandle;
//import winDeed_utility.WDUtils;
import MIQ_accelerators.MIQBase;
import MIQ_accelerators.MIQActionsClass;
import MetroIQ_Utility.MIQLog;

import MetroIQ_Utility.MIQUtils;
//import accelerators.MIQActionsClass;
import MetroIQ_Utility.MIQExceptionHandle;


public class MIQ_Login {
	static WebDriver newdriver = MIQBase.driver;
	static String winHandleBefore ;
	static String winHandleAfter ;
	
	
	@Before
	public void setUp() throws Exception {
		try {

			DOMConfigurator.configure(System.getProperty("user.dir") + "\\MetroIQData\\log4j.xml");
			MIQActionsClass.sTestCaseName = this.toString();
			MIQActionsClass.sTestCaseName = MIQUtils.getTestCaseName(MIQActionsClass.sTestCaseName);
			MIQLog.startTestCase(MIQActionsClass.sTestCaseName);

		} catch (Exception e) {
			MIQLog.info(e.getMessage());
		}
	}

	@Given("^Launch MetroIQ Browser$")
	public static void launchWindeedTheBrowse() throws Throwable {
try {
			newdriver=MIQBase.OpenBrowser();
			newdriver=MIQBase.driver;
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e,"Failed to launch the browser");
		}
	}
	@Given("^I am on the MetroIQ login page$")
	public void NavigatetoWinDeedURL() throws Throwable {
		try {
			String url = MIQUtils.getProperty("Application_URL");	
			newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
			newdriver.get(url);
			Thread.sleep(1000);
		//	ActionsClass.waitForElement(AccountsObjects.loginUsername_TxtBox,5);

		}catch (Exception e) {
//e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to launch MetroIQ screen");
		}
	}
	@When("^Enter email id \"([^\"]*)\" and Password \"([^\"]*)\"$")
	public void getusername(String sEmail, String sPassword) {
		try {
			String email = MIQUtils.getProperty(sEmail);
			String password = MIQUtils.getProperty(sPassword);
			MIQActionsClass.waitForElement(LoginObjects.email, 3);
			MIQActionsClass.typeInTextBox(LoginObjects.email, email, "Username text field");
			MIQActionsClass.waitForElement(LoginObjects.password, 3);
			MIQActionsClass.typeInTextBox(LoginObjects.password, password, "pASSWORD text field");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter Username");
		}
	}

	@And("^Click on Login button in MetroIQ$")
	public static void clickLogin() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.login_submit, 10);
			MIQActionsClass.clickOnElement(LoginObjects.login_submit, "Login button");
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on Login button");
		}
	}

	@And("^Verify the login error message \"([^\"]*)\"$")
	public static void verifyLoginErrorMessage(String errorMessage) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.login_error, 5);
			String Error=MIQActionsClass.getElementText(LoginObjects.login_error, "Error message");
			Assert.assertEquals(Error, errorMessage);
			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Verify the login error message");
		}
	}

	@Then("^Refresh the MeroIQ Login page$")
	public void refershThePage() throws Throwable {
		try {
			
			newdriver.navigate().refresh();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Refresh the page");
		}

	}
	
	@Then("^User should be successfully loggedin to see the landing page$")
	public void userLandingPage() throws Throwable {
		
			try {
				MIQActionsClass.waitForElement(LoginObjects.login_UserProfile, 5);
				
				//newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
				if(MIQActionsClass.isElementVisible(LoginObjects.login_UserProfile, "User Profile")) {
					MIQLog.info("User should be successfully loggedin to see the landing page");
				}
				else {
					Assert.fail("Failed to check User should be successfully loggedin to see the landing page");
					MIQLog.info("Failed to check User should be successfully loggedin to see the landing page");
				}	

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check User should be successfully loggedin to see the landing page");
		}
	}

	@Then("^User should be directed to the \"([^\"]*)\" page$")
	public void userDirectedPage(String sModule) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.mapView, 150);
			
			if(MIQActionsClass.isElementVisible(LoginObjects.mapView, "MapView")) {
				MetroIQ_Utility.MIQLog.info("User should be direced to the "+sModule+ " page" );
			}
			else {
				Assert.fail("Failed to check User should be direced to theb"+sModule+ " page");
				MIQLog.info("Failed to check User should be direced to theb"+sModule+ " page");
			}	

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check User should be direced to theb"+sModule+ " page");
		}
	}
	
	@And("^Click on \"([^\"]*)\" link and it should be navigated to \"([^\"]*)\" page$")
	public void clickChangePassword(String sForgotPassword, String sForgot) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.login_UserName_TxtField, 5);
			MIQActionsClass.clickOnElement(LoginObjects.login_ForgotPassword_Link, " Forgot Password link");
			MIQActionsClass.waitForElement(LoginObjects.forgotPassword_Email_TxtField, 5);
			String sForgotPasswordPage=MIQActionsClass.getElementText(LoginObjects.forgotPassword_Page, " Forgot Password page");
			if(sForgotPasswordPage.equalsIgnoreCase(sForgot)) {
			MIQLog.info("User clicked on " +sForgotPassword+ "and it navigated to" +sForgot+ " page");
			}
			else {
				MIQLog.info("failed to clicked on " +sForgotPassword+ "and it navigated to" +sForgot+ " page");
				Assert.fail("failed to clicked on " +sForgotPassword+ "and it navigated to" +sForgot+ "page");
			}
			
		}catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "failed to clicked on " +sForgotPassword+ "and it navigated to" +sForgot+ " page");
		}
		
	}
	@Given("^Enter a \"([^\"]*)\" email id \"([^\"]*)\" at \"([^\"]*)\" page$")
	public void enterChangePasswordEmail(String arg1, String sEmail, String arg3) throws Throwable {
		try {
			String email = MIQUtils.getProperty(sEmail);
			MIQActionsClass.waitForElement(LoginObjects.forgotPassword_Email_TxtField, 3);
			MIQActionsClass.typeInTextBox(LoginObjects.forgotPassword_Email_TxtField, email, "Forgot paswoord Email text field");	

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter Username");
		}
	}


	@And("^Click on \"([^\"]*)\" button at \"([^\"]*)\" page$")
	public void clickOnSubmit(String sButton, String sPage) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.forgotPassword_RequstLink_Button, 5);
			MIQActionsClass.clickOnElement(LoginObjects.forgotPassword_RequstLink_Button, " Request Link");
			Thread.sleep(3000);
			
		

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to click on "+sButton+" at" +sPage+ " page");
		}
	}
	
	
	@Then("^Notification message should be displayed \"([^\"]*)\"$")
	public void notificationMessageDisplayed(String sMessage) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.forgotPassword_Email_TxtField, 10);
			String sNotificationMessage=MIQActionsClass.getElementText(LoginObjects.forgotPassword_Notificatin_Message, " Notification Message");
			Thread.sleep(3000);
			assertEquals(sNotificationMessage,sMessage);
		

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Notification message should be displayed " +sMessage);
		}
	}
	
	

	@Then("^Close the Browser$")
	public void close_the_Browser() throws Throwable {
		try {
			newdriver.close();	

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to close the browser");
		}
	}

	@Then("^Login into webmail \"([^\"]*)\" using Username \"([^\"]*)\" password \"([^\"]*)\"$")
	public void login_into_webmail_using_Username_password(String sUrl, String sUser, String sPassword) throws Throwable {
		Thread.sleep(3000);
		try {
			sUser = MIQUtils.getProperty(sUser);
			sPassword = MIQUtils.getProperty(sPassword);

			MIQActionsClass.launchAnApplication(sUrl);
			//To identify onyx login page
			MIQActionsClass.waitForElement(By.xpath("//img[@class='main-logo']"),10);
			
			MIQActionsClass.waitForElement(LoginObjects.webmail_UserTxtBox,5);
			MIQActionsClass.typeInTextBox(LoginObjects.webmail_UserTxtBox,sUser,sUser+" User Name");
			MIQActionsClass.typeInTextBox(LoginObjects.webmail_PasswordTxtBox,sPassword,sPassword+" Password");
			MIQActionsClass.clickOnElement(LoginObjects.webmail_loginBtn, " Login Button");
			Thread.sleep(1000);
			//This will display only when we use new emails
			try {
				if(newdriver.findElement(LoginObjects.webmail_GotItButton).isDisplayed()) {
					MIQActionsClass.clickOnElement(LoginObjects.webmail_GotItButton, " Got It Button");
				}
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			//This will display only when we use new emails
			try {

				if(newdriver.findElement(LoginObjects.webmail_RoundCubeSetasDefault).isDisplayed()) {
					MIQActionsClass.clickOnElement(LoginObjects.webmail_RoundCubeSetasDefault, " Round cube set as default link");
					Thread.sleep(500);
					MIQActionsClass.clickOnElement(LoginObjects.webmail_RoundCubeBlock, " Round cube");
					Thread.sleep(1000);
				}

			}
			catch (Exception e) {
				//e.printStackTrace();
			}
			MIQActionsClass.switchToFrameByObj(LoginObjects.webmail_EmailFrame);
			MIQActionsClass.waitForElement(By.xpath("//a[@rel='INBOX']"), 5);
			MIQActionsClass.clickOnElement(By.xpath("//a[@rel='INBOX']"), "Inbox Link");
			Thread.sleep(1000);

		}
		catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to login into web mail");
		}
	}

	@Then("^Open \"([^\"]*)\" email from webmail$")
	public void openEmailFromWebmail(String sMailType) throws Throwable {
		try {
			By obj=null;
			/*ActionsClass.clickOnElement(By.xpath("//*[@title='Check for new messages']"), "Refresh");
			Thread.sleep(1500);*/
			Thread.sleep(30000);
			if(sMailType.equalsIgnoreCase("Reset Password")) {
				obj=LoginObjects.webmail_ResetPasswordEmail;
			}		
			else if(sMailType.equalsIgnoreCase("Registration")){
				obj=LoginObjects.webmail_RegistrationEmail;
			}
			else if(sMailType.equalsIgnoreCase("User Not Found")){
				obj=LoginObjects.webmail_UserNotFound;
			}
			MIQActionsClass.doubleClick(obj, "Open mail");
			Thread.sleep(500);
			MIQActionsClass.clickOnElement(By.xpath("//a[@id='messagemenulink' and text()='More']"), "More link");
			Thread.sleep(500);
			MIQActionsClass.jsClickOnElement(By.xpath("//span[text()='Open in new window']"), " Open in new window");
			for (String winHandle : newdriver.getWindowHandles()) {
				newdriver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
			}
			//newdriver.switchTo().frame(newdriver.findElement(LoginObjects.webmail_EmailFrame));
			/*try {
				if(newdriver.findElement(obj).isDisplayed()) {
					ActionsClass.doubleClick(obj, "Open mail");
				}
			}
			catch (Exception e) {
				Assert.fail("Failed to click on "+sMailType+" email link");
			}*/
			Thread.sleep(1000);
		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Unable to open mail");
		}
	}

	@Then("^Click on the unique link in the change password email and it should be navigated to \"([^\"]*)\" page$")
	public void clickResetpasswordLink(String sReset) throws Throwable {
		try {
			 winHandleBefore = newdriver.getWindowHandle();
			MIQActionsClass.waitForElement(LoginObjects.webmail_PasswordReset_Link, 5);
			MIQActionsClass.clickOnElement(LoginObjects.webmail_PasswordReset_Link, " Request Link");
			for (String winHandle : newdriver.getWindowHandles()) {
				newdriver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
				//newdriver.switchTo().window("Lexis®Nexis");
			}

			String sResetPasswordPage=MIQActionsClass.getElementText(LoginObjects.forgotPassword_Page, " Reset Password page");
			if(sResetPasswordPage.equalsIgnoreCase(sReset)) {
			MIQLog.info("User clicked on " +sResetPasswordPage+ "and it navigated to" +sReset+ " page");
			}
			else {
				MIQLog.info("failed to clicked on " +sResetPasswordPage+ "and it navigated to" +sReset+ " page");
				Assert.fail("failed to clicked on " +sResetPasswordPage+ "and it navigated to" +sReset+ "page");
			}

			Thread.sleep(1500);
		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to click on password reset link");
		}
	}

	@Then("^I enter value \"([^\"]*)\" in New Password and in \"([^\"]*)\" Confirm Password text field at \"([^\"]*)\" page$")
	public void resetPasswordPage(String sNewPassword, String sConfirmPassword, String sarg3) throws Throwable {
		try {
			sNewPassword = MIQUtils.getProperty(sNewPassword);
			 sConfirmPassword = MIQUtils.getProperty(sConfirmPassword);
			MIQActionsClass.waitForElement(LoginObjects.resetPassword_NewPassword_TxtField, 3);
			MIQActionsClass.typeInTextBox(LoginObjects.resetPassword_NewPassword_TxtField, sNewPassword, "New Password text field");
			MIQActionsClass.waitForElement(LoginObjects.resetPassword_ConfirmPassword_TxtField, 8);
			MIQActionsClass.typeInTextBox(LoginObjects.resetPassword_ConfirmPassword_TxtField, sConfirmPassword, "Confirm Password text field");

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to enter Username");
		}
	}
	@Then("^Click on \"([^\"]*)\" link and should be directed to the Login page$")
	public void clickReturnToLogin(String arg1) throws Throwable {
		try {
		MIQActionsClass.waitForElement(LoginObjects.webmail_PasswordReset_Link, 5);
		MIQActionsClass.clickOnElement(LoginObjects.webmail_PasswordReset_Link, " Request Link");
		
		//Thread.sleep(1000);
		//newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
		if(MIQActionsClass.isElementVisible(LoginObjects.login_UserName_TxtField, "Username Textbox")) {
			utility.Log.info("User navigated back to login screen:");
		}
		else {
			Assert.fail("Failed to navigate to Lexis login screen");
			MIQLog.info("Failed to navigate to Lexis login screen");
		}	
	}catch (Exception e) {

		MIQExceptionHandle.HandleException(e, "Failed to navigate to Lexis login screen");
	}
	}
	@Given("^Switch back to original browser$")
	public void switch_back_to_original_browser() throws Throwable {
		try {
			newdriver.close();
			newdriver.switchTo().window(winHandleBefore);
		}catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to navigate to Lexis login screen");
		}
	}
	
	@Then("^Click on \"([^\"]*)\" on Webmail and user should receive a password updated successfully email$")
	public void clickInboxemail(String arg1) throws Throwable {
	
		try {
			MIQActionsClass.switchToFrameByObj(LoginObjects.webmail_EmailFrame);
			MIQActionsClass.waitForElement(By.xpath("//a[@rel='INBOX']"), 5);
			MIQActionsClass.clickOnElement(By.xpath("//a[@rel='INBOX']"), "Inbox Link");
			MIQActionsClass.isElementVisible(LoginObjects.webmail_ResetPasswordEmail, "PasswordUpdatedMessage");
			
		}catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to navigate to Lexis login screen");
		}
	}
	
	@Then("^Search for \"([^\"]*)\" in webmail$")
	public void searchWebmail(String sText) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.webmail_Search_TextField, 3);
			MIQActionsClass.typeInTextBox(LoginObjects.webmail_Search_TextField, sText, "Webmail Search Text field");
			newdriver.findElement(By.id("quicksearchbox")).sendKeys(Keys.ENTER);
		
		}catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to searchf for" +sText+ "in webmail");
		}
	}
	

	
	@And("^\"([^\"]*)\" is displayed in red color$")
	public void VerifyFieldsInRedColor(String sFieldName) throws Throwable {
		try {

			String sColor = "";
			if(sFieldName.equalsIgnoreCase("ErrorMessage")){
				sColor = MIQActionsClass.getCssValue(LoginObjects.login_error, "color",
						"ErrorMesage");
			}
			System.out.println(sColor + "scolor");
			String[] split = sColor.split("\\(");
			sColor = split[1];
			System.out.println(sColor + "split");
			// Convert rgd color to hexa
			sColor = MIQActionsClass.convertRGBtoHexa(sColor);
			System.out.println(sColor);
			if (sColor.equalsIgnoreCase("#e41b22")) {
				utility.Log.info("Fields are highlighted in red");

			} else {
				Assert.fail(sFieldName + " field is not highlighted in red");
				utility.Log.info(sFieldName + " field is not highlighted in red");
			}
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to verify " + sFieldName + " is in red color");
		}
	}
	
	@And("^Click on ContactUs link$")
	public static void clickContactUS() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.ContactUs_Link, 10);
			MIQActionsClass.clickOnElement(LoginObjects.ContactUs_Link, "ContactUs_Link");
			MIQActionsClass.waitForElement(LoginObjects.contactUs_Send_Button, 10);
//			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on ContactUS");
		}
	}
	
	@When("^Enter contact details Name \"([^\"]*)\" , Email Address \"([^\"]*)\" , Contact Number \"([^\"]*)\" , Comments \"([^\"]*)\"$")
	public void EnterContactDetails(String sName, String sEmail,String sNumber,String sComments) {
		try {
			String email = MIQUtils.getProperty(sEmail);
			String name = MIQUtils.getProperty(sName);
			String number = MIQUtils.getProperty(sNumber);
			String comments = MIQUtils.getProperty(sComments);
			MIQActionsClass.typeInTextBox(LoginObjects.contactUs_Name_TxtField, name, "name text field");
			
			MIQActionsClass.typeInTextBox(LoginObjects.contactUs_Email_TxtField, email, "email text field");
			MIQActionsClass.typeInTextBox(LoginObjects.contactUs_ContactNumber_TxtField, number, "number text field");
			MIQActionsClass.typeInTextBox(LoginObjects.contactUs_Comments_TxtField, comments, "email text field");
			

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter Username");
		}
	}
	
	@And("^Click on Reset link in contactUS page$")
	public static void clickResetContactUS() throws Throwable {
		try {
			
			MIQActionsClass.clickOnElement(LoginObjects.contactUs_Reset_Link, "contactUs_Reset_Link");
			
//			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on contactUs_Reset_Link");
		}
	}
	
	@And("^Verify the Contact detils erased or not$")
	public static void verifyEmptyContactDetails() throws Throwable {
		try {
			String name=MIQActionsClass.getAttribute(LoginObjects.contactUs_Name_TxtField, "value", "name");	
			String email=MIQActionsClass.getAttribute(LoginObjects.contactUs_Email_TxtField, "value", "email");			
			String number=MIQActionsClass.getAttribute(LoginObjects.contactUs_ContactNumber_TxtField, "value", "number");			
			String comments=MIQActionsClass.getAttribute(LoginObjects.contactUs_Comments_TxtField, "value", "comments");			
			Assert.assertTrue(name.equalsIgnoreCase(""));
			Assert.assertTrue(email.equalsIgnoreCase(""));
			Assert.assertTrue(number.equalsIgnoreCase(""));
			Assert.assertTrue(comments.equalsIgnoreCase(""));
//			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on contactUs_Reset_Link");
		}
	}
	
	@And("^Click on Send in ContactUs$")
	public static void clickSendContactUS() throws Throwable {
		try {
			
			MIQActionsClass.clickOnElement(LoginObjects.contactUs_Send_Button, "contactUs_Send_Button");
			
//			Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on contactUs_Send_Button");
		}
	}
	
	@And("^verify the alert message for contact details \"([^\"]*)\"$")
	public static void verifyAlertMessage(String sAlertmessage) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.waitForElement(LoginObjects.contactUs_Popup_Dialog_OK_Button, 5);
			String Alert=	MIQActionsClass.getElementText(LoginObjects.contactUs_Popup_Dialog, "Contact us Dialog box");		
			System.out.println(Alert);
			Assert.assertEquals(Alert, sAlertmessage);
			MIQActionsClass.clickOnElement(LoginObjects.contactUs_Popup_Dialog_OK_Button, "contactUs_Ok_Button");
//			Thread.sleep(3000);contactUs_Popup_Dialog_OK_Button
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to click on contactUs_Send_Button");
		}
	}
	
	@Given("^Click on the \"([^\"]*)\" in the bottom \"([^\"]*)\" corner$")
	public void clickFooterLinkCorners(String sFooterLink, String sCorner) throws Throwable {

		try {
			if (sFooterLink.equalsIgnoreCase("LexisNexis logo")) {
				MIQActionsClass.waitForElement(LoginObjects.login_Footer_LexisLogo_Link, 5);
				MIQActionsClass.clickOnElement(LoginObjects.login_Footer_LexisLogo_Link, " Lexis logo");
				newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			} else if (sFooterLink.equalsIgnoreCase("RELX logo")) {
				
				MIQActionsClass.waitForElement(LoginObjects.login_Footer_RelxLogo_Link, 5);
				MIQActionsClass.clickOnElement(LoginObjects.login_Footer_RelxLogo_Link, " RELX logo");
			
			}

		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sFooterLink + " in the bottom " +sCorner+ "Corner");
		}
	}

	@Then("^Check user should be directed to the LexisNexis SA homepage \"([^\"]*)\"$")
	public void checkLexisNexisSAHomePage(String sUrl) throws Throwable {

		try {
				newdriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			String sCurrentUrl	= newdriver.getCurrentUrl();
				assertEquals(sCurrentUrl,sUrl);
				newdriver.navigate().back();
		

		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Check user should be directed to the LexisNexis SA homepage " +sUrl);
		}
	}

	@Then("^Click \"([^\"]*)\" in the footer$")
	public void clickFooterLink(String sFooterLinks) throws Throwable {
		try {
			if (sFooterLinks.equalsIgnoreCase("About Lexis MetroIQ")) {
				MIQActionsClass.waitForElement(LoginObjects.login_Footer_AboutMetroIQ_Link, 5);
				MIQActionsClass.clickOnElement(LoginObjects.login_Footer_AboutMetroIQ_Link, " About MetroIQ");

			} else if (sFooterLinks.equalsIgnoreCase("Privacy Policy")) {
				
				MIQActionsClass.waitForElement(LoginObjects.login_Footer_PrivacyPolicy_Link, 5);
				MIQActionsClass.clickOnElement(LoginObjects.login_Footer_PrivacyPolicy_Link, " Privacy Policy");
			
			}else if (sFooterLinks.equalsIgnoreCase("Terms and Conditions")) {
				
				MIQActionsClass.waitForElement(LoginObjects.login_Footer_TermsAndConditions_Link, 5);
				MIQActionsClass.clickOnElement(LoginObjects.login_Footer_TermsAndConditions_Link, " Terms and Conditions");
				
			
			}
			

		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sFooterLinks + " in the footer " );
		}
	}

	@Then("^The user should be directed to the \"([^\"]*)\" page$")
	public void userDirectedFooterPage(String sHeadingValue) throws Throwable {
		try {
		
			sHeadingValue=	MIQActionsClass.getElementText(By.xpath(LoginObjects.login_Footer_Headers_Value1
					+ sHeadingValue + LoginObjects.login_Footer_Headers_Value2), sHeadingValue);
			
			String sHeadingTitle=sHeadingValue.toUpperCase();
			assertEquals(sHeadingValue,sHeadingTitle);

	} catch (Exception e) {

		MIQExceptionHandle.HandleException(e, "Failed to checktThe user should be directed to the" +sHeadingValue);
	}
	}
	
	@Then("^Click \"([^\"]*)\" on the \"([^\"]*)\" page$")
	public void clickDocumentLink(String sDocument, String sPage) throws Throwable {
		try {
			 winHandleBefore = newdriver.getWindowHandle();
			MIQActionsClass.waitForElement(LoginObjects.login_Footer_DocumentPdF_Link, 5);
			MIQActionsClass.clickOnElement(LoginObjects.login_Footer_DocumentPdF_Link, " Document Pdf Link");
			for (String winHandle : newdriver.getWindowHandles()) {
				newdriver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
			}

			winHandleAfter = newdriver.getWindowHandle();
		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to click "+sDocument+ "on the "+sPage+"page");
		}
	}

	@Then("^Validate \"([^\"]*)\" should be opened in a new browser tab$")
	public void validateNewBrowserTab(String arg1) throws Throwable {
		try {
			
			if(!winHandleBefore.equals(winHandleAfter)) {
			MIQLog.info("User opened the document in a new browser tab");
			
			}
			else {
				MIQLog.info("failed to opened the document in a new browser tab ");
				Assert.fail("failed to opened the document in a new browser tab");
			}

		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to opened the document in a new browser tab");
		}
	}
	
	@And("^Quit the browser$")
	public void QuitBrowser() throws Throwable {
		try {
			Thread.sleep(3000);
			newdriver.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Refresh the page");
		}

	}
	@And("^Click on Report History icon$") 
	public void clickReport() throws Throwable{
		try {
			Actions action = new Actions(newdriver);
			String enter ="7";
			MIQActionsClass.waitForElement(LoginObjects.transferReport_History_Page, 5);
			MIQActionsClass.clickOnElement(LoginObjects.transferReport_History_Page, "Report History");
			MIQActionsClass.waitForElement(LoginObjects.transferReport_History_Enter,5);
			MIQActionsClass.typeInTextBox(LoginObjects.transferReport_History_Enter,enter, "Enter");
			action.sendKeys(Keys.ENTER).build().perform();
			
		}catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click Report History ");
		}
	}
	
	@Then("^Drag the scroll bar to the bottom$")
	public void drag_the_scroll_bar_to_the_bottom() throws Throwable {
		  JavascriptExecutor js = (JavascriptExecutor) newdriver;

	        //This will scroll the web page till end.		
	        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	       
	}

	  @After
		public static void close(Scenario scenario) {
			try {

				scenario.write("finished scenario");
				if (scenario.isFailed()) {
					
					MIQReport.addScreenCaptureFromPath(MIQActionsClass.getBase64Screenshot());
					//newdriver.close();
				}
//				for (String winHandle : newdriver.getWindowHandles()) {
//					newdriver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle
//															// (that's your newly opened window)
//					System.out.println( "after class");								// (that's your newly opened window)

		//newdriver.close();
		//		}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}