package MetroIQ_seleniumglucode;
import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import MIQ_accelerators.MIQActionsClass;
import MIQ_accelerators.MIQBase;
import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_AreaOfInterestObjects;
import MetroIQ_PageObjects.MIQ_MapViewObjects;
import MetroIQ_Utility.MIQExceptionHandle;
import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utility.ExceptionHandle;

public class MIQ_MapView {
	
	public static WebDriver newdriver = MIQBase.driver;
	public static String target;
	
	
	@When("^Enter \"([^\"]*)\" in the Map Page search bar$")
	public void EnterOnMapPageSearchBar(String searchData) throws Throwable {
		try {

			MIQActionsClass.waitForElement(MIQ_MapViewObjects.pageSearchBar_Input, 3);
			MIQActionsClass.typeInTextBox(MIQ_MapViewObjects.pageSearchBar_Input, searchData,"Search text field");
			Thread.sleep(5000);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter Search Data");
		}
	}

	@When("^Click on Search button in MetroIQ Map$")
	public void clickSearchButtonMetroIQMap() throws Throwable {
		try {

			MIQActionsClass.waitForElement(MIQ_MapViewObjects.pageSearchBar_InputButton, 3);
			MIQActionsClass.clickOnElement(MIQ_MapViewObjects.pageSearchBar_InputButton,"Submit search button");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to submit Search Data");
		}
	}


	@And("^East pane should be displayed with \"([^\"]*)\"$")
	public void eastPaneDisplayed(String expected) throws Throwable {
		try {

	
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.eastPaneTitile_PropertyInformation, 200);
			
			  String ConfirmationMessage = MIQActionsClass.getElementText(MIQ_MapViewObjects.eastPaneTitile_PropertyInformation,"Text on panel Information");
			  assertEquals(ConfirmationMessage,expected);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Faile to Check message" +expected);
		}
	}



	@And("^The Buttons \"([^\"]*)\" should be visible in the Property Information East panel$")
	public void ButtonsVisiblePropertyInformationEastPanel(String arg1) throws Throwable {

		try {
			
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.propertyInformation_SchemeButton, 200);
			MIQActionsClass.isElementVisible(MIQ_MapViewObjects.propertyInformation_SchemeButton, "Scheme Report");
			
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.propertyInformation_ViewUnits, 5);
			MIQActionsClass.isElementVisible(MIQ_MapViewObjects.propertyInformation_ViewUnits, "View Units");
			
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check All of the buttons on the " +arg1+" East panel should be enabled");
		}
	}

	@And("^The Buttons \"([^\"]*)\" should not be visible in the Property Information East panel$")
	public void buttonsNotVisiblePropertyInformationEastPanel(String arg1) throws Throwable {

		try {
			
			Thread.sleep(3000);
			MIQActionsClass.isElementNotVisible(MIQ_MapViewObjects.propertyInformation_SchemeButton, "Scheme Report");
			Thread.sleep(3000);
			MIQActionsClass.isElementNotVisible(MIQ_MapViewObjects.propertyInformation_ViewUnits, "View Units");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check All of the buttons on the " +arg1+" East panel should not be enabled");
		}
	}
	
	@And("^Enter \"([^\"]*)\" in map search text field$")
	public void enterMapsearch(String sMapvalue) {
		try {
		
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_searchMap, 3);
			MIQActionsClass.typeInTextBox(MIQ_MapViewObjects.MapVIew_searchMap, sMapvalue, "Mapvalue text field");
			

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter Mapvalue");
		}
	}
	
	@Then("^Click on \"([^\"]*)\" button in Map View$")
	public void clickAreaOfInterestpage(String sButton) throws Throwable {
		try {
			if(sButton.equalsIgnoreCase("MapSearch")) {
				MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_searchButton, 5);
				MIQActionsClass.clickOnElement(MIQ_MapViewObjects.MapVIew_searchButton,"Search Button");
				MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_PropertyInformation, 50);
			
			} else if (sButton.equalsIgnoreCase("Generate Report")) {
				MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_GenerateReportButton, 5);
				MIQActionsClass.clickOnElement(MIQ_MapViewObjects.MapVIew_GenerateReportButton, " Generate Report Button");
			
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on  "+sButton+ " button ");
		}
	}
	
	@And("^Check \"([^\"]*)\" is visible in east panel of Mapview$")
	public void checkEastPanelMapview(String sPanel) throws Throwable {
		try {
			if(sPanel.equalsIgnoreCase("Property Information")) {
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_PropertyInformation, 50);
			MIQActionsClass.isElementVisible(MIQ_MapViewObjects.MapVIew_PropertyInformation, "Property Information");
			} else if(sPanel.equalsIgnoreCase("Generate Report")) {
				MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_GenerateReportButton, 5);
				MIQActionsClass.isElementVisible(MIQ_MapViewObjects.MapVIew_GenerateReportButton, "Generate Report Button");
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Area Of Interest Pane should appear");
		}
	}
	
	@And("^Check Property Address \"([^\"]*)\" is visible in east panel of \"([^\"]*)\"$")
	public void checkPropertyAddressValuesInEastPanel(String sPropertyAddress, String sarg2) throws Throwable {
		try {
		
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_PropertyInformation, 5);
			String PropertyAdd=MIQActionsClass.getElementText(MIQ_MapViewObjects.MapVIew_PropertyAddress, "Property Address");
			Assert.assertTrue(PropertyAdd.contains(sPropertyAddress));
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Property Address in East panel");
		}
	} 
	@And("^Check Property Description \"([^\"]*)\" is visible in east panel of \"([^\"]*)\"$")
	public void checkPropertyDescriptionValuesInEastPanel(String sPropertyDescription, String sarg2) throws Throwable {
		try {
		
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_PropertyInformation, 50);
			String PropertyDec=MIQActionsClass.getElementText(MIQ_MapViewObjects.MapVIew_PropertyDescription, "Property Description");
			Assert.assertTrue(PropertyDec.contains(sPropertyDescription));

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Property Description in East panel");
		}
	}
	
	@When("^Check Owners \"([^\"]*)\" is visible in east panel of \"([^\"]*)\"$")
	public void check_Owners_is_visible_in_east_panel_of(String sOwnerName, String arg2) throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_OwnerName_Label, 5);
			String OwnerName= MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_OwnerName_Label, "Owner Name");
			Assert.assertTrue(OwnerName.contains(sOwnerName));

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check PropertyInformation OwnerName");
		}
	}
	@And("^Check \"([^\"]*)\" page should be displayed$")
	public void checkPropertyReportPage(String sPropertyReport) throws Throwable {
		try {
		
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_PropertyReport, 300);
			String pagetitle=MIQActionsClass.getElementText(MIQ_MapViewObjects.MapVIew_PropertyReport, "Property Report");
			Assert.assertTrue(pagetitle.contains(sPropertyReport));

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Property report should appear");
		}
	}
	@And("^Verify the Mapview with selected Property \"([^\"]*)\"$")
	public void checkMapView(String sDistrict) throws Throwable {
		try {
			Thread.sleep(20000);
			MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
				Screen s = new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sDistrict  + ".PNG");
				s.exists(pattern);

		} catch (Exception e) {
			ExceptionHandle.HandleException(e, "Failed to Verify the Mapview with selected MAOI " +sDistrict);
		}
	}
	@And("^Check \"([^\"]*)\" is Should not be visible in east panel of Mapview$")
	public void checkGenerateReportEastPanelMapviewOutside(String sPanel) throws Throwable {
		try {
			if(sPanel.equalsIgnoreCase("Generate Report")) {
				MIQActionsClass.isElementNotVisible(MIQ_MapViewObjects.MapVIew_GenerateReportButton, "Generate Report Button");
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check Area Of Interest Pane should appear");
		}
	}
	
	@Then("^Click on the \"([^\"]*)\" button on the zoom slider$")
	public void clickZoomButtonAtZoomSlider(String sZoom) throws Throwable {
		try {
			if (sZoom.equalsIgnoreCase("zoom-control-plus")) {
				
				MIQActionsClass.clickOnElement((By.xpath(MIQ_MapViewObjects.zoomIn1 + sZoom + MIQ_MapViewObjects.zoomIn2 )), "") ;	
				}
	
		} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed to click on "+sZoom+" button on the zoom slider");
				}
	}

	@Then("^The map should \"([^\"]*)\" one level$")
	public void checkMapOneLevel(String sDragged) throws Throwable {
		try {
				Thread.sleep(20000);
				MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					Screen s = new Screen();
					Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sDragged  + ".PNG");
					s.exists(pattern);
	
		} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed to Check the map "+sDragged+" one level");
				}
	}

	@Then("^Drag the zoom indicator button on the zoom slider up towards the \"([^\"]*)\" button$")
	public void dragZoomIndicator(String sZoom) throws Throwable {
		try {
			if (sZoom.equalsIgnoreCase("zoom plus")) {
				
					MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_ZoomSlider, 5);
					MIQActionsClass.dragAndDrop(MIQ_MapViewObjects.mapView_ZoomSlider, MIQ_MapViewObjects.mapView_ZoomIn);

				}
			else if (sZoom.equalsIgnoreCase("zoom minus")) {
				
				MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_ZoomSlider, 5);
				MIQActionsClass.dragAndDrop(MIQ_MapViewObjects.mapView_ZoomSlider, MIQ_MapViewObjects.mapView_ZoomOut);
			}
			
			
		} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed toDrag the zoom indicator button on the zoon slider up towards the  "+sZoom+" button");
				}
	}

	@Then("^Check the map should \"([^\"]*)\" according to how far the zoom indicator has been dragged$")
	public void checkMapZoomIndicatorDragged(String sZoom) throws Throwable {
		try {
			
				Thread.sleep(20000);
				MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					Screen s = new Screen();
					Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sZoom  + ".PNG");
					s.exists(pattern);	
		} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed toDrag the zoom indicator button on the zoon slider up towards the  "+sZoom+" button");
				}
	}
	
	@Then("^Click on the \"([^\"]*)\" button at Mapview$")
	public void clickMapview(String sButton) throws Throwable {
		try {
				if (sButton.equalsIgnoreCase("SATELLITE")) {
					
					MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_Satellite_Button, 5);
					MIQActionsClass.clickOnElement(MIQ_MapViewObjects.mapView_Satellite_Button, " Satellite Button");
							

					}
				else if (sButton.equalsIgnoreCase("Map")) {
					MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_Map_Button, 5);
					MIQActionsClass.clickOnElement(MIQ_MapViewObjects.mapView_Map_Button, " Map Button");
					
				}
				
				
			} catch (Exception e) {
						e.printStackTrace();
						MIQExceptionHandle.HandleException(e, "Failed to Click on the "+sButton+" button at Mapview");
					}
		}
	

	@Then("^Check the map should change to the \"([^\"]*)\" view$")
	public void checkMapChangeView(String sView) throws Throwable {
		try {

				Thread.sleep(20000);
				MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
					Screen s = new Screen();
					Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sView  + ".PNG");
					s.exists(pattern);
							
			
		} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed to Check the map should change to the "+sView+" view");
				}
	}



	@Then("^Click \"([^\"]*)\" to the lowest zoom level on the map to an area that has contains many properties$")
	public void clickLowestZoomLevel(String sProperty) throws Throwable {
		 try {
	            
//	            Thread.sleep(3000);
//	            for (int i = 0; i < 6; i++){
//	            Screen s=new Screen();
//	            Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sProperty+".PNG");
//	            Thread.sleep(2000);
//	            s.doubleClick(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sProperty+".PNG");    
//	            MIQLog.info("The selected "+sProperty+" highlighted on the map");
//	            }
	            MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_ZoomSlider, 5);
				MIQActionsClass.dragAndDrop(MIQ_MapViewObjects.mapView_ZoomSlider, MIQ_MapViewObjects.mapView_ZoomIn);
	        } catch (Exception e) {
	            MIQExceptionHandle.HandleException(e, "Failed to click" +sProperty + "to the lowest zoom level on the map to an area that has contains many properties");
	            }
	        }
	

	@When("^Zoom in to the lowest \"(.*)\" level on the map$")
	public void checkZoomlowestZoomLevel(String sZoom) throws Throwable {
		try {
			
			Thread.sleep(4000);
			for (int i = 0; i < 10; i++){
				MIQActionsClass.waitForElement(MIQ_MapViewObjects.zoomIn, 1500);
				MIQActionsClass.clickOnElement((By.xpath(MIQ_MapViewObjects.zoomIn1 + sZoom + MIQ_MapViewObjects.zoomIn2 )), "") ;
				  Thread.sleep(2000);
				}
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check zoom in to the lowest level");
		}
	}
	
	
	@When("^Click in the middle of any \"(.*)\"$")
	public void clickMiddleStreet(String sStreet) throws Throwable {
		try {
			
			Thread.sleep(3000);
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sStreet+".PNG");
			Thread.sleep(5000);
			s.click(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sStreet+".PNG");	
		
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click in the middle of any " +sStreet);
		}
	}
	
	
	@When("^East panel will display a warning message \"([^\"]*)\"$")
	public void eastPanelWarningMessage(String sErrorMessage) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.zoomIn, 1500);
			MIQActionsClass.clickOnElement((By.xpath(MIQ_MapViewObjects.errorMessage1 + sErrorMessage + MIQ_MapViewObjects.errorMessage2 )), "") ;
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Display Error Message ");
		}
	}
	
	@And ("^Click on the Map View$")
	public void clickOnMapView() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.menuMapView, 5);
			MIQActionsClass.clickOnElement(MIQ_MapViewObjects.menuMapView, "Map View");
			
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on the Map View ");
		}
	}
	
	@And ("^Click on any \"(.*)\" on sea$")
	public void clickAnyPlaceOnTheSea(String sOpenSpaceOnSea) throws Throwable {
		try {
			
			Thread.sleep(3000);
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sOpenSpaceOnSea+".PNG");
			Thread.sleep(5000);
			s.click(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sOpenSpaceOnSea+".PNG");	
			
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on any " +sOpenSpaceOnSea+ " on sea");
		}
	} 
	
	@When("^Click in the middle of the \"(.*)\"$")
	public void clickMiddleSea(String sSea) throws Throwable {
		try {
			
			Thread.sleep(3000);
			for (int i = 0; i < 8; i++){
				
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sSea+".PNG");
			Thread.sleep(2000);
			s.doubleClick(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sSea+".PNG");	
			MIQLog.info("The selected "+sSea+" highlighted on the map");
			}
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click in the middle of the "+sSea);
			}
		}
	@When("^Click in the abcd of the \"(.*)\"$")
	public void clickMidleSea(String sSea) throws Throwable {
		try {
			Screen s=new Screen();
		
			if (s.exists(System.getProperty("user.dir")+"\\MetroIQData\\Images\\FirstImage.png") != null)
	{       
			//	s.click(System.getProperty("user.dir")+"\\GuaranteeHubData\\Images\\Aurl.png");
				System.out.println("second highlighted image");
			s.doubleClick(System.getProperty("user.dir")+"\\MetroIQData\\Images\\FirstImage.png");
				Thread.sleep(3000);
				s=null;
				}
				
				else if (s.exists((System.getProperty("user.dir")+"\\MetroIQData\\Images\\FirstImage.png")) != null )
				{
					Thread.sleep(2000);
					System.out.println("First highlighted image");
					s.doubleClick(System.getProperty("user.dir")+"\\MetroIQData\\Images\\FirstImage.png");
					Thread.sleep(3000);
				s=null;
				}
				
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click in the middle of the "+sSea);
			}
		}
	

	@Then("^Check All of the property boundaries should \"([^\"]*)\" in black$")
	public void checkAllPropertyBoundaries(String sView) throws Throwable {
		try {

			Thread.sleep(20000);
			MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Screen s = new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sView  + ".PNG");
				s.exists(pattern);
						
		
	} catch (Exception e) {
				e.printStackTrace();
				MIQExceptionHandle.HandleException(e, "Failed to Check All of the property boundaries should "+sView+" in black");
			}
	}

	@Then("^\"([^\"]*)\" the \"([^\"]*)\" checkbox$")
	public void checkCheckbox(String sCheck, String arg2) throws Throwable {
		try {
			if (sCheck.equalsIgnoreCase("Select")) {
				
				if(!(MIQActionsClass.isCheckBoxChecked(MIQ_MapViewObjects.mapView_ShowERfNumber_Checkbox ))) {
					
				MIQActionsClass.clickOnElement(MIQ_MapViewObjects.mapView_ShowERfNumber_Checkbox, "Select Show ERf Number Checkbox");
						
				} 
				}
			else if (sCheck.equalsIgnoreCase("Deselect")) {
			//	if((MIQActionsClass.isCheckBoxChecked(MIQ_MapViewObjects.mapView_ShowERfNumber_Checkbox ))) {
					MIQActionsClass.clickOnElement(MIQ_MapViewObjects.mapView_ShowERfNumber_Checkbox, "Deselect Select Show ERf Number Checkbox");
			//	} 

			}
			
			
		} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed to "+sCheck+" Checkbox");
				}
	}

	@Then("^All of the properties should have the individual Erf numbers shown in the \"([^\"]*)\" of the property area$")
	public void checkAllPropertiesErfNumbers(String sView) throws Throwable {
		try {
			
			Thread.sleep(20000);
			MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Screen s = new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sView  + ".PNG");
				s.exists(pattern);
						
		
	} catch (Exception e) {
				e.printStackTrace();
				MIQExceptionHandle.HandleException(e, "Failed to Check the All of the properties should have the individual Erf numbers shown in th "+sView+" of the property area");
			}
	}

	@Then("^Check the property Erf numbers should \"([^\"]*)\" be visible$")
	public void checkPropertyErfumbersNoLongerVisible(String sView) throws Throwable {
try {
			
			Thread.sleep(20000);
			MIQBase.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				Screen s = new Screen();
				Pattern pattern = new Pattern(System.getProperty("user.dir") + "\\MetroIQData\\Images\\" + sView  + ".PNG");
				s.exists(pattern);
						
		
	} catch (Exception e) {
				e.printStackTrace();
				MIQExceptionHandle.HandleException(e, "Failed to Check the property Erf numbers should "+sView+" be visible");
			}
	}

	@When("^click on selectedMAOI \"(.*)\"$")
	public void clickOnMAOI(String sMAOI) throws Throwable {
		try {
			
			Thread.sleep(3000);
			
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sMAOI+".PNG");
			Thread.sleep(2000);
			s.doubleClick(System.getProperty("user.dir")+"\\MetroIQData\\Images\\"+sMAOI+".PNG");	
			MIQLog.info("The selected "+sMAOI+" highlighted on the map");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on selectedMAOI");
			}
		}
	

	
}
