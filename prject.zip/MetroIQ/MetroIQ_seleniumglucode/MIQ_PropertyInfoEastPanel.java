package MetroIQ_seleniumglucode;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.Assert;

import MIQ_accelerators.MIQBase;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.testng.Assert.assertEquals;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;


import com.cucumber.MIQlistener.MIQReport;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_MapViewObjects;
import MIQ_accelerators.MIQActionsClass;
import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;
import MetroIQ_Utility.MIQExceptionHandle;

public class MIQ_PropertyInfoEastPanel {
	static String sSaveText;
	
	
	@Then("^Navigate to the notes tab$")
	public void navigateNotesTab() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_PersonalNotes, 5);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_PersonalNotes, "Navigate to the notes tab");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Navigate to the notes tab");
		}
	}

	@Then("^Enter a \"([^\"]*)\" into the text section$")
	public void enterTextSection(String sSave) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.personalNotesTextbox, 5);
			MIQActionsClass.clickOnElement(LoginObjects.personalNotesTextbox, "Personal notes tab");
			MIQActionsClass.typeInTextBox(LoginObjects.personalNotesTextbox,sSave, "enter note into the text section");
			
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to enter note into the text section");
	}
}

	@Then("^Click \"([^\"]*)\" button at Personal Notes$")
	public void click_save(String sSave) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.personalNotesSave, 5);
			MIQActionsClass.clickOnElement(LoginObjects.personalNotesSave, "click save");
			sSaveText = MIQActionsClass.getAttribute(LoginObjects.personalNotesSave, "value", "Save");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click" +sSave+" button");
		}
	}

	@Then("^A Save succesful notification bar appears$")
	public void checkNotificationBar() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.personalNotesSaveNotification, 3);
			MIQActionsClass.isElementVisible(LoginObjects.personalNotesSaveNotification, "display a notification");
			
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to display a notification");
		}
	}

	@Then("^Navigate to a \"(.*)\" tab and back again$")
	public void navigateDifferentTab(String sNote) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_ReportsTab, 5);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_ReportsTab, "Navigate to a different tab and back again");
			Thread.sleep(2000);
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_PersonalNotes, 5);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_PersonalNotes, "Navigate to the notes tab");
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Navigate to a different tab and back again");
		}
	}

	@Then("^The \"(.*)\" note should remain in the dialog$")
	public void checkNoteDialog(String sNote) throws Throwable {
		try {
			 Thread.sleep(3000);
			String Text = MIQActionsClass.getElementText(LoginObjects.personalNotesTextbox, "Note");            
            assertEquals(Text,sNote);
           
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to display note in the dialog");
		}
	}

	@Then("^There should be no \"(.*)\" note saved unless you have also saved a note for this property, but should not be the same note$")
	public void checkSavedNotes(String sNote) throws Throwable {
		try {
            
            Thread.sleep(2000);
			String Text = MIQActionsClass.getElementText(LoginObjects.personalNotesTextbox, "Note");            
            assertEquals(Text,sNote);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check note should not be the same note");
		}
	}


	@Then("^The \"(.*)\" note should still be there$")
	public void checkNotes(String sNote) throws Throwable {
		try {
			
			String Text = MIQActionsClass.getElementText(LoginObjects.personalNotesTextbox, "Note");            
            assertEquals(Text,sNote);
            Thread.sleep(3000);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to display note");
		}
	}

	@Then("^check \"([^\"]*)\" succesful notification appears$")
	public void checkSuccesfulNotification(String sMessage) throws Throwable {
try {
			Thread.sleep(3000);
			String Text = MIQActionsClass.getElementText(LoginObjects.personalNotes_SaveNotification_Message, "Succesful Message");            
            assertEquals(Text,sMessage);
            
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check confirmation message");
		}
	}

	@Then("^Remove \"([^\"]*)\" text from the notes$")
	public void removeTextFromNotes(String arg1) throws Throwable {
try {
	
	MIQActionsClass.waitForElement(LoginObjects.personalNotesTextbox, 5);
	MIQActionsClass.clearTextbox(LoginObjects.personalNotesTextbox, "Clear Notes tab");
	
           
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to remove the text for notes");
		} 
	}

	@Then("^Check the \"([^\"]*)\" button changes to \"([^\"]*)\"$")
	public void checkButtonChanges(String sButton, String arg2) throws Throwable {
	    
		try {
		MIQActionsClass.waitForElement(LoginObjects.personalNotesSave, 5);
		String sSaveTextbutton = MIQActionsClass.getAttribute(LoginObjects.personalNotesSave, "value", "Save");
		Assert.assertNotEquals(sSaveText, sSaveTextbutton);
	
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to check the "+sButton+ "button changes to " +arg2+ " display note");
	} 
	
	}
	@Then("^Check he Property Information tab should contains \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"\"$")
	public void checkPropertyInformationTab(String sStreetAddress, String sPropertyDescription, String sStreetViewImage, String sOwnerlist, String Registrationdetails) throws Throwable {
		try {
			
		MIQActionsClass.waitForElement(MIQ_MapViewObjects.MapVIew_PropertyInformation, 5);
		String PropertyAdd=MIQActionsClass.getElementText(MIQ_MapViewObjects.MapVIew_PropertyAddress, "Property Address");
	//	Assert.assertTrue(PropertyAdd.contains(sPropertyAddress));
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to click on selectedMAOI");
		}
	}
	@Then("^Check the Property Information tab should contains \"([^\"]*)\" for \"([^\"]*)\", \"([^\"]*)\" for \"([^\"]*)\", \"([^\"]*)\" for \"([^\"]*)\" and Registered size \"([^\"]*)\", Registered sales date \"([^\"]*)\", Registration date \"([^\"]*)\", Registered sales price \"([^\"]*)\" and Current bonds \"([^\"]*)\" for \"([^\"]*)\"$")
	public void checkPropertyInformationTab(String sStreetAddress, String arg2, String sPropertyDescription, String arg4, String sOwnerName, String arg6, String sRegisteredSize, String sRegisteredSalesDate, String sRegistrationDate, String sRegisteredSalesPrice, String sCurrentBond,String sRegistrationDetails) throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_StreetAddress_Label, 3);
			String StreetAddress =	MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_StreetAddress_Label, "Street Address");
			MIQActionsClass.waitForElement(MIQ_MapViewObjects. mapView_PropertyInformation_PropertyDescription_Label, 5);
			String PropertyDescription=MIQActionsClass.getElementText(MIQ_MapViewObjects. mapView_PropertyInformation_PropertyDescription_Label, "Property Description");
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_OwnerName_Label, 5);
			String OwnerName= MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_OwnerName_Label, "Owner Name");
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_RegisteredSize_Label, 5);
			String RegisteredSize =MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_RegisteredSize_Label, "RegisteredSize");
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_RegisteredSalesDate_Label, 5);
			String RegisteredSalesDate=MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_RegisteredSalesDate_Label, "RegisteredSalesDate");
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_RegistrationDate_Label, 5);
			String RegistrationDate=MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_RegistrationDate_Label, "RegistrationDate");
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_RegisteredSalesPrice_Label, 5);
			String RegisteredSalesPrice=	MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_RegisteredSalesPrice_Label, "RegisteredSalesPrice");
			MIQActionsClass.waitForElement(MIQ_MapViewObjects.mapView_PropertyInformation_CurrentBond_Label, 5);
			String CurrentBond=MIQActionsClass.getElementText(MIQ_MapViewObjects.mapView_PropertyInformation_CurrentBond_Label, "Current Bond");
			Assert.assertTrue(StreetAddress.contains(sStreetAddress));
			Assert.assertTrue(PropertyDescription.contains(sPropertyDescription));
			Assert.assertTrue(OwnerName.contains(sOwnerName));
			Assert.assertTrue(RegisteredSize.contains(sRegisteredSize));
			Assert.assertTrue(RegisteredSalesDate.contains(sRegisteredSalesDate));
			Assert.assertTrue(RegistrationDate.contains(sRegistrationDate));
			Assert.assertTrue(RegisteredSalesPrice.contains(sRegisteredSalesPrice));
			Assert.assertTrue(CurrentBond.contains(sCurrentBond));
			
		
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check the Property information tab");
		} 
	}
	
	@Then("^Enter \"([^\"]*)\" in \"([^\"]*)\" at type at \"([^\"]*)\" page$")
	public void enterStreetNunberPage(String sName, String arg2, String arg3) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_StreetName_TextFiled, 3);
			MIQActionsClass.typeInTextBox(LoginObjects.propertySearch_StreetName_TextFiled, sName, "Property Search Street Name");
			
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Enter the deatils in Street Name");
			}
	}
	
	@Then("^User should be navigated to the \"([^\"]*)\" tab at \"([^\"]*)\" East Panel$")
	public void userNavigatedEastPanel(String sReports, String arg2) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_ReportGeneration_Label, 3);
			String sReportTab=MIQActionsClass.getElementText(LoginObjects.propertySearch_ReportGeneration_Label, "");
			assertEquals(sReportTab,sReports);
			
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check user navigate to the"+sReports+" tab");
			}	
	}

	@Then("^Check report \"([^\"]*)\" message should be displayed$")
	public void checkReportMessage(String sMessage) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_ReportGeneration_PropertyReport_Message, 3);
			String sReportTab=MIQActionsClass.getElementText(LoginObjects.propertySearch_ReportGeneration_PropertyReport_Message, "Porperty Report Message");
			assertEquals(sReportTab,sMessage);
			
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check report message");
			}	
	}

	

	@Then("^Check should be able to view \"([^\"]*)\" at east panel \"([^\"]*)\"$")
	public void checkEastPanelReportHistory(String arg1, String arg2) throws Throwable {
try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_ReportGeneration_ReportHistory_Link, 3);
			MIQActionsClass.isElementVisible(LoginObjects.propertySearch_ReportGeneration_ReportHistory_Link, "Report History");
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check user able to view "+arg1);
			}	
	}
	

	@Then("^Click on \"([^\"]*)\" at east panel \"([^\"]*)\"$")
	public void clickReportHiatory(String arg1, String arg2) throws Throwable {
try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_ReportGeneration_ReportHistory_Link, 3);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_ReportGeneration_ReportHistory_Link, "Report History");
		
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check user able to click "+arg1);
			}	
	}
	
	@Then("^Navigate to a \"(.*)\" tab$")
	public void navigateEastPannelTab(String sTab) throws Throwable {
		try {
			if (sTab.equalsIgnoreCase("Reports")) {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_ReportsTab, 5);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_ReportsTab, "Navigate to a different tab and back again");
			
			}else if (sTab.equalsIgnoreCase("Notes")) {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_PersonalNotes, 5);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_PersonalNotes, "Navigate to the notes tab");
			}	
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Navigate to " +sTab);
		}
	}
	@Then("^Click on any appropriate report in \"([^\"]*)\" page$")
	public void userDirectedPage(String sReport) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.reportHistory_FirstReport, 5);	
			MIQActionsClass.clickOnElement(LoginObjects.reportHistory_FirstReport, "First Report");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click on any appropriate report in "+sReport+ " page");
		}
	}
	
	@Then("^Check blue question mark icon next to the Property Description heading is visible$")
	public void checkBlueQuestionMarkIcon() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyInformation_QuestionMark_Label, 5);	
			MIQActionsClass.isElementVisible(LoginObjects.propertySearch_PropertyInformation_QuestionMark_Label, "First Report");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check blue question mark icon next to the Property Description heading is visible");
		}
	}

	@Then("^Click on blue question mark icon next to the Property Description heading$")
	public void clickBlueQuestionMarkIcon() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyInformation_QuestionMark_Label, 5);	
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyInformation_QuestionMark_Label, "First Report");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Click on blue question mark icon next to the Property Description heading");
		}
	}

	@Then("^Check it should displays the information on Dialog box \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void checkInformatioDialogBox(String sPropertyInformation, String sInformation, String sIncludes, String sStreetAddress, String sOfficialDescription, String sOwners, String sRegistrationDetails, String sAvailableAreaofInterest, String sCancel) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_PropertyInformation_Label, 3);
			String PropertyInformation =	MIQActionsClass.getElementText(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_PropertyInformation_Label, "PropertyInformation");
			MIQActionsClass.waitForElement(LoginObjects. propertyInformationEastPanel_QuestionMark_Dialog_Available_Label, 5);
			String Information=MIQActionsClass.getElementText(LoginObjects. propertyInformationEastPanel_QuestionMark_Dialog_Available_Label, "Information");
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_ThisIncludes_Label, 5);
			String Includes= MIQActionsClass.getElementText(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_ThisIncludes_Label, "Includes");
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_StreetAddress_Label, 5);
			String StreetAddress =MIQActionsClass.getElementText(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_StreetAddress_Label, "Street Address");
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_OfficialDescription_Label, 5);
			String OfficialDescription=MIQActionsClass.getElementText(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_OfficialDescription_Label, "Offical Description");
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_Owners_Label, 5);
			String Owners=MIQActionsClass.getElementText(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_Owners_Label, "Owners");
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_RegistrationDetails_Label, 5);
			String RegistrationDetails=	MIQActionsClass.getElementText(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_RegistrationDetails_Label, "Registration Details");
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_AreaOfInterest_Label, 5);
			String AvailableAreaofInterest=MIQActionsClass.getElementText(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_AreaOfInterest_Label, "Available Area of Interest");
			
			
			Assert.assertTrue(PropertyInformation.contains(sPropertyInformation));
			Assert.assertTrue(Information.contains(sInformation));
			Assert.assertTrue(Includes.contains(sIncludes));
			Assert.assertTrue(StreetAddress.contains(sStreetAddress));
			Assert.assertTrue(OfficialDescription.contains(sOfficialDescription));
			Assert.assertTrue(Owners.contains(sOwners));
			Assert.assertTrue(RegistrationDetails.contains(sRegistrationDetails));
			Assert.assertTrue(AvailableAreaofInterest.contains(sAvailableAreaofInterest));
			
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_Cancel_Button, 3);		
			MIQActionsClass.isElementVisible(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_Cancel_Button, "Canccel Button");
			

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to heck information on Dialog box e");
		}
	
}
	
	@Then("^Click on \"([^\"]*)\" button at Property Informatin Dialog$")
	public void clickPropertyInformatinDialog(String arg1) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_Cancel_Button, 3);	
			MIQActionsClass.clickOnElement(LoginObjects.propertyInformationEastPanel_QuestionMark_Dialog_Cancel_Button, "Cancel Button");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check blue question mark icon next to the Property Description heading is visible");
		}
	}

	@Then("^Check Property Information Dialog should not be visible$")
	public void checkPropertyInformationDialogShouldNotVisible() throws Throwable {
		try {
			Thread.sleep(5000);
			MIQActionsClass.isElementNotVisible(LoginObjects.propertyInformationEastPanel_QuestionMark_DialogBox, "DialogBox");
			

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Check blue question mark icon next to the Property Description heading is visible");
		}
	}

}



