package MetroIQ_seleniumglucode;

import static org.junit.Assert.assertNotEquals;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import MIQ_accelerators.MIQActionsClass;
import MIQ_accelerators.MIQBase;
import MetroIQ_PageObjects.MIQ_PropertyListObjects;
import MetroIQ_Utility.MIQExcelUtils;
import MetroIQ_Utility.MIQExceptionHandle;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utility.ExceptionHandle;
import MetroIQ_Utility.VerifyDownloadedFile;

public class MIQ_PropertyList {
	String currentAOI;
	String Desc_Row1;
	String Desc_Row2;
	String LPICode_Row1;
	String LPICode_Row2;
	String CSVReportName;
	String PDFReportName;
	String errorMessage;
	static String CSV_FILE_PATH;
	List<String> CSVData;
	String DownloadPath=System.getProperty("user.home") + "\\Downloads";
	@And("^get the current AOI$")
	public void getCurrentAOI() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentAOI, 25);
			currentAOI=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentAOI, "CurrentAOI");
			System.out.println(currentAOI);
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "get the current AOI");
		}
	}
	
	@And("^Check property list in the current Area Of Interest$")
	public void verifyPropertyListPage() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.pageTitle, 15);
			String title=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageTitle, "pageTitle");
			Assert.assertEquals(title, "Area of Interest Property List");
			
			String Description=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageDescription, "pageDescription");
			Assert.assertTrue(Description.contains(currentAOI));
			Assert.assertTrue(Description.contains("Properties within your Area of Interest. Current Area of Interest: "));
			MIQActionsClass.isElementVisible(MIQ_PropertyListObjects.PropertyListTable, "PropertyListTable");
		
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "PropertyList page not opened");
		}
	}

	@And("^select first two rows of the propertyList table$")
	public void Select2RowsFromPropertyList() throws Throwable {
		try {		
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.PropertyListTableRow_1, "Row1");
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.PropertyListTableRow_2, "Row2");
			Assert.assertTrue(MIQActionsClass.isCheckBoxChecked(MIQ_PropertyListObjects.PropertyListTableRow_1));
			Assert.assertTrue(MIQActionsClass.isCheckBoxChecked(MIQ_PropertyListObjects.PropertyListTableRow_2));
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Not able to select first two rows of the propertyList table");
		}
	}
	
	@And("^select \"([^\"]*)\" from the export dropdown$")
	public void selectExportOption(String sOption) throws Throwable {
		try {
			MIQActionsClass.selectByValue(MIQ_PropertyListObjects.ExportSelection_Dropdown, sOption);
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to selected the export option");
			}
	}

	@And("^click on \"([^\"]*)\" button to export$")
	public void ClickOnExportOption(String sOption) throws Throwable {
		try {
			Thread.sleep(5000);
			MIQActionsClass.clickOnElement(By.xpath(MIQ_PropertyListObjects.ExportSelection+sOption+"']"), "ExportSelection");
			Thread.sleep(3000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to selected the export option");
			}
	}
	
	@And("^get the description of the first two rows$")
	public void getDescription() throws Throwable {
		try {
			Desc_Row1=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.PropertyListTableRow_1_Title, "Desc_Row1");
			System.out.println(Desc_Row1+"Desc_Row1");
			Desc_Row2=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.PropertyListTableRow_2_Title, "Desc_Row2");
			System.out.println(Desc_Row2+"Desc_Row2");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Not able get the description of the first two rows");
		}
	}
	
@And("^Verify and Validate the information in the exported CSV \"(.*)\"$")
	
	public void verifyInformationInCSV(String sDesc) throws Throwable {
		try {
			System.out.println(sDesc+"sDesc");
			System.out.println(DownloadPath+"\\"+CSVReportName);
			
			VerifyDownloadedFile.deleteLatestReportfromDir(System.getProperty("user.home") + "//Downloads");
			System.out.println(CSVData); 
			Assert.assertTrue(CSVData.contains(Desc_Row1));
			Assert.assertTrue(CSVData.contains(Desc_Row2));
			
			
		} catch (Exception e) {
			VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
			e.printStackTrace();
			ExceptionHandle.HandleException(e, "Failed to verif the information in the exported CSV ");
		}

	}


@Then("^verify \"([^\"]*)\" dowloaded after clicking on export CSV in property List$")
public void exportCSVReport(String sDoc) throws Throwable {
    try {
        Thread.sleep(20000);
        CSVReportName = VerifyDownloadedFile.isFileDownloadedName(System.getProperty("user.home") + "//Downloads", sDoc);
        System.out.println(CSVReportName);
        Assert.assertFalse(CSVReportName.isEmpty());
        System.out.println("CSV report downlaoded");
        String[] name=CSVReportName.split("[.]");
        Assert.assertTrue(name[1].equalsIgnoreCase("CSV"));
        
        VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
    } catch (Exception e) {
        VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
        e.printStackTrace();
        ExceptionHandle.HandleException(e, "Failed to download export CSV");
    }
}



@Then("^verify \"([^\"]*)\" dowloaded after clicking on export PDF in property List$")
public void exportPDFReport(String sDoc) throws Throwable {
	try {
		Thread.sleep(20000);
		PDFReportName = VerifyDownloadedFile.isFileDownloadedName(System.getProperty("user.home") + "//Downloads", sDoc);
		System.out.println(PDFReportName);
		Assert.assertFalse(PDFReportName.isEmpty());
		System.out.println("PDF report downlaoded");
		String[] name=PDFReportName.split("[.]");
		Assert.assertTrue(name[1].equalsIgnoreCase("PDF"));
	} catch (Exception e) {
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
		e.printStackTrace();
		ExceptionHandle.HandleException(e, "Failed to download export PDF");
	}
}
@And("^Check Content In pdf report with description of the first two rows$")
public void verifyInformationInPDF() throws Throwable {
	try {
		Thread.sleep(3000);
		String contentInPdf = MIQActionsClass.checkDataFromPDF(PDFReportName);

		String ActualText = contentInPdf.replace("\r\n", "");
//		ActualText=ActualText.toLowerCase();
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");

		System.out.println(ActualText);
	
		
		Assert.assertTrue(ActualText.contains(Desc_Row1));
		Assert.assertTrue(ActualText.contains(Desc_Row2));
//		
	} catch (Exception e) {
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
        e.printStackTrace();
		ExceptionHandle.HandleException(e, "Content of pdf is not matched");
	}
}

@And("^select \"([^\"]*)\" from the \"([^\"]*)\" dropdown$")
public void selectFilteredOption(String sOption, String sDropdown) throws Throwable {
	try {
		if(sDropdown.equalsIgnoreCase("PropertyType")) {
			MIQActionsClass.selectByValue(MIQ_PropertyListObjects.PropertyType_Dropdown, sOption);	
			String selectedValue=	MIQActionsClass.GetSelectedValue(MIQ_PropertyListObjects.PropertyType_Dropdown);
			Assert.assertEquals(selectedValue, sOption);
		}
		else if(sDropdown.equalsIgnoreCase("LocalAuthority")) {
			MIQActionsClass.selectByValue(MIQ_PropertyListObjects.LocalAuthority_Dropdown, sOption);	
			String selectedValue=	MIQActionsClass.GetSelectedValue(MIQ_PropertyListObjects.LocalAuthority_Dropdown);
			Assert.assertEquals(selectedValue, sOption);
			Thread.sleep(15000);
		}
		else if(sDropdown.equalsIgnoreCase("Suburb")) {
			
			MIQActionsClass.selectByValue(MIQ_PropertyListObjects.Suburb_Dropdown, sOption);
			String selectedValue=	MIQActionsClass.GetSelectedValue(MIQ_PropertyListObjects.Suburb_Dropdown);
			Assert.assertEquals(selectedValue, sOption);
//			Thread.sleep(5000);
		}
		else if(sDropdown.equalsIgnoreCase("Township")) {
			
			MIQActionsClass.selectByValue(MIQ_PropertyListObjects.TownShip_Dropdown, sOption);
			String selectedValue=	MIQActionsClass.GetSelectedValue(MIQ_PropertyListObjects.TownShip_Dropdown);
			Assert.assertEquals(selectedValue, sOption);
//			Thread.sleep(5000);
		}
		Thread.sleep(20000);
	} catch (Exception e) {
		e.printStackTrace();
		MIQExceptionHandle.HandleException(e, "Failed to selected the export option");
		}
}

@And("^Delete the latest report downloaded in MetroIQ$")
public static void deleteLatestReport() throws Throwable {
	try {			
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");		
	} catch (Exception e) {
//		
		e.printStackTrace();
		ExceptionHandle.HandleException(e, "pdf not deleted");
	}
}

@Then("^verify \"([^\"]*)\" not dowloaded after clicking on export PDF in property List$")
public void NoexportPDFReport(String sDoc) throws Throwable {
	try {
//		Thread.sleep(20000);
		PDFReportName = VerifyDownloadedFile.isFileDownloadedName(System.getProperty("user.home") + "//Downloads", sDoc);
		System.out.println(PDFReportName);
		Assert.assertNull(PDFReportName);
		
		System.out.println("PDF report Not downlaoded");
		
	} catch (Exception e) {
		e.printStackTrace();
		ExceptionHandle.HandleException(e, "Failed to download export PDF");
	}
}

@Then("^verify \"([^\"]*)\" not dowloaded after clicking on export CSV in property List$")
public void NoexportCSVReport(String sDoc) throws Throwable {
	try {
//		Thread.sleep(20000);
		CSVReportName = VerifyDownloadedFile.isFileDownloadedName(System.getProperty("user.home") + "//Downloads", sDoc);
		System.out.println(CSVReportName);
		Assert.assertNull(CSVReportName);
		System.out.println("CSV report Not downlaoded");
	
	} catch (Exception e) {
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
		e.printStackTrace();
		ExceptionHandle.HandleException(e, "Failed to download export CSV");
	}
}

@And("^verify the filtered properties with suburb \"([^\"]*)\"$")
public void CheckFilteredProperties(String sValue) throws Throwable {
	try {
//		Thread.sleep(10000);
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.PropertyListSuburb, 5);
		java.util.List<WebElement> suburbValue =MIQActionsClass.getElements(MIQ_PropertyListObjects.PropertyListSuburb);
		for(int i=0; i<suburbValue.size(); i++) {
			String suburb=suburbValue.get(i).getText();
			System.out.println(suburb);
			Assert.assertEquals(suburb, sValue);
		}
		
		
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "get the current AOI");
	}
}

@And("^select \"([^\"]*)\" from pagination dropdown$")
public void PaginationDropdown(String sValue) throws Throwable {
	try {
		
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.PropertyListPageDropdown, 5);
		
		MIQActionsClass.selectByValue(MIQ_PropertyListObjects.PropertyListPageDropdown, sValue);
		Thread.sleep(15000);
		
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "get the current AOI");
	}
}

@And("^verify the number of items \"([^\"]*)\" per page$")
public void NoOfItemsPerPage(String sValue) throws Throwable {
	try {
		Thread.sleep(5000);
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.PropertyListFooter, 25);
		String footer=MIQActionsClass.getElementText(MIQ_PropertyListObjects.PropertyListFooter, "footer");
		System.out.println(footer);
		String[] footerValue=footer.split(" ");
		String pagination=footerValue[1]+"-"+footerValue[3];
		
		System.out.println(pagination);
		Assert.assertEquals(pagination, sValue);
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "get the current AOI");
	}
}

@And("^Click on \"([^\"]*)\" pagination link$")
public void ClickOnPaginationLink(String sOption) throws Throwable {
	try {
		if(sOption.equalsIgnoreCase("Next")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.PropertyListLeftPagination, 25);	
		MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.PropertyListLeftPagination, "LeftPagination");
		} 
		else if(sOption.equalsIgnoreCase("Last")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.PropertyListLastPagination, 5);	
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.PropertyListLastPagination, "LastPagination");
			Thread.sleep(10000);
		}
		else if(sOption.equalsIgnoreCase("First")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.PropertyListFirstPagination, 5);	
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.PropertyListFirstPagination, "FirstPagination");
			Thread.sleep(10000);
		}
		else if(sOption.equalsIgnoreCase("Prev")) {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.PropertyListPrevPagination, 5);	
			MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.PropertyListPrevPagination, "PrevPagination");
		}
		Thread.sleep(20000);
	} catch (Exception e) {
		e.printStackTrace();
		MIQExceptionHandle.HandleException(e, "Failed to selected the export option");
		}
}


@And("^Check unlocated property list in the current Area Of Interest$")
public void verifyUnlocatedPropertyListPage() throws Throwable {
	try {
		
		MIQActionsClass.waitForElement(MIQ_PropertyListObjects.pageTitle, 15);
		String title=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageTitle, "pageTitle");
		Assert.assertEquals(title, "Area of Interest Unlocated Property List");
		
		String Description=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageDescription, "pageDescription");
		
		Assert.assertTrue(Description.contains("Non Geolocated Properties within your Municipal Area of Interest. Current Area Of Interest: "));
		Description=Description.toLowerCase();
		Assert.assertTrue(Description.contains(currentAOI.toLowerCase()));
		MIQActionsClass.isElementVisible(MIQ_PropertyListObjects.PropertyListTable, "PropertyListTable");
	
		
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "unlocated PropertyList page not opened");
	}
}

@And("^get the LPI Code of the first two rows$")
public void getLPICode() throws Throwable {
	try {
		LPICode_Row1=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.PropertyListLPICode_row1, "LPICODE_Row1");
		System.out.println(LPICode_Row1+"LPICode_Row1");
		LPICode_Row2=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.PropertyListLPICode_row2, "LPICODE_Row2");
		System.out.println(LPICode_Row1+"LPICode_Row1");
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Not able get the LPICOde of the first two rows");
	}
}

@And("^Check Content In pdf report with LPICODE of the first two rows in Unlocated PropertyList$")
public void verifyInformationInPDFUnlocated() throws Throwable {
	try {
		Thread.sleep(3000);
		String contentInPdf = MIQActionsClass.checkDataFromPDF(PDFReportName);

		String ActualText = contentInPdf.replace("\r\n", "");
//		ActualText=ActualText.toLowerCase();
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");

		System.out.println(ActualText);
	
		
		Assert.assertTrue(ActualText.contains(LPICode_Row1));
		Assert.assertTrue(ActualText.contains(LPICode_Row2));
//		
	} catch (Exception e) {
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
        e.printStackTrace();
		ExceptionHandle.HandleException(e, "Content of pdf is not matched");
	}
}

@And("^Verify error message \"([^\"]*)\"$")
public void checkError(String sMessage) throws Throwable {
	try {
		errorMessage=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.Error, "error");
		Assert.assertEquals(errorMessage, sMessage);
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Error is not displayed");
	}
}
@Then("^Drag the scroll bar till bottom of the page$")
public void dragTheScrollBar() throws Throwable {
	try {
		
//	        String jsCode1 = "window.scrollBy(0, document.body.scrollHeight)";
	        JavascriptExecutor je = (JavascriptExecutor)MIQBase.driver;
//	        je.executeScript(jsCode1);  
//	        Thread.sleep(2000);
//	        je.executeScript("window.scrollBy(0,5000)");
//	        Thread.sleep(3000);
		
		WebElement element = MIQBase.driver.findElement(By.id("next_propertiesResultPager")); 
//		Actions actions = new Actions(MIQBase.driver);
//        actions.clickAndHold(element).moveByOffset(0,8000).release().perform();
        je.executeScript("arguments[0].scrollIntoView(true);",element);
        Thread.sleep(2000);
        
		
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to drag the scroll bar");
	}
}
@Then("^Verify \"([^\"]*)\" dowloaded after clicking on export \"([^\"]*)\" in property List$")
public void verify_dowloaded_after_clicking_on_export_in_property_List(String sDoc, String sDocument) throws Throwable {
	try {
		if(sDocument.equalsIgnoreCase("CSV")) {
			Thread.sleep(20000);
			CSVReportName = VerifyDownloadedFile.isFileDownloadedName(System.getProperty("user.home") + "//Downloads", sDoc);
			System.out.println(CSVReportName);
			Assert.assertFalse(CSVReportName.isEmpty());
			System.out.println("CSV report downlaoded");
			String[] name=CSVReportName.split("[.]");
			Assert.assertTrue(name[1].equalsIgnoreCase("CSV"));
			String a =VerifyDownloadedFile.getLatestFileNameFromDir(System.getProperty("user.home") + "//Downloads");
			File file=new File(System.getProperty("user.home")+"\\Downloads\\"+a);
			CSV_FILE_PATH = file.toString();
		}
		else if(sDocument.equalsIgnoreCase("PDF")) {
			
			Thread.sleep(20000);
			PDFReportName = VerifyDownloadedFile.getLatestFileNameFromDir(System.getProperty("user.home") + "//Downloads");
			System.out.println(PDFReportName);
			Assert.assertFalse(PDFReportName.isEmpty());
			System.out.println("PDF report downlaoded");
			String[] name=PDFReportName.split("[.]");
			Assert.assertTrue(name[1].equalsIgnoreCase("pdf"));
		}
		
	} catch (Exception e) {
		e.printStackTrace();
		MIQExceptionHandle.HandleException(e, "Failed to verify the downloaded file");
		}
}

@And("^Check Content In pdf report with description of the first two rows of Notifications$")
public void verifyInformationInPDfNoifications() throws Throwable {
	try {
		Thread.sleep(3000);
		String contentInPdf = MIQActionsClass.checkDataFromPDF(PDFReportName);

		String ActualText = contentInPdf.replace("\r\n", "");
//		ActualText=ActualText.toLowerCase();
	//	VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");

		System.out.println(ActualText);
		
		
		///Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPDFOfficialDescriptionText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ErfPart));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPropertyTypeText));
		//Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordStreetText));
		//Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordStreetAddressText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPDFCapitalSuburbText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordTitleDeedText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPDFExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPDFRemainingExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPriceText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPDFRegistrationDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPDFPurchaseDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FirstRecordPDFCaptureDateText));
		
		//Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordOfficialDescriptionText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondErfPart));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordPropertyTypeText));
		//Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordStreetText));
		//Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordStreetAddressText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordPDFCapitalSuburbText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordTitleDeedText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordPDFExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordPDFRemainingExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordPriceText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordPurchaseDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordRegistrationDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.SecondRecordCaptureDateText));
		
		//VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");

	} catch (Exception e) {
		//VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
        e.printStackTrace();
		ExceptionHandle.HandleException(e, "Content of pdf is not matched");
	}
}
@And("^Check Content In pdf report with description for all the rows of Notifications$")
public void verifyAllInformationInPDfNoifications() throws Throwable {
	try {
		Thread.sleep(3000);
		String contentInPdf = MIQActionsClass.checkDataFromPDF(PDFReportName);

		String ActualText = contentInPdf.replace("\r\n", "");
//		ActualText=ActualText.toLowerCase();
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");

		System.out.println(ActualText);
		
		
		///Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPDFOfficialDescriptionText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordErfPart));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPropertyTypeText));
	//	Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordStreetText));
	//	Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordStreetAddressText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordCapitalPDFSuburbText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordTitleDeedText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPDFExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPDFRemainingExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPriceText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPDFPurchaseDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPDFRegistrationDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.ThirdRecordPDFCaptureDateText));
		
		//Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordOfficialDescriptionText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordErfPart));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordPropertyTypeText));
	//Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordStreetText));
	//	Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordStreetAddressText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordSuburbText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordTitleDeedText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordPDFExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordPDFRemainingExtentText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordPriceText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordPurchaseDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordRegistrationDateText));
		Assert.assertTrue(ActualText.contains(MIQ_TransferReport.FourthRecordCaptureDateText));
		
	//	VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");

	} catch (Exception e) {
		//VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
        e.printStackTrace();
		ExceptionHandle.HandleException(e, "Content of pdf is not matched");
	}
}
@When("^Wait for some time to \"([^\"]*)\"$")
public void wait_for_some_time_to(String arg1) throws Throwable {
	try {
		Thread.sleep(80000);
	} catch (Exception e) {
		VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
		MIQExceptionHandle.HandleException(e, "Error is not displayed");
	}
}
}
