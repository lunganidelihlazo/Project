package MetroIQ_seleniumglucode;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import MIQ_accelerators.MIQBase;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.cucumber.MIQlistener.MIQReport;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import guaranteeHub.pageObjects.AdministratorObjects;
import pageObjects.DashboardObjects;
//import rc_accelerators.RCActionsClass;
//import rc_pageobjects.RCLoginObjects;
//import rc_utility.RCExceptionHandle;
import utility.ExceptionHandle;
import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_AdminObjects;
import MetroIQ_PageObjects.MIQ_MapViewObjects;
import MetroIQ_PageObjects.MIQ_PropertyListObjects;
import MetroIQ_PageObjects.MIQ_ReportHistoryObjects;
import MIQ_accelerators.MIQActionsClass;
import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;
import accelerators.ActionsClass;
import accelerators.GHActionsClass;
import MetroIQ_Utility.MIQExceptionHandle;

public class MIQ_PropertySearch extends MIQBase{
	public static WebDriver newdriver = MIQBase.driver;
static String sPropertyDiscriErfNumber;
static String sPropertyDiscriTownship;
static String sProperty_Discri_FarmName;
static String sPropery_Discri_Holding_Area;
static String sProperty_Discri_Holding_Num;
static String sProperty_Discri_portion;
static String PropertyName_report;    
static String AddressName_report;    
static String docName;
static String Name1, Name2;
	
	@When("^Click on \"([^\"]*)\" icon$")
	public void clickExpertNavigatinIcons(String sNavigationBarIcons) throws Throwable {
		try {
			if (sNavigationBarIcons.equalsIgnoreCase("Property Search")) {
				MIQActionsClass.waitForElement(LoginObjects.propertySearch_Icon, 5);
				MIQActionsClass.clickOnElement(LoginObjects.propertySearch_Icon, " Property Search");

			} else if (sNavigationBarIcons.equalsIgnoreCase("Admin")) {
				MIQActionsClass.waitForElement(LoginObjects.admin_Icon, 5);
				MIQActionsClass.clickOnElement(LoginObjects.admin_Icon, " Admin");
			
			}else if (sNavigationBarIcons.equalsIgnoreCase("Transfers Report")) {	
				MIQActionsClass.waitForElement(LoginObjects.transferReprot_Icon, 5);
				MIQActionsClass.clickOnElement(LoginObjects.transferReprot_Icon, " Transfer Report");
			}else if (sNavigationBarIcons.equalsIgnoreCase("Property List")) {	
				MIQActionsClass.waitForElement(MIQ_PropertyListObjects.propertyList_Icon, 5);
				MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.propertyList_Icon, " Property List");
			}
			else if (sNavigationBarIcons.equalsIgnoreCase("Unlocated Properties")) {	
				MIQActionsClass.waitForElement(MIQ_PropertyListObjects.UnlocatedpropertyList_Icon, 5);
				MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.UnlocatedpropertyList_Icon, "Unlocated Properties");
			}
			else if (sNavigationBarIcons.equalsIgnoreCase("Notifications")) {	
				MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_Icon, 5);
				MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.notifications_Icon, "Notifications");
			}			else if (sNavigationBarIcons.equalsIgnoreCase("Admin")) {	
				MIQActionsClass.waitForElement(MIQ_AdminObjects.Admin_Icon, 5);
				MIQActionsClass.clickOnElement(MIQ_AdminObjects.Admin_Icon, "Admin");
			} else if (sNavigationBarIcons.equalsIgnoreCase("ReportHistory")) {    
                MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.ReportHistory_Icon, 5);
                MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.ReportHistory_Icon, "ReportHistory");
            }else if (sNavigationBarIcons.equalsIgnoreCase("Offline Process")) {    
                MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.offlineProcess_Icon, 5);
                MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.offlineProcess_Icon, "Offline Process");
            }else if (sNavigationBarIcons.equalsIgnoreCase("Sub-Division Report")) {    
                MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.subDivisionReport_Link, 5);
                MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.subDivisionReport_Link, "Sub Division Report");
            }else if (sNavigationBarIcons.equalsIgnoreCase("Consolidation Report")) {    
                MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.consolidationReport_Link, 5);
                MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.consolidationReport_Link, "Consolidation Report");
            }

		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sNavigationBarIcons );
		}
	}

	@When("^Type \"([^\"]*)\" at \"([^\"]*)\" dropdown$")
	public void typStreetName(String sName, String sValue) throws Throwable {
		try {
			if (sValue.equalsIgnoreCase("Street Name")) {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_StreetName_Dropdown, 15);
			MIQActionsClass.typeInTextBox(LoginObjects.propertySearch_StreetName_Dropdown, sName, "Property Search Street Name");
			Thread.sleep(8000);
			
			}
			else if (sValue.equalsIgnoreCase("Suburb")) {
				MIQActionsClass.waitForElement(LoginObjects.propertySearch_Suburb_TextFiled, 15);
				MIQActionsClass.typeInTextBox(LoginObjects.propertySearch_Suburb_TextFiled, sName, "Property Search Suburb");
				
			}
			else if (sValue.equalsIgnoreCase("Type")) {
				MIQActionsClass.waitForElement(LoginObjects.propertySearch_Type_Dropdown, 15);
				MIQActionsClass.clickOnElement(LoginObjects.propertySearch_Type_Dropdown, " Property Search");
				Thread.sleep(2000);
		    	Actions action = new Actions(MIQBase.driver);
				action.sendKeys(sName).build().perform();
				Thread.sleep(2000);

				
			}
			else if (sValue.equalsIgnoreCase("Property Description Scheme name")) {
				MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionTownship, 15);
				//MIQActionsClass.typeInTextBox(LoginObjects.propertyDescriptionTownship, sName, "Property Search Suburb");
				MIQActionsClass.TypeInField(LoginObjects.propertyDescriptionTownship,sName);
				Thread.sleep(5000);
				
			}
			else if (sValue.equalsIgnoreCase("Property Description Deeds Office")) {
				MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionDeedsOffice, 15);
				MIQActionsClass.clickOnElement(LoginObjects.propertyDescriptionDeedsOffice, " Property Search");
				Thread.sleep(2000);
//				Actions action = new Actions(newdriver);
//				action.sendKeys(sName).build().perform();
				MIQActionsClass.typeInTextBoxWithoutClear(LoginObjects.propertyDescriptionDeedsOffice, sName, "Property Search Suburb");	
			}
			else if (sValue.equalsIgnoreCase("Property Description Farm Name")) {
				MIQActionsClass.waitForElement(LoginObjects.propertySearch_FarmName, 15);
				MIQActionsClass.typeInTextBox(LoginObjects.propertySearch_FarmName, sName, "propertySearch_FarmName");
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to type "+sName+ "at" +sValue+" dropdown");
		}
	}

	@When("^Validate the list containting \"([^\"]*)\"$")
	public void validateList(String sValue) throws Throwable {
		List<String> optionList = new ArrayList<String>();
		try {
			
			Thread.sleep(3000);
				
				List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@class='ui-layout-resizer ui-layout-resizer-east ui-layout-resizer-closed ui-layout-resizer-east-closed']//following-sibling::ul//li"));
				for (int i = 0; i < getList.size(); i++) {
					String s = getList.get(i).getText();
					System.out.println("abc text" + s);
					optionList.add(s);
					System.out.println("abc text" + optionList);

				}
			
			if (optionList.toString().contains(sValue)) {
				Thread.sleep(3000);
				MIQLog.info("dropdown displays" +sValue);
			} else {
			
				MIQLog.info("Failed to Validate the lit containing " +sValue);
				Assert.fail("Failed to Validate the lsit containing " +sValue);
			}

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Validate the lsit containing " +sValue);
		}
	}

	@When("^Select \"([^\"]*)\" at \"([^\"]*)\" dropdown$")
	public void selectDropdown(String sTitle, String arg2) throws Throwable {
		try {
			Thread.sleep(2000);
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@class='ui-layout-resizer ui-layout-resizer-east ui-layout-resizer-closed ui-layout-resizer-east-closed']//following-sibling::ul//li"));
			
		for (int i = 0; i < getList.size(); i++) {
			if (getList.get(i).getText().contains(sTitle)) {
				getList.get(i).click();
				break;
			}
		}
	
} catch (Exception e) {
	MIQExceptionHandle.HandleException(e, " Failed to select "+sTitle+ "at"+arg2+ " dropdown");
}
	    
	}

	@When("^Check street name \"([^\"]*)\", type is \"([^\"]*)\" and suburb is \"([^\"]*)\" for \"([^\"]*)\"$")
	public void checkPropertySearchValues(String sStreet, String sType, String sSuburb, String arg4) throws Throwable {
		
try {
	MIQActionsClass.waitForElement(LoginObjects.propertySearch_StreetName_Dropdown, 3);
	String sStreeetName = MIQActionsClass.getAttribute(LoginObjects.propertySearch_StreetName_Dropdown, "value", "Street Name");
	MIQActionsClass.waitForElement(LoginObjects.propertySearch_Suburb_TextFiled, 3);
	String sSuburbName = MIQActionsClass.getAttribute(LoginObjects.propertySearch_Suburb_TextFiled, "value", "Suburb");
	MIQActionsClass.waitForElement(LoginObjects.propertySearch_Type_Dropdown, 3);
	String STypeName=MIQActionsClass.GetSelectedValue(LoginObjects.propertySearch_Type_Dropdown);

	
	assertEquals(sStreet,sStreeetName);
	assertEquals(sType,STypeName);
	assertEquals(sSuburb,sSuburbName);
	
	
	
} catch (Exception e) {
	e.printStackTrace();
	MIQExceptionHandle.HandleException(e, " Failed to check Street Name "+sStreet+ " type"+sType+ " and suburb is" +sSuburb);
	}

}
	@When("^Validate the list containting \"([^\"]*)\" for \"([^\"]*)\"$")
	public void validatePropertySearchValue(String arg1, String sValue) throws Throwable {
		List<String> optionList = new ArrayList<String>();
		try {
			
				
				//List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@class='ui-helper-hidden-accessible']//following-sibling::ul//li/div"));
				
				List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@class='ui-helper-hidden-accessible']//following-sibling::ul//li/div"));
				
				for (int i = 0; i < getList.size(); i++) {
					String s = getList.get(i).getText();
					System.out.println("abc text" + s);
					optionList.add(s);
					System.out.println("abc text" + optionList);

				}
			
			if (optionList.toString().contains(sValue)) {
				Thread.sleep(3000);
				MIQLog.info("dropdown displays" +sValue);
			} else {
			
				utility.Log.info("Failed to Validate the list containing " +sValue);
				Assert.fail("Failed to Validate the list containing " +sValue);
			}

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Validate the list containing " +sValue);
		}
	}
	
	@Then("^Check \"([^\"]*)\" value is displayed at \"([^\"]*)\" dropdown$")
	public void checkTypedropdownValue(String sType, String arg2) throws Throwable {
		try {
			
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_Type_Dropdown, 3);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_Type_Dropdown, " Property Search");
			Thread.sleep(3000);
			String sTypeName=MIQActionsClass.GetSelectedValue(LoginObjects.propertySearch_Type_Dropdown);
			assertEquals(sType,sTypeName);
		
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, " Failed to check type "+sType+ "value is displayed at" +arg2+" dropdown");
			}
	}

	
	//Sikumbuzo
//	@Then("drag the scroll bar in the Metro IQ Data") 
//	public void dragAndDrop() throws Throwable{
//		try {
//			Thread.sleep(4000);
//			Screen s = new Screen();
//			s.click(System.getProperty("user.dir") + "\\\\MetroIQData\\Images\\Drag1.PNG");
//			
//			// s.click(System.getProperty("user.dir")+"\\GuaranteeHubData\\Images\\"+sCertificate+".png");
//			// s.click(System.getProperty("user.dir")+"\\GuaranteeHubData\\Images\\OK1.png");
//			s = null;
//		}catch(Exception e) {
//			RCExceptionHandle.HandleException(e, "Failed to drag down the scroll bar");
//		}
//	}
	
	
	@And("^Select Property description \"([^\"]*)\" in the \"([^\"]*)\"$")
	public void propertyDescriptionType(String sValue, String sProDescri) throws Throwable {
	    try {
	    		
	    	if(sProDescri.equalsIgnoreCase("Type")) {
	    		MIQActionsClass.waitForElement(LoginObjects.propertyDescritionType, 8);
	    		MIQActionsClass.clickOnElement(LoginObjects.propertyDescritionType, "Property Type");
	    		
	    		List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
	    				"//select[@id='PropertyType']//following-sibling::option"));
	    		for(int i = 0; i < getList.size(); i++) {
	    			if(getList.get(i).getText().contains(sValue)) {
	    				getList.get(i).click();
	    				break;
	    			}
	    				
	    		}
	    	}else if(sProDescri.equalsIgnoreCase("deeds office")) {
	    		MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionDeedsOffice, 8);
	    		MIQActionsClass.clickOnElement(LoginObjects.propertyDescriptionDeedsOffice, "deeds office");
	    		
	    		List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
	    				"//select[@id='OfficialDescriptionInput_DeedsOffice']//following-sibling::option"));
	    		for(int i = 0; i < getList.size(); i++) {
	    			if(getList.get(i).getText().contains(sValue)) {
	    				getList.get(i).click();
	    				break;
	    			}
	    		}
	    	}		
	    }catch(Exception e) {
	    	MIQExceptionHandle.HandleException(e, "Failed to select property description type and deeds office");
	    }
	}
	
	
	@And("^Enter \"([^\"]*)\" township and \"([^\"]*)\" Erf number in the property description$")
	public void enterPropertyDescriptionTownshipErfNumber(String sTownship, String sErfNumber) throws Throwable{
		try {
			sPropertyDiscriTownship = sTownship;
			sPropertyDiscriErfNumber = sErfNumber;
			
				MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionTownship, 3);
				MIQActionsClass.typeInTextBox(LoginObjects.propertyDescriptionTownship, sTownship, "Township");
				
				MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionErfNumber, 3);
				MIQActionsClass.typeInTextBox(LoginObjects.propertyDescriptionErfNumber, sErfNumber, "Erf Number");
		}catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter township and Erf number");
		}
	}

	
	@And("^Click the reset button$")
	public void clickResetButton() throws Throwable{
		try {
				MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionResetButton, 3);
				MIQActionsClass.clickOnElement(LoginObjects.propertyDescriptionResetButton, "Reset Button");
				
		}catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to click the reset button");
		}
	}
	
	
	
	
	
	@And("^Select propertyType as \"([^\"]*)\"$")
	public static void selectPropertyType(String sText) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyType_Dropdown, 3);
			MIQActionsClass.selectByVisibleText(LoginObjects.propertySearch_PropertyType_Dropdown, sText);

//			Thread.sleep(3000);
		} catch (Exception e) {
			ExceptionHandle.HandleException(e, "Failed to Select type drop down");
		}
	}
	@And("^Clear \"([^\"]*)\" text filed$")
	public static void clearHoldingArea(String sField) throws Throwable {
		try {
		if(sField.equalsIgnoreCase("Holding area"))
		{
			MIQActionsClass.clearTextbox(LoginObjects.propertySearch_HoldingArea, "Holding Area");
		}
//			Thread.sleep(3000);
		} catch (Exception e) {
			ExceptionHandle.HandleException(e, "Failed to Clear the field");
		}
	}
	@Then("^All the fields are reset to their original state, type \"([^\"]*)\" and Deeds Office \"([^\"]*)\" Township and Erf number$")
    public void checkFieldResetToOriginal(String sType, String sDeedOffice) throws Throwable{
        try {
            
                String strType = MIQActionsClass.getElementText(LoginObjects.propertyDescritionTypeDefaultValue, "Type");
                System.out.println(strType);
                Assert.assertEquals(strType, sType);
                
                
                String strDeedsOffice = MIQActionsClass.getElementText(LoginObjects.propertyDescriptionDeedsOfficeDefaultValue, "Deeds Office");
                System.out.println(strDeedsOffice);
                Assert.assertEquals(strDeedsOffice, sDeedOffice);
                
                String strTownship = MIQActionsClass.getElementText(LoginObjects.propertyDescriptionTownship, "Township");
                System.out.println(strTownship);
                Assert.assertFalse(strTownship.contains(sPropertyDiscriTownship));
                
                
                String strErfNumber = MIQActionsClass.getElementText(LoginObjects.propertyDescriptionErfNumber, "Deeds Office");
                Assert.assertFalse(strErfNumber.contains(sPropertyDiscriErfNumber));
                
        }catch(Exception e ) {
        	e.printStackTrace();
            MIQExceptionHandle.HandleException(e, "Failed to reset the fields to their original states");
        }
    }

	@And("^select holding area \"(.*)\" from autocomplete dropdown by giving characters \"(.*)\"$")
	public static void selectMultipleSignatories( String sHoldingArea, String sCharacter) throws Throwable {

		try {

			sCharacter=sCharacter.toUpperCase();
			sHoldingArea=sHoldingArea.toUpperCase();
			MIQActionsClass.typeInTextBoxWithoutClear(LoginObjects.propertySearch_HoldingArea,sCharacter, "Holding Area");
			Thread.sleep(3000);
			//newdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@class='ui-layout-resizer ui-layout-resizer-east ui-layout-resizer-closed ui-layout-resizer-east-closed']//following-sibling::ul//li"));
            
	        for (int i = 0; i < getList.size(); i++) {
	        	System.out.println(getList.get(i).getText());
	            if (getList.get(i).getText().contains(sHoldingArea)) {
	                getList.get(i).click();
	                break;
	            }
	        }
	        Thread.sleep(3000);
	        Assert.assertEquals(MIQActionsClass.getAttribute(LoginObjects.propertySearch_HoldingArea, "value", "Holding area"), sHoldingArea);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Select Holding area from the dropdown list by giving character");
		}
	}

	@Then("^drag the scroll bar in MetroIQ$")
	public void dragScrollBar() throws Throwable {
		try {
//			Thread.sleep(2000);
//			Screen s = new Screen();
//			s.click(System.getProperty("user.dir") + "\\MetroIQData\\Images\\drag.png");
//			s = null;
		//	Thread.sleep(3000);
			WebElement element = MIQBase.driver.findElement(By.xpath("//input[@value='Reset fields']")); 
			Actions actions = new Actions(MIQBase.driver);
            actions.clickAndHold(element).moveByOffset(0,5000).release().perform();
            Thread.sleep(2000);

            
		} catch (Exception e) {
			e.printStackTrace();
			ExceptionHandle.HandleException(e, "Failed to drag the scroll bar in MetroIQ");
		}
	}
	@Then("^Check property Description \"([^\"]*)\" Changed to \"([^\"]*)\" from \"([^\"]*)\"$")
	public void checkPropertyDescriptionChanged(String arg1, String arg2, String sValue) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyType_Dropdown, 3);
			String sTypeValue=MIQActionsClass.GetSelectedValue(LoginObjects.propertySearch_PropertyType_Dropdown);
			assertNotEquals(sValue,sTypeValue);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, " Failed to check property Description "+arg1+ " Changed to"+arg2+ " from" +sValue);
			}
	}

	@Then("^Check Deeds Office \"([^\"]*)\" and Scheme number \"([^\"]*)\" for \"([^\"]*)\"$")
	public void checkDeedsOfficeSchemeNumber(String sDeedsOffice, String sNumber, String arg3) throws Throwable {
		try {

			MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionDeedsOffice, 3);
			String ssDeedsOfficeName=MIQActionsClass.GetSelectedValue(LoginObjects.propertyDescriptionDeedsOffice);
			MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionErfNumber, 3);
			String sNumberName = MIQActionsClass.getAttribute(LoginObjects.propertyDescriptionErfNumber, "value", "Suburb");
			assertEquals(sDeedsOffice,ssDeedsOfficeName);
			assertEquals(sNumber,sNumberName);
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, " Failed to Check Deeds Office  "+sDeedsOffice+ " and Scheme number "+sNumber+ " for " +arg3);
			}
	}
	
	@And("^Verify the DeedsOffice value \"([^\"]*)\"$")
	public static void verifyDeedsOfficeValue(String sText) throws Throwable {
		try {
			String SelectedOption= MIQActionsClass.GetSelectedValue(LoginObjects.propertySearch_DeedsOffice_Dropdown);
			Assert.assertEquals(SelectedOption, sText);
		} catch (Exception e) {
			ExceptionHandle.HandleException(e, "Value not matched");
		}
	}
	
	@When("^Validate all options from DeedsOffice dropdown \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\"$")
	public void validateallptionsDeedsOffice_dropdown(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12) throws Throwable {
	try {
			List<String> ExpectedOptions=new ArrayList<String>();
			List<String> ActualOptions = new ArrayList<String>();
			ExpectedOptions.add(arg1);
			ExpectedOptions.add(arg2);
			ExpectedOptions.add(arg3);
			ExpectedOptions.add(arg4);
			ExpectedOptions.add(arg5);
			ExpectedOptions.add(arg6);
			ExpectedOptions.add(arg7);
			ExpectedOptions.add(arg8);
			ExpectedOptions.add(arg9);
			ExpectedOptions.add(arg10);
			ExpectedOptions.add(arg11);
			ExpectedOptions.add(arg12);
			
			// Select s = new Select(newdriver.findElement(LoginObjects.propertySearch_DeedsOffice_Dropdown));
			//List<WebElement> Options= s.getOptions();
			List<WebElement> Options = MIQActionsClass.getElements(By.xpath("//Select[@id='OfficialDescriptionInput_DeedsOffice']//option"));
				
			for(int i=0 ; i< Options.size();i++) {
				String option = Options.get(i).getText();
				System.out.println(option);
				ActualOptions.add(option);
			}
			Assert.assertTrue(ActualOptions.equals(ExpectedOptions));
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			ExceptionHandle.HandleException(e, "Failed to click on login");
		}
	}
	@Then("^Check No result - no matches for \"([^\"]*)\" within the \"([^\"]*)\" deeds office$")
	public void checkNoResultNoMatchesForDeedsOffice(String arg1, String arg2) throws Throwable {
		try {
			
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@class='ui-layout-resizer ui-layout-resizer-east ui-layout-resizer-closed ui-layout-resizer-east-closed']//following-sibling::ul//li"));
					for (int i = 0; i < getList.size(); i++) {
						
						if(!getList.get(i).isDisplayed()) {

				MIQLog.info("No result - no matches for " +arg1+ " within the"  +arg2+" deeds office");
			} 
				
			else  {
				
				MIQLog.info("Failed to check No result - no matches for " +arg1+ " within the "  +arg2+" deeds office");
				Assert.fail("Failed to check No result - no matches for " +arg1+ " within the "  +arg2+" deeds office");
			}
			
		}
		}catch (Exception e) {
			ExceptionHandle.HandleException(e, "Failed to check No result - no matches for " +arg1+ " within the "  +arg2+" deeds office");
		}
	
	}
	
	@When("^Click on \"([^\"]*)\" at \"([^\"]*)\" page$")
	public void clickButtons(String sButton, String sModule) throws Throwable {
		try {
			if (sButton.equalsIgnoreCase("Next button")) {
				
					MIQActionsClass.waitForElement(LoginObjects.propertySearch_Next_Button, 5);
					MIQActionsClass.clickOnElement(LoginObjects.propertySearch_Next_Button, " Next Button");	

				}
			else if (sButton.equalsIgnoreCase("Return to search")) {
				MIQActionsClass.waitForElement(LoginObjects.propertySearch_ReturnToSearch_Button, 5);
				MIQActionsClass.clickOnElement(LoginObjects.propertySearch_ReturnToSearch_Button, " Return to search Button");
				
			}
			else if (sButton.equalsIgnoreCase("Generate report")) {
				MIQActionsClass.waitForElement(LoginObjects.transferReprot_GenerateReport_Button, 5);
				MIQActionsClass.clickOnElement(LoginObjects.transferReprot_GenerateReport_Button, " Generate Report Button");
				
			}
			else if (sButton.equalsIgnoreCase("Refine Report")) {
				MIQActionsClass.waitForElement(LoginObjects.transferReprot_RefineReport_Button, 25);
				MIQActionsClass.clickOnElement(LoginObjects.transferReprot_RefineReport_Button, " Refine Report Button");
				
			}
			else if (sButton.equalsIgnoreCase("Reset fields")) {
				MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResetFields_Button, 5);
				MIQActionsClass.clickOnElement(LoginObjects.transferReprot_ResetFields_Button, " Reset Filed Button");
				
			}
			
		} catch (Exception e) {
					e.printStackTrace();
					MIQExceptionHandle.HandleException(e, "Failed to click on "+sButton+" at" +sModule+ " page");
				}
		}
	@Given("^Check the jquery grid displays$")
	public static void checkJqueryGrid() throws Throwable {
try {
	MIQActionsClass.waitForElement(LoginObjects.propertySearch_Result_Grid, 5);
	
	MIQActionsClass.isElementVisible(LoginObjects.propertySearch_Result_Grid, "MapView");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e,"Failed to Check the jquery grid displays");
		}
	}
	@When("^Enter \"([^\"]*)\" in \"([^\"]*)\" and Check it fiters the values with \"([^\"]*)\" on \"([^\"]*)\" page$")
	public void enterValuesForFilter(String sValue, String arg2, String sPropertyDescriptionValue, String arg4) throws Throwable {
		try {
			String sOption = "";
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_TextField, 5);
			MIQActionsClass.typeInTextBox(LoginObjects.propertySearch_PropertyDescrtipionGrid_TextField,sValue, "Property Description");

					List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//table[@id='AdvancedListResultTable']//tr//td[@aria-describedby='AdvancedListResultTable_PropertyDescriptionString']"));
					for (int i = 0; i < getList.size(); i++) {
						sOption = getList.get(i).getText();
						
					}
					if (sPropertyDescriptionValue.equalsIgnoreCase("Erf 5")) {
						Assert.assertTrue(sOption.startsWith(sPropertyDescriptionValue));
						MIQLog.info("Filters the Property Description values");
						
					} else {
					
						utility.Log.info("Failed to enter " +sValue+"in" +arg2+" and Check it fiters the values with "+sPropertyDescriptionValue+ "on"+arg4+ " Page");
						Assert.fail("Failed to enter " +sValue+"in" +arg2+" and Check it fiters the values with "+sPropertyDescriptionValue+ "on"+arg4+ " Page");
					}
	
				} catch (Exception e) {
					MIQExceptionHandle.HandleException(e,"Failed to enter " +sValue+"in" +arg2+" and Check it fiters the values with "+sPropertyDescriptionValue+ "on"+arg4+ " Page");
				}
	}

	@When("^Sort the list of \"([^\"]*)\" values at \"([^\"]*)\" page$")
	public void sorthTheValues(String arg1, String arg2) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_Sortable, 5);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_Sortable," Property Description");
			
			ArrayList<String> obtainedList = new ArrayList<>();
			List<WebElement> elementList = MIQActionsClass.getElements(By.xpath("//table[@id='AdvancedListResultTable']//tr//td[@aria-describedby='AdvancedListResultTable_PropertyDescriptionString']"));
			for (WebElement we : elementList) {
				obtainedList.add(we.getText());
				System.out.println("obtainedList" + obtainedList);
			}

			ArrayList<String> sortedList = new ArrayList<>();
			for (String s : obtainedList) {
				sortedList.add(s);
				System.out.println("sortedList" + sortedList);
			}
			Collections.sort(sortedList);
			Collections.reverse(sortedList);//For descending order a
			Assert.assertTrue(sortedList.equals(obtainedList));
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to launch the browser");
		}
	}
//	@And("^Resize the browser$")
//    public void resizeBrowser() throws Throwable{
//        try {
//                Dimension d = new Dimension(800,480);
////                Resize the current window to the set dimension
//                Thread.sleep(5000);
//                newdriver.manage().window().setSize(d);
//                
//        }catch(Exception e) {
//            MIQExceptionHandle.HandleException(e, "Failed to resize the browser");
//        }
//    }
	@When("^Resize the browser with width \"([^\"]*)\" and height \"([^\"]*)\"$")
	public void resizeBrowser(int sWidth, int sHeight) throws Throwable {
	     try {
             Dimension d = new Dimension(sWidth,sHeight);
//             Resize the current window to the set dimension
             Thread.sleep(5000);
             MIQBase.driver.manage().window().setSize(d);
             
     }catch(Exception e) {
    	 e.printStackTrace();
         MIQExceptionHandle.HandleException(e, "Failed to resize the browser");
     }
	}

	@When("^Validate the size of the browser with height \"([^\"]*)\" and width \"([^\"]*)\"$")
	public void validateSizeTheBrowser(int sHeight, int sWidth) throws Throwable {
	     try {
//	    	 sHeight=sHeight+2;
//	    	 sWidth=sWidth+2;
	    	 
	    	 Dimension initial_size = MIQBase.driver.manage().window().getSize();
	    	    int height = initial_size.getHeight();
	    	    int width = initial_size.getWidth();
	    	    System.out.println(""+height+""+width);
	    	    assertEquals(sHeight,height);
	    	    assertEquals(sWidth,width);
             

     }catch(Exception e) {
         MIQExceptionHandle.HandleException(e, "Failed to resize the browser");
     }
	}
	@Then("^Check Registation Division \"([^\"]*)\" and Farm number \"([^\"]*)\"$")
	public void checkRegistartionDevisionFarmNumber(String sRDivision, String sFarmNumber) throws Throwable {
		try {

			MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionRegistrationDivision, 8);
			String RegistrationDivision= MIQActionsClass.getAttribute(LoginObjects.propertyDescriptionRegistrationDivision, "value", "propertyDescriptionRegistrationDivision");
			System.out.println(RegistrationDivision+"rd");
			MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionFarmNumber, 8);
			String FarmNumber = MIQActionsClass.getAttribute(LoginObjects.propertyDescriptionFarmNumber, "value", "propertyDescriptionFarmNumber");
			System.out.println(FarmNumber+"fN");
			Assert.assertEquals(RegistrationDivision, sRDivision);
			Assert.assertEquals(FarmNumber, sFarmNumber);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, " Registration Division or farm number not matched");
			}
	}
	
	@Then("^Select \"([^\"]*)\" and the type field is \"([^\"]*)\"$")
	public void selectTypeField(String sTypeValue, String sTypeFName) throws Throwable {
	    try {
	    		if(sTypeFName.equalsIgnoreCase("Agriculture")) {
	    			MIQActionsClass.waitForElement(LoginObjects.propertyDescritionType, 4);
		    		MIQActionsClass.clickOnElement(LoginObjects.propertyDescritionType, "Property Type");
	    			
		    		List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
		    				"//select[@id='PropertyType']//following-sibling::option"));
		    		for(int i = 0; i < getList.size(); i++) {
		    			if(getList.get(i).getText().contains(sTypeValue)) {
		    				getList.get(i).click();
		    				break;
		    			}	
		    		}
	    		}else if(sTypeFName.equalsIgnoreCase("ERF Number")) {
	    			MIQActionsClass.waitForElement(LoginObjects.propertyDescritionType, 4);
		    		MIQActionsClass.clickOnElement(LoginObjects.propertyDescritionType, "Property Type");
		    		
		    		List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
		    				"//select[@id='PropertyType']//following-sibling::option"));
		    		for(int i = 0; i < getList.size(); i++) {
		    			if(getList.get(i).getText().contains(sTypeValue)) {
		    				getList.get(i).click();
		    				break;
		    			}	
		    		}
	    		}else if(sTypeFName.equalsIgnoreCase("Farm name")) {
	    			MIQActionsClass.waitForElement(LoginObjects.propertyDescritionType, 4);
		    		MIQActionsClass.clickOnElement(LoginObjects.propertyDescritionType, "Property Type");
		    		
		    		List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
		    				"//select[@id='PropertyType']//following-sibling::option"));
		    		for(int i = 0; i < getList.size(); i++) {
		    			if(getList.get(i).getText().contains(sTypeValue)) {
		    				getList.get(i).click();
		    				break;
		    			}	
		    		}
	    		}else if(sTypeFName.equalsIgnoreCase("Sectional Scheme")) {
	    			MIQActionsClass.waitForElement(LoginObjects.propertyDescritionType, 4);
		    		MIQActionsClass.clickOnElement(LoginObjects.propertyDescritionType, "Property Type");
		    		
		    		List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
		    				"//select[@id='PropertyType']//following-sibling::option"));
		    		for(int i = 0; i < getList.size(); i++) {
		    			if(getList.get(i).getText().contains(sTypeValue)) {
		    				getList.get(i).click();
		    				break;
		    			}	
		    		}
	    		}else if(sTypeFName.equalsIgnoreCase("All Fields")) {
	    			MIQActionsClass.waitForElement(LoginObjects.propertyDescritionType, 4);
		    		MIQActionsClass.clickOnElement(LoginObjects.propertyDescritionType, "Property Type");
		    		
		    		List<WebElement> getList = MIQActionsClass.getElements(By.xpath(
		    				"//select[@id='PropertyType']//following-sibling::option"));
		    		for(int i = 0; i < getList.size(); i++) {
		    			if(getList.get(i).getText().contains(sTypeValue)) {
		    				getList.get(i).click();
		    				break;
		    			}	
		    		}
	    		}
	    }catch(Exception e) {
	    	MIQExceptionHandle.HandleException(e, "Failed to select the type on the type dropdown");
	    }
	}

	
	
	@Then("^Check fields change to \"([^\"]*)\" , \"([^\"]*)\", \"([^\"]*)\"$")
	public void checkFieldsChangeTo(String arg1, String arg2, String arg3) throws Throwable {
	    try {
	    	sPropery_Discri_Holding_Area = MIQActionsClass.getElementText(
					LoginObjects.label_propetry_Description_Holding_Area, "Holding Area");
			Assert.assertEquals(sPropery_Discri_Holding_Area, arg1);
			
			sProperty_Discri_Holding_Num = MIQActionsClass.getElementText(
					LoginObjects.label_property_Description_Holding_Number, "Holding Number");
			Assert.assertEquals(sProperty_Discri_Holding_Num, arg2);
			
			sProperty_Discri_portion = MIQActionsClass.getElementText(
					LoginObjects.label_property_Description_Portion_Number, "Portion Number");
			Assert.assertEquals(sProperty_Discri_portion, arg3);
	    }catch(Exception e) { 
	    	MIQExceptionHandle.HandleException(e, "Failed to verify that the field has change or match with the selected option");
	    }
	}
	
	
	@Then("^Check the field for Farm has change to \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void checkFarmFieldsChange(String arg1, String arg2, String arg3, String arg4) throws Throwable{
		try {
			
			sProperty_Discri_FarmName = MIQActionsClass.getElementText(
					LoginObjects.label_propetry_Description_Farm_Name, "Farm name");
			Assert.assertEquals(sProperty_Discri_FarmName, arg1);
			
			sPropery_Discri_Holding_Area = MIQActionsClass.getElementText(
					LoginObjects.label_propetry_Description_Holding_Area, "Holding Area");
			Assert.assertEquals(sPropery_Discri_Holding_Area, arg2);
			
			sProperty_Discri_Holding_Num = MIQActionsClass.getElementText(
					LoginObjects.label_property_Description_Holding_Number, "Holding Number");
			Assert.assertEquals(sProperty_Discri_Holding_Num, arg3);
			
			sProperty_Discri_portion = MIQActionsClass.getElementText(
					LoginObjects.label_property_Description_Portion_Number, "Portion Number");
			Assert.assertEquals(sProperty_Discri_portion, arg4);
		}catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to verify that the field has change or match with the selected option");
		}
	}
	


	@Then("^Click on \"([^\"]*)\" in \"([^\"]*)\" page$")
	public void clickLink(String sLink, String arg2) throws Throwable {
		try {
			if (sLink.equalsIgnoreCase("Report Branding Manager")) {
				MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_Link, 5);
				MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_Link, " Report Branding Manager");

			} else if (sLink.equalsIgnoreCase("Change Header")) {
				MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_UploadButton, 5);
				MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_UploadButton, " Change Header");
			
			}else if (sLink.equalsIgnoreCase("Change Footer")) {
				
				MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_UploadButton, 5);
				MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_UploadButton, " Change Footer");
			}

		} catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sLink+ " in "+arg2+ " page" );
		}
	}

	@Then("^Check Windows file browser appears$")
	public void checkWindowsFile() throws Throwable {
		try {
			Screen s=new Screen();
			Pattern pattern = new Pattern(System.getProperty("user.dir")+"/MetroIQData/Images/WindowsFile.PNG");
			s.exists(pattern);
			utility.Log.info("Windows file browser appears");
		}
		catch (Exception e) {

			ExceptionHandle.HandleException(e, "Failed to check Windows file browser appears");
		}
	}
	
	@Then("^select a suitable \"([^\"]*)\" at \"([^\"]*)\" page$")
	public void selectHeaderOrFooterPath(String sPath, String sarg2) throws Throwable {
		try {
			
			if(sPath.equalsIgnoreCase("Header Image")) {
				Thread.sleep(3000);
				Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\MetroIQData\\AutoIT\\WindowsFile.exe");
			}else if(sPath.equalsIgnoreCase("Footer Image")) {
				Thread.sleep(3000);
				Runtime.getRuntime().exec(System.getProperty("user.dir")+"\\MetroIQData\\AutoIT\\ReportFooter.exe");
			}
			Thread.sleep(3000);
		} catch (Exception e) {

			ExceptionHandle.HandleException(e, "Failed to upload signatory document");
		}
		 
	}

	@Then("^Click on \"([^\"]*)\" and it will discard all changes$")
	public void clickDiscard(String sDiscard) throws Throwable {
		try {
			if (sDiscard.equalsIgnoreCase("Discard Header")) {
				MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_Discard_Button, 5);
				MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_Discard_Button, " Change Header Discard button");
				MIQActionsClass.isElementVisible(LoginObjects.admin_ReportBrandingManager_ChangeHeader_UploadButton, "Change Header");
				} 

			 else if (sDiscard.equalsIgnoreCase("Discard Footer")) {
				 MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_Discard_Button, 5);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_Discard_Button, " Change Footer Discard button");
					MIQActionsClass.isElementVisible(LoginObjects.admin_ReportBrandingManager_ChangeFooter_UploadButton, "Change Footer");
				
			}
				
		}
		catch (Exception e) {

			ExceptionHandle.HandleException(e, "Failed to click on " +sDiscard);
		}
	}
	
	@Then("^\"([^\"]*)\" check box labeled \"([^\"]*)\" at \"([^\"]*)\" page$")
	public void checkBoxLabeledPage(String sCheckbox, String arg2, String arg3) throws Throwable {
		try {
			if (sCheckbox.equalsIgnoreCase("Tick")) {
				if(!(MIQActionsClass.isCheckBoxChecked(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox))) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox, 3);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox, "Can edit on website checkbox");
				} 

			} else if (sCheckbox.equalsIgnoreCase("Untick")) {
				if((MIQActionsClass.isCheckBoxChecked(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox))) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox, 3);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox, "Can edit on website checkbox");
				} 
			}
				
		}
		catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to "+sCheckbox+" check box labeled  " + arg2+ " at "+arg3+ " page" );
		}

	}

	@Then("^Click \"([^\"]*)\" at Report Branding Change header page$")
	public void clickReportBrandingChangeHeaderPage(String sSave) throws Throwable {
		try {
			if (sSave.equalsIgnoreCase("Save Header")) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SaveHeader_Button, 25);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SaveHeader_Button, "Save Header");
				} 

			 else if (sSave.equalsIgnoreCase("Save Footer")) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SaveFooter_Button, 25);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SaveFooter_Button, "Save Footer");
				
			}
				
		}
		catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sSave+ " at Report Branding Change header page" );
		}
	}
	
	@Then("^Check successfull confirmation message \"([^\"]*)\"$")
	public void checkSuccessfullConfirmationMessage(String sNotifySucessMessage) throws Throwable {
		try {
		MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_NotificationMessage, 3);
			String Error=MIQActionsClass.getElementText(LoginObjects.admin_ReportBrandingManager_NotificationMessage, "NotifyMessage");
			Assert.assertEquals(Error, sNotifySucessMessage);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check successfull confirmation message " +sNotifySucessMessage);
		}
	}
	
	@Then("^Click on \"([^\"]*)\" and Check reset confirmation slide appears$")
	public void clickAndCheckResetConfirmationSlideAppears(String sReset) throws Throwable {
		try {
//			if (sReset.equalsIgnoreCase("Reset Header")) {
			Thread.sleep(3000);
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, 3);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, "Reset Header");
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog, 5);
					MIQActionsClass.isElementVisible(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog, "Reset Header Dialog");
					
	//			} 

//			 else if (sReset.equalsIgnoreCase("Reset Footer")) {
//				 MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, 3);
//					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, "Reset Header");
//					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog, 5);
//					MIQActionsClass.isElementVisible(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog, "Reset Header Dialog");
//				
//			}
//				
	}
		catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sReset+ " and Check reset confirmation slide appears" );
		}
	}

	@Then("^Click \"([^\"]*)\" button and reset confimation slides disappear and \"([^\"]*)\" remains the same$")
	public void clickButtonResetConfimationSlidesDisappear(String sButton, String arg2) throws Throwable {
		try {
			if (sButton.equalsIgnoreCase("Cancel")) {
				MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Cancel_Button, 3);
				MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Cancel_Button, "Reset Header");
				Thread.sleep(3000);
				MIQActionsClass.isElementNotVisible(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog, "Reset Header Dialog");
				if(arg2.equals("header")) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, 3);
					String ResetHeader=MIQActionsClass.getElementText(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, "Reset header");
					Assert.assertEquals(ResetHeader, "Reset header to subscription default");
					
					MIQLog.info("Reset confimation slides disappear and " +arg2+ " remains the same");
					}
					else {
						MIQLog.info("failed to check Reset confimation slides disappear and " +arg2+ " remains the same");
						Assert.fail("failed to check Reset confimation slides disappear and " +arg2+ " remains the same");
					}
			}

			 else if (arg2.equalsIgnoreCase("footer")) {
			MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Cancel_Button, 3);
				MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Cancel_Button, "Reset Header");
				Thread.sleep(3000);
				MIQActionsClass.isElementNotVisible(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog, "Reset Header Dialog");
				if(arg2.equals("footer")) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, 3);
					String ResetHeader=MIQActionsClass.getElementText(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, "Reset header");
					Assert.assertEquals(ResetHeader, "Reset footer to subscription default");
					
					MIQLog.info("Reset confimation slides disappear and " +arg2+ " remains the same");
					}
					else {
						MIQLog.info("failed to check Reset confimation slides disappear and " +arg2+ " remains the same");
						Assert.fail("failed to check Reset confimation slides disappear and " +arg2+ " remains the same");
					}
				
		}
		}
		catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sButton+ " and reset confimation slides disappear and " +arg2+ " remains the same");
		}
	}

	@Then("^Click \"([^\"]*)\" button and check The succes notification appears and the \"([^\"]*)\" is reset to the default \"([^\"]*)\"$")
	public void clickButtonAndNotifySucessMessge(String sButton, String arg2, String arg3) throws Throwable {
	  	try {
		//	if (sButton.equalsIgnoreCase("Confirm")) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Confirm_Button, 3);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_Dialog_Confirm_Button, "Confirm");
					String ResetHeader=MIQActionsClass.getElementText(LoginObjects.admin_ReportBrandingManager_NotificationMessage, "Notification Message");
					if(sButton.equals("Confirm")) {
						
						Assert.assertEquals(ResetHeader, "Your changes have been saved successfully.");
						MIQLog.info("Sucess confimation message appears");
						}
						else {
							MIQLog.info("Failed to check successfull confirmation message" );
							Assert.fail("Failed to check successfull confirmation message" );
						}
			Thread.sleep(3000);
					MIQActionsClass.isElementNotVisible(LoginObjects.admin_ReportBrandingManager_ChangeHeader_ResetHeader_link, "Reset Header Link");
				

//			 else if (sButton.equalsIgnoreCase("Untick")) {
//					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox, 3);
//					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeHeader_SetHeaderSubscriptionDefault_CheckBox, "Can edit on website checkbox");
//				
//			}
				
		}
		catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to Click on " + sButton+ " button and check The succes notification appears and the " +arg2+ " is reset to the default" +arg3);
		}
	}
	@Then("^\"([^\"]*)\" check box labeled \"([^\"]*)\" at \"([^\"]*)\" page for footer$")
	public void checkBoxFooter(String sCheckbox, String arg2, String arg3) throws Throwable {
		try {
			if (sCheckbox.equalsIgnoreCase("Tick")) {
				if(!(MIQActionsClass.isCheckBoxChecked(LoginObjects.admin_ReportBrandingManager_ChangeFooter_SetFooterSubscriptionDefault_CheckBox))) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_SetFooterSubscriptionDefault_CheckBox, 3);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_SetFooterSubscriptionDefault_CheckBox, "Footer checkbox");
				} 

			} else if (sCheckbox.equalsIgnoreCase("Untick")) {
				if((MIQActionsClass.isCheckBoxChecked(LoginObjects.admin_ReportBrandingManager_ChangeFooter_SetFooterSubscriptionDefault_CheckBox))) {
					MIQActionsClass.waitForElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_SetFooterSubscriptionDefault_CheckBox, 3);
					MIQActionsClass.clickOnElement(LoginObjects.admin_ReportBrandingManager_ChangeFooter_SetFooterSubscriptionDefault_CheckBox, "Footercheckbox");
				} 
			}
				
		}
		catch (Exception e) {

			MIQExceptionHandle.HandleException(e, "Failed to "+sCheckbox+" Chekbox " + arg2+ " at "+arg3+ " page for footer" );
		}

	}
	
	@Given("^Enter \"([^\"]*)\" in \"([^\"]*)\" at \"([^\"]*)\" page$")
	public void enterDetailsPage(String sValue, String arg2, String arg3) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_TextField, 5);
			MIQActionsClass.typeInTextBox(LoginObjects.propertySearch_PropertyDescrtipionGrid_TextField,sValue, "Property Description");
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to enter " +sValue);
			}
	}

	@Then("^Select the \"([^\"]*)\" record from the Search Results$")
	public void selectRecordSearchResults(String arg1) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_ResultsTable, 5);
			MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_ResultsTable, arg1);
			
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to select" +arg1+"record from the Search Results");
			}
	}

	@Then("^Check An east panel should appear with additional \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void checkEastPanelAppearWithAdditional(String arg1, String arg2, String arg3) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyDescrtipionGrid_EastPanel, 5);
			MIQActionsClass.isElementVisible(LoginObjects.propertySearch_PropertyDescrtipionGrid_EastPanel, "East panel");
			MIQActionsClass.isElementVisible(LoginObjects.propertySearch_EastPanel_PropertyInformation, "Property Information");
			MIQActionsClass.isElementVisible(LoginObjects.propertySearch_EastPanel_ReportsGenerated, "Reprots Generated");
			MIQActionsClass.isElementVisible(LoginObjects.propertySearch_PropertyDescrtipionGrid_PersonalNotes, "Personal Notes");
			
			Name1 = MIQActionsClass.getElementText(LoginObjects.propertyInformationName, "Property Report");
			
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to check successfull confirmation message " +arg1);
			}
	}
	@And ("^Click on \"(.*)\" for Property Report$")
    public void clickOnPropertyReport(String sPropertyReport) throws Throwable {
        try {
        	if (sPropertyReport.equalsIgnoreCase("Generate Report")) {
            MIQActionsClass.waitForElement(LoginObjects.generateReport, 5);
            MIQActionsClass.clickOnElement(LoginObjects.generateReport, "Generate Report");
        	}    else if (sPropertyReport.equalsIgnoreCase("Email")) {
				
        		   MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyReport_Email_button, 5);
                   MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyReport_Email_button, "Email");	
				
			}  else if(sPropertyReport.equalsIgnoreCase("PDF Version"))
            {
           	 MIQActionsClass.waitForElement(LoginObjects.pdfVersion, 20);
                MIQActionsClass.clickOnElement(LoginObjects.pdfVersion, "pdfVersion");
           }  
        
    } catch (Exception e) {
                e.printStackTrace();
                MIQExceptionHandle.HandleException(e, "Failed to Click Property Report");
            }
    }
	@Then("^Check an east panel should appear where the user is able to input E-Mail Address $")
	public void checkEastPanelAppearInputEMailAddress() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyReport_EastPanel, 5);
			MIQActionsClass.isElementVisible(LoginObjects.propertySearch_PropertyReport_EastPanel, "East panel");
			MIQActionsClass.isElementEnabled(LoginObjects.propertySearch_PropertyReport_EastPanel_Email_TextBox);
			
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to check successfull confirmation message " );
			}
	}
	@Then("^Enter a \"([^\"]*)\" E-Mail address and click the \"([^\"]*)\" sign at Email report east panel$")
	public void enterEMailAddressClickEmailReportEastPanel(String sEmail, String arg2) throws Throwable {
		try {
			String semail = MIQUtils.getProperty(sEmail);
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyReport_EastPanel_Email_TextBox, 3);
			MIQActionsClass.typeInTextBox(LoginObjects.propertySearch_PropertyReport_EastPanel_Email_TextBox, semail, "Email Address");
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyReport_EastPanel_Plus_Button, 3);
			 MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyReport_EastPanel_Plus_Button, "Email");
			
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to check successfull confirmation message " );
			}
	}

	@Then("^Click \"([^\"]*)\" button at \"([^\"]*)\" east panel$")
	public void clickButtonEastPanel(String sValue, String arg2) throws Throwable {
		try {
			if (sValue.equalsIgnoreCase("Send E-Mail")) {
			MIQActionsClass.waitForElement(LoginObjects.propertySearch_PropertyReport_EastPanel_Save_Button, 3);
			 MIQActionsClass.clickOnElement(LoginObjects.propertySearch_PropertyReport_EastPanel_Save_Button, "Email");
			
			}else if (sValue.equalsIgnoreCase("Cancel")) {
			
			}
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to check successfull confirmation message " );
			}
	}
	
	@Then("^Check The Property Report shown on screen should be sent in the form of a pdf attachment to the respective EMail address$")
	public void checkPropertyReport_E_Mail_address() throws Throwable {
	   
	}
	
	@Then("^Get the property name and address values from the report$")
	public void getPropertyAndAddress() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.PdfReport_propertyName, 200);
			PropertyName_report=MIQActionsClass.getElementText(LoginObjects.PdfReport_propertyName, "PdfReport_propertyName");
			AddressName_report=MIQActionsClass.getElementText(LoginObjects.PdfReport_Address, "PdfReport_Address");
			System.out.println(PropertyName_report+"AddressName_report"+AddressName_report);
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to get the values from report");
			}
	}

	@Then("^verify \"([^\"]*)\" property report dowloaded by clicking on pdf version$")
	public void exportPDFReport(String sDoc) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.pdfVersion, 15);
			MIQActionsClass.clickOnElement(LoginObjects.pdfVersion, "Pdf");
			
			// WDActionsClass.selectByIndex(LoginObjects.Export_Dropdown ,arg2 );
			Thread.sleep(30000);
			System.out.println(sDoc);
			docName = MetroIQ_Utility.VerifyDownloadedFile.isFileDownloadedName(System.getProperty("user.home") + "//Downloads", sDoc);
			System.out.println(docName);
			Assert.assertFalse(docName.isEmpty());
			System.out.println("PDF report downlaoded" +sDoc+"property report dowloaded by clicking on pdf version");

		} catch (Exception e) {
			e.printStackTrace();
			ExceptionHandle.HandleException(e, "Failed to Verify");
		}
	}
	
	@And("^Check content in pdf report of property$")
	 public static void checkContentPDFReport() throws Throwable {
			try {
				Thread.sleep(3000);
				String contentInPdf = MIQActionsClass.checkDataFromPDF(docName);
				MetroIQ_Utility.VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");

				String ActualText = contentInPdf.replace("\r\n", "");
				ActualText=ActualText.toLowerCase();
				System.out.println(ActualText);
				System.out.println(PropertyName_report+AddressName_report);				
				Assert.assertTrue(ActualText.contains(PropertyName_report.toLowerCase()));
				Assert.assertTrue(ActualText.contains(AddressName_report.toLowerCase()));
			
				
			} catch (Exception e) {
				MetroIQ_Utility.VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
				e.printStackTrace();
				ExceptionHandle.HandleException(e, "Content of pdf is not matched");
			}
		}
	@And ("^Validate if \"(.*)\" is successfully generated using the same \"(.*)\"$")
    public void validatePropertyReport(String sPropertyReport, String sReportName) throws Throwable {
        try {
            
            MIQActionsClass.waitForElement(LoginObjects.properReportTitle, 100);
            MIQActionsClass.isElementVisible(LoginObjects.properReportTitle, "Generate Report");
            MIQActionsClass.waitForElement(LoginObjects.propertyDescriptionName, 200);
           String newStr = MIQActionsClass.getElementText(LoginObjects.propertyDescriptionName, "Property Report");
           Name2 = newStr.replaceAll("CapeTown", "CAPE TOWN");
           assertEquals(Name1,Name2);
           Thread.sleep(3000);
                        
        
    } catch (Exception e) {
                e.printStackTrace();
                MIQExceptionHandle.HandleException(e, "Failed to Validate Property Report");
            }
    }
	

	@When("^Select \"([^\"]*)\" at \"([^\"]*)\" dropdown value$")
	public void selectDropdownValue(String sTitle, String arg2) throws Throwable {
		try {
			Thread.sleep(2000);
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//div[@class='ui-layout-resizer ui-layout-resizer-east ui-layout-resizer-closed ui-layout-resizer-east-closed']//following-sibling::ul//li"));
			
		for (int i = 0; i < getList.size(); i++) {
			if (getList.get(i).getText().equals(sTitle)) {
				getList.get(i).click();
				break;
			}
		}
	
} catch (Exception e) {
	MIQExceptionHandle.HandleException(e, " Failed to select "+sTitle+ "at"+arg2+ " dropdown");
}
	    
	}
}
