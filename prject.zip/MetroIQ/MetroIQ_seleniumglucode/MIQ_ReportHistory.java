package MetroIQ_seleniumglucode;

import java.time.LocalDateTime;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import MIQ_accelerators.MIQActionsClass;
import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_AdminObjects;
import MetroIQ_PageObjects.MIQ_PropertyListObjects;
import MetroIQ_PageObjects.MIQ_ReportHistoryObjects;
import MetroIQ_Utility.MIQExceptionHandle;
import MetroIQ_Utility.MIQUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

public class MIQ_ReportHistory {
	public static String currentAOI;
	public static String currentReportName;
	@And("^Check Report history page is opened$")
	public void verifyReportHistoryPage() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.pageTitle, 15);
			String title=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageTitle, "pageTitle");
			Assert.assertEquals(title, "Report history");
			
			String Description=MIQActionsClass.getElementText(MIQ_PropertyListObjects.pageDescription, "pageDescription");	
			Assert.assertTrue(Description.contains("View previous reports generated."));	
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Report history page not opened");
		}
	}
	
	@And("^Check columns displayed in Report history table for \"([^\"]*)\" report type$")
	public void CheckColumnsInReportHistory(String sType) throws Throwable {
		try {
			System.out.println(MIQ_ReportHistoryObjects.ReportHistoryTable+"Report Description"+"']");
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_ReportHistoryObjects.ReportHistoryTable+"Report Description"+"']"), "Report Description"));
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_ReportHistoryObjects.ReportHistoryTable+"Area Name"+"']"), "Area Name"));
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_ReportHistoryObjects.ReportHistoryTable+"Report Type"+"']"), "Report Type"));
			Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_ReportHistoryObjects.ReportHistoryTable+"Requested"+"']"), "Requested"));
			
			if(sType.equalsIgnoreCase("My Company's Reports")) {
				Assert.assertTrue(MIQActionsClass.isElementVisible(By.xpath(MIQ_ReportHistoryObjects.ReportHistoryTable+"User"+"']"), "User"));

			}

		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check the Columns");
			}
	}
	
	@And("^select \"([^\"]*)\" in show drop down$")
	public void SelectShowReportType(String sType) throws Throwable {
		try {
			
			MIQActionsClass.selectByVisibleText(MIQ_ReportHistoryObjects.report_dropdown, sType);
			String selectedOption=MIQActionsClass.GetSelectedValue(MIQ_ReportHistoryObjects.report_dropdown);
			Assert.assertEquals(selectedOption, sType);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to check the disabled/enabled user");
			}
	}
	
	@And("^Check show drop down is displayed$")
	public void checkShowDropdown() throws Throwable {
		try {
			Assert.assertTrue(MIQActionsClass.isElementVisible(MIQ_ReportHistoryObjects.show_label, "show_label"));
			Assert.assertTrue(MIQActionsClass.isElementVisible(MIQ_ReportHistoryObjects.report_dropdown, "report_dropdown"));

			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Report history page not opened");
		}
	}
	
	@And("^verify the area name of all reports$")
	public void CheckFilteredProperties() throws Throwable {
		try {
//			Thread.sleep(10000);
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.ReportHistory_AOI, 5);
			java.util.List<WebElement> AOIValue =MIQActionsClass.getElements(MIQ_ReportHistoryObjects.ReportHistory_AOI);
			for(int i=0; i<AOIValue.size(); i++) {
				String AOI=AOIValue.get(i).getText();
				System.out.println(AOI+" "+i);
				if(!(AOI.equals(" "))) {
				Assert.assertTrue(AOI.equalsIgnoreCase(currentAOI));
				}
			}
			
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Area of interest didn't match");
		}
	}
	
	@And("^get the current AOI for Report History$")
	public void getCurrentAOI() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.currentAOI, 5);
			currentAOI=	MIQActionsClass.getElementText(MIQ_PropertyListObjects.currentAOI, "CurrentAOI");
			System.out.println(currentAOI);
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "get the current AOI");
		}
	}
	@And("^select \"([^\"]*)\" report type dropdown$")
	public void SelectReportType(String sType) throws Throwable {
		try {
			
			MIQActionsClass.selectByVisibleText(MIQ_ReportHistoryObjects.ReportHistory_ReportType_dropdown, sType);
			String selectedOption=MIQActionsClass.GetSelectedValue(MIQ_ReportHistoryObjects.ReportHistory_ReportType_dropdown);
			Assert.assertEquals(selectedOption, sType);
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to select report type");
			}
	}	
	
	@And("^verify the filtered reports with type \"([^\"]*)\"$")
	public void CheckFilteredReports(String sValue) throws Throwable {
		try {
//			Thread.sleep(10000);
			String footer=MIQActionsClass.getElementText(MIQ_ReportHistoryObjects.ReportHistory_footer, "Footer");
			if(!(footer.contains("No records to view"))) {
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.ReportHistory_ReportType, 25);
			java.util.List<WebElement> ReportValue =MIQActionsClass.getElements(MIQ_ReportHistoryObjects.ReportHistory_ReportType);
			for(int i=0; i<ReportValue.size(); i++) {
				String type=ReportValue.get(i).getText();
				System.out.println(type);
				Assert.assertEquals(type, sValue);
			}
			
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Report type should not match");
		}
	}
	
	@And("^click on \"([^\"]*)\" link any report$")
	public void CreateCurrentReport(String sValue) throws Throwable {
		try {
//			Thread.sleep(10000);
			String footer=MIQActionsClass.getElementText(MIQ_ReportHistoryObjects.ReportHistory_currentReport, "currentReport");
			if(!(footer.contains("No records to view"))) {
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.ReportHistory_currentReport, 5);
			java.util.List<WebElement> ReportValue =MIQActionsClass.getElements(MIQ_ReportHistoryObjects.ReportHistory_currentReport);
			for(int i=0; i<ReportValue.size(); i++) {
				String type=ReportValue.get(i).getText();
				System.out.println(type);
				if(type.equalsIgnoreCase(sValue)) {
					ReportValue.get(i).click();
				break;	
				}
//				Assert.assertEquals(type, sValue);
			}
			
			}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Create current report link not found");
		}
	}
	
	@When("^Enter report name \"([^\"]*)\" on dailog$")
	public void EnterCurrentReportName(String sName) {
		try {
			LocalDateTime myObj = LocalDateTime.now();
			sName=sName+myObj;
			currentReportName=sName;
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.currentReport_DailogText, 3);
			MIQActionsClass.typeInTextBox(MIQ_ReportHistoryObjects.currentReport_DailogText, sName, "Current Report name");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter Username");
		}
	}

	@And("^verify dailog should open with text \"([^\"]*)\"$")
	public void checkDailogMessage(String sMessage) throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.currentReport_Dailog, 15);
		String Message=	MIQActionsClass.getElementText(MIQ_ReportHistoryObjects.currentReport_DailogMessage, "DailogMessage");
//			System.out.println(currentAOI);
			Assert.assertTrue(Message.equalsIgnoreCase(sMessage));
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "get the current AOI");
		}
	}
	
	@And("^click on confirm button$")
	public void clickOnConfirm() throws Throwable {
		try {
			
			MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.currentReport_DailogConfirm, "confirm button");
			Thread.sleep(3000);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "get the current AOI");
		}
	}
	@And("^Check and accept the Report Created dailog$")
	public void checkReportCreatedDailog() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.CreatedcurrentReport_DailogMessage, 15);
			String Message=	MIQActionsClass.getElementText(MIQ_ReportHistoryObjects.CreatedcurrentReport_DailogMessage, "DailogMessage");
//				System.out.println(currentAOI);
				Assert.assertTrue(Message.equalsIgnoreCase("A new Current Report has been created successfully"));
				MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.CreatedcurrentReport_DailogOK, "Ok button");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "current report not created");
		}
	}
	
	@And("^Click on first property report$")
	public void clickOnFirstRecord() throws Throwable {
		try {
			
			MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.ReportHistory_Row1, "First Record");
			Thread.sleep(3000);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "not able to click first record");
		}
	}
	@And("^verify and click on \"([^\"]*)\" button$")
	public void verifyAndClick(String sButton) throws Throwable {
		try {
			if(sButton.equalsIgnoreCase("Email")) {
				MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.ReportHistory_Email, 300);
			Assert.assertTrue(MIQActionsClass.isElementVisible(MIQ_ReportHistoryObjects.ReportHistory_Email, "Email"));

			MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.ReportHistory_Email, "Email");
			Thread.sleep(3000);
			} 
			else if(sButton.equalsIgnoreCase("Send Email")) {
				Assert.assertTrue(MIQActionsClass.isElementVisible(MIQ_ReportHistoryObjects.ReportHistory_SendEmail, "SendEmail"));

				MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.ReportHistory_SendEmail, "SendEmail");
//				Thread.sleep(3000);
			}

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Email is not visible");
		}
	}
	@And("^check the success message for email$")
	public void checkEmailSuccess() throws Throwable {
		try {
			
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.ReportHistory_EmailSuccess, 5);
		String Message=	MIQActionsClass.getElementText(MIQ_ReportHistoryObjects.ReportHistory_EmailSuccess, "EmailSuccess");
//			System.out.println(currentAOI);
			Assert.assertTrue(Message.equalsIgnoreCase("Email successfully sent"));
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Email successfully sent message not displayed");
		}
	}
	
	@And("^Click on last page$")
	public void clickOnLastPage() throws Throwable {
		try {
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.CurrentReport_LastPage, 25);
			MIQActionsClass.clickOnElement(MIQ_ReportHistoryObjects.CurrentReport_LastPage, "Last page button");
			Thread.sleep(10000);
		

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "get the current AOI");
		}
	}
	
	@And("^verify the current report is created with given name$")
	public void CheckCurrentReportName() throws Throwable {
		try {
			Thread.sleep(5000);
			MIQActionsClass.waitForElement(MIQ_ReportHistoryObjects.CurrentReport_Description, 100);
			java.util.List<WebElement> DecValue =MIQActionsClass.getElements(MIQ_ReportHistoryObjects.CurrentReport_Description);
			int count=0;
			System.out.println(DecValue.size()+"size");
			for(int i=0; i<DecValue.size(); i++) {
				String Desc=DecValue.get(i).getText();
				System.out.println(Desc);
				if(Desc.equalsIgnoreCase(currentReportName)) {
					System.out.println("current report name");
					count=count+1;
				}
			}
			Assert.assertTrue(count!=0);
			
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "get the current AOI");
		}
	}
}
