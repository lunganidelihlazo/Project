package MetroIQ_seleniumglucode;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import MIQ_accelerators.MIQBase;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;


import com.cucumber.MIQlistener.MIQReport;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import winDeed_utility.VerifyDownloadedFile;

//import rc_accelerators.RCActionsClass;
//import rc_pageobjects.RCLoginObjects;
//import rc_utility.RCExceptionHandle;

import MetroIQ_PageObjects.LoginObjects;
import MetroIQ_PageObjects.MIQ_MapViewObjects;
import MetroIQ_PageObjects.MIQ_PropertyListObjects;
import MIQ_accelerators.MIQActionsClass;
import MetroIQ_Utility.MIQLog;
import MetroIQ_Utility.MIQUtils;
import MetroIQ_Utility.MIQExceptionHandle;

public class MIQ_TransferReport {
	static Boolean sSelectedCheckbox,sSelectedCheckbox1,sSelectedCheckbox2;
	static String sFileTransfer,sTextSelectedCheckbox1,sTextSelectedCheckbox2;
	static String CurrentReportDescription,sStreetName,sSuburbValue,docName,sOfficialDescriptionValue,sPropertyTypeValue;
	static String FirstRecordOfficialDescriptionText,FirstRecordErfPortionText,FirstRecordPropertyTypeText,FirstRecordStreetText,FirstRecordStreetAddressText,FirstRecordSuburbText,FirstRecordTitleDeedText,FirstRecordExtentText,FirstRecordRemainingExtentText,FirstRecordPriceText,FirstRecordPurchaseDateText,FirstRecordRegistrationDateText,FirstRecordCaptureDateText;
	static String SecondRecordOfficialDescriptionText,SecondRecordErfPortionText,SecondRecordPropertyTypeText,SecondRecordStreetText,SecondRecordStreetAddressText,SecondRecordSuburbText,SecondRecordTitleDeedText,SecondRecordExtentText,SecondErfPart,SecondRecordRemainingExtentText,SecondRecordPriceText,SecondRecordPurchaseDateText,SecondRecordRegistrationDateText,SecondRecordCaptureDateText;
	static String SecondRecordPDFRemainingExtentText,SecondRecordPDFCapitalSuburbText,SecondRecordPDFExtentText,FirstRecordPDFCapitalSuburbText,ErfPart,FirstRecordPDFOfficialDescriptionText,FirstRecordPDFExtentText,FirstRecordPDFRemainingExtentText,FirstRecordPDFPriceText,FirstRecordPDFPurchaseDateText,FirstRecordPDFRegistrationDateText,FirstRecordPDFCaptureDateText;
	static String ThirdRecordPDFOfficialDescriptionText,ThirdRecordCapitalPDFSuburbText,ThirdRecordOfficialDescriptionText,ThirdRecordErfPart,ThirdRecordErfPortionText,ThirdRecordPropertyTypeText,ThirdRecordStreetText,ThirdRecordStreetAddressText,ThirdRecordSuburbText,ThirdRecordTitleDeedText,ThirdRecordPDFExtentText,ThirdRecordExtentText,ThirdRecordPDFRemainingExtentText,ThirdRecordRemainingExtentText,ThirdRecordPDFPriceText,ThirdRecordPriceText,ThirdRecordPDFPurchaseDateText,ThirdRecordPurchaseDateText,ThirdRecordPDFRegistrationDateText,ThirdRecordRegistrationDateText,ThirdRecordPDFCaptureDateText,ThirdRecordCaptureDateText;
	static String FourthRecordOfficialDescriptionText,FourthRecordErfPart,FourthRecordErfPortionText,FourthRecordPropertyTypeText,FourthRecordStreetText,FourthRecordStreetAddressText,FourthRecordSuburbText,FourthRecordTitleDeedText,FourthRecordPDFExtentText,FourthRecordExtentText,FourthRecordPDFRemainingExtentText,FourthRecordRemainingExtentText,FourthRecordPriceText,FourthRecordPurchaseDateText,FourthRecordRegistrationDateText,FourthRecordCaptureDateText;
	
	@Then("^User should be navigated to the \"([^\"]*)\" page$")
	public void userDirectedPage(String sMessage) throws Throwable {
		try {
			Thread.sleep(3000);
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_Page_Title, 5);
			
			if(MIQActionsClass.isElementVisible(LoginObjects.transferReprot_Page_Title, "Transfer Report Title")) {
				String Text = MIQActionsClass.getElementText(LoginObjects.transferReprot_Page_Title, "Transfer Report Title"); 
	            assertEquals(Text,sMessage);
	            
			}
			else {
				Assert.fail("Failed to check User should be direced to the"+sMessage+ " page");
				MIQLog.info("Failed to check User should be direced to the"+sMessage+ " page");
			}	

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check User should be direced to theb"+sMessage+ " page");
		}
	}
	@Then("^Check the validation message \"([^\"]*)\"$")
	public void checkValidationMessage(String sMessage) throws Throwable {
		try {
			   MIQActionsClass.waitForElement(LoginObjects.transferReprot_GenerateReport_Error_Message, 5);
				String Text = MIQActionsClass.getElementText(LoginObjects.transferReprot_GenerateReport_Error_Message,sMessage );    
	            assertEquals(Text,sMessage);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check User should be direced to theb"+sMessage+ " page");
		}
	}
	@Then("^Select \"([^\"]*)\" from the \"([^\"]*)\" field Dropdown$")
	public void selectFromFieldDropdown(String sVisibletext, String sValue) throws Throwable {
		try {
			sFileTransfer = sVisibletext;
			
			if (sValue.equalsIgnoreCase("Filter Transfers by")) {
			   MIQActionsClass.waitForElement(LoginObjects.transferReprot_FileTransfer_Dropdown, 5);
			   MIQActionsClass.selectByVisibleText(LoginObjects.transferReprot_FileTransfer_Dropdown, sVisibletext);
			}	else if (sValue.equalsIgnoreCase("Export")) {
				
				MIQActionsClass.waitForElement(LoginObjects.transferReprot_SummarySection_Export_Dropdown, 5);
				MIQActionsClass.selectByVisibleText(LoginObjects.transferReprot_SummarySection_Export_Dropdown, sVisibletext);
			
			}

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to select" +sVisibletext+ "from the "+sValue+ " field Dropdown");
		}
	}

	@Then("^Validate \"([^\"]*)\" should be selected$")
	public void validateShouldSelected(String sValue) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_FileTransfer_Dropdown, 5);
			String Text = MIQActionsClass.GetSelectedValue(LoginObjects.transferReprot_FileTransfer_Dropdown);
			assertEquals(Text, sValue);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate"+sValue+" be selected");
		}
	}
	

	@Then("^Click on \"([^\"]*)\" by ticking radio button$")
	public void clickTickingRadiobutton(String sCheck) throws Throwable {
		try {
		MIQActionsClass.waitForElement(LoginObjects.transferReprot_SpecifiedDateRange_Checkbox, 5);
		sSelectedCheckbox=MIQActionsClass.isCheckBoxChecked(LoginObjects.transferReprot_SpecifiedDateRange_Checkbox);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate"+sCheck);
		}
	}

	@Then("^Validate \"([^\"]*)\" is checked$")
	public void validateChecked(String sCheck) throws Throwable {
		try {
			
		assertEquals(sSelectedCheckbox,false);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate"+sCheck);
		}
	}

	@Given("^Select \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" by using values \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" in From field from Specified Date Range$")
	public void selectFromFieldSpecifiedDateRange(String arg1, String arg2, String arg3, int sMonthDropdownValue, String sYearDropdownValue, String sDate) throws Throwable {
		try {

			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SpecifiedDateRange_From_DatePicker, 3);
			MIQActionsClass.clickOnElement(LoginObjects.transferReprot_SpecifiedDateRange_From_DatePicker, "Date picker from text field");
			MIQActionsClass.selectByIndex(LoginObjects.transferReprot_SpecifiedDateRange_DatePicker_Month,sMonthDropdownValue );
			MIQActionsClass.selectByVisibleText(LoginObjects.transferReprot_SpecifiedDateRange_DatePicker_Year, sYearDropdownValue);
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//td[@data-event='click']//a"));
			for(int i = 0; i <getList.size(); i++) {
				if(getList.get(i).getText().contains(sDate))
				{
					getList.get(i).click();
					System.out.println(getList.get(i));
					break;
				}
			}
		}

		catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to select on "+sMonthDropdownValue+" "+sYearDropdownValue+" "+sDate+" in From Specified Date Range");
		}  
	}

	@Given("^Select \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" by using values \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" in To field from Specified Date Range$")
	public void selectTofieldFromSpecifiedDateRange(String arg1, String arg2, String arg3, int sMonthDropdownValue, String sYearDropdownValue, String sDate) throws Throwable {
		try {

			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SpecifiedDateRange_To_DatePicker, 3);
			MIQActionsClass.clickOnElement(LoginObjects.transferReprot_SpecifiedDateRange_To_DatePicker, "Date picker To text field");
			MIQActionsClass.selectByIndex(LoginObjects.transferReprot_SpecifiedDateRange_DatePicker_Month,sMonthDropdownValue );
			MIQActionsClass.selectByVisibleText(LoginObjects.transferReprot_SpecifiedDateRange_DatePicker_Year, sYearDropdownValue);
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//table[@class='ui-datepicker-calendar']//td//a"));
			for(int i = 0; i <getList.size(); i++) {
				if(getList.get(i).getText().contains(sDate))
				{
					getList.get(i).click();
					break;
				}
			}
		}

		catch(Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to select on "+sMonthDropdownValue+" "+sYearDropdownValue+" "+sDate+" in To Specified Date Range");
		}  
	}
	@Then("^Uncheck all property types for \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", and \"([^\"]*)\"$")
	public void uncheckAllpropertyTypes(String arg1, String arg2, String arg3, String arg4) throws Throwable {
		try {
			
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//ul[@class='consumerApplicationsCheckbox']//input[@type='checkbox']//following-sibling::label"));

			for(int i = 0; i <getList.size(); i++) {
				{
					getList.get(i).click();
					
				}
			}
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to uncheck all Property types");
			}
	}

	@Then("^Click the property type \"([^\"]*)\" from \"([^\"]*)\"$")
	public void clickPropertyType(String sPropertyType, String arg2) throws Throwable {
		try {
			
				if(!(MIQActionsClass.isCheckBoxChecked(By.xpath(LoginObjects.transferReprot_PropertyTypes_Label1 + sPropertyType + LoginObjects.transferReprot_PropertyTypes_Label2)))) {
					Thread.sleep(3000);
					MIQActionsClass.clickOnElement(By.xpath(LoginObjects.transferReprot_PropertyTypes_Label1 + sPropertyType + LoginObjects.transferReprot_PropertyTypes_Label2), sPropertyType);
				} 
		
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to click the property type "+arg2);
			}
	}
	
	@Then("^Check From \"([^\"]*)\" and To \"([^\"]*)\" date be captured in the field$")
	public void checkFromToDateField(String sFromDate, String sToDate) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SpecifiedDateRange_From_DatePicker, 3);
		String sFrom=MIQActionsClass.getAttribute(LoginObjects.transferReprot_SpecifiedDateRange_From_DatePicker, "value", "From Date");
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SpecifiedDateRange_To_DatePicker, 3);
			String sTo=MIQActionsClass.getAttribute(LoginObjects.transferReprot_SpecifiedDateRange_To_DatePicker, "value", "From Date");
			assertEquals(sFromDate,sFrom);
			assertEquals(sToDate,sTo);
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to validate From and To date capute in the fields");
			}
	}

	@Then("^Validate a report should be generated successfully and should only display properties that are of type \"([^\"]*)\"$")
	public void validateReportGeneratedsuccessfullyPage(String sType) throws Throwable {
		String sOption = "";
		MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsPage, 300);
		MIQActionsClass.isElementVisible(LoginObjects.transferReprot_ResultsPage, "Transfer Report Results page");	
		try {
		List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//td[@aria-describedby='transfersResultTable_PropertyType']"));
		for (int i = 0; i < getList.size(); i++) {
			sOption = getList.get(i).getText();
			assertEquals(sOption, sType);
		}
	
	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to validate From and To Date");
	}

}
	@Then("^Uncheck the property type \"([^\"]*)\" from \"([^\"]*)\"$")
	public void uncheckPropertyTypeFrom(String sPropertyType, String arg2) throws Throwable {
		try {
			
			if(!(MIQActionsClass.isCheckBoxChecked(By.xpath(LoginObjects.transferReprot_PropertyTypes_Label1 + sPropertyType + LoginObjects.transferReprot_PropertyTypes_Label2)))) {
				Thread.sleep(3000);
				MIQActionsClass.clickOnElement(By.xpath(LoginObjects.transferReprot_PropertyTypes_Label1 + sPropertyType + LoginObjects.transferReprot_PropertyTypes_Label2), sPropertyType);
			} 
	
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to uncheck the property type"+sPropertyType+"from"+arg2);
		}
	}
	
	@Then("^Enter Current Report Description \"([^\"]*)\"$")
	public void enterCurrentReportDescription(String sDescription) throws Throwable {
		try {
			CurrentReportDescription=sDescription;
		MIQActionsClass.waitForElement(LoginObjects.transferReprot_CurrentReportDescription_TextField, 3);
		MIQActionsClass.typeInTextBox(LoginObjects.transferReprot_CurrentReportDescription_TextField, CurrentReportDescription, sDescription);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter "+sDescription);
		}
	}

	@Then("^\"([^\"]*)\" the Create Current Report at \"([^\"]*)\" page$")
	public void createCurrentReport(String arg1, String arg2) throws Throwable {
		try {
		if(!(MIQActionsClass.isCheckBoxChecked(LoginObjects.transferReport_CreateCurrentReport_Checkbox))) {
			Thread.sleep(3000);
			MIQActionsClass.clickOnElement(LoginObjects.transferReport_CreateCurrentReport_Checkbox, "Create current Report");
		} 

	} catch (Exception e) {
		MIQExceptionHandle.HandleException(e, "Failed to " +arg1+ "Create current Report");
	}
	}
	
	@Then("^Check all fields should be reset to their default values$")
	public void checkAllFieldsResetDefaultValues() throws Throwable {
		try {
			List<WebElement>  checkbox = MIQActionsClass.getElements(By.xpath("//ul[@class='consumerApplicationsCheckbox']//input[@type='checkbox']//following-sibling::label"));
			for (int i = 0; i < checkbox.size(); i++) {
				
				if((checkbox.get(i).isDisplayed()==true))
				{
					MIQLog.info("All the PropertyType checkbox are Reset to their defaul values");
				}
				
				else {
					MIQLog.info("Failed to Check all the PropertyType checkbox are Reset to their defaul values");
					Assert.fail("Failed to Check all the PropertyType checkbox are Reset to their defaul values");
				}	
				
			}
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_FileTransfer_Dropdown, 5);
			String sDropdownValue = MIQActionsClass.GetSelectedValue(LoginObjects.transferReprot_FileTransfer_Dropdown);
			assertFalse(sDropdownValue.equals(sFileTransfer));
			MIQActionsClass.isElementNotVisible(LoginObjects.transferReprot_SpecifiedDateRange_From_DatePicker, "Date picker Fron text field");
			MIQActionsClass.isElementNotVisible(LoginObjects.transferReprot_SpecifiedDateRange_To_DatePicker, "Date picker To text field");
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_CurrentReportDescription_TextField, 5);
			String sCurrentReportDescritionValue=MIQActionsClass.getAttribute(LoginObjects.transferReprot_CurrentReportDescription_TextField, "value", "Current Report Description");
			Assert.assertNotEquals(sCurrentReportDescritionValue, sFileTransfer);
			if (!(MIQActionsClass.isCheckBoxChecked(LoginObjects.transferReport_CreateCurrentReport_Checkbox))) {
				
				MIQLog.info("Checkbox is unchecked");
			}
			else {
				MIQLog.info("Checkbox is checked");
				Assert.fail("Unable to verify the Unchecked checkbox");

			}
	} catch (Exception e) {
		e.printStackTrace();
		MIQExceptionHandle.HandleException(e, "Failed to check all fields should be reset to their default values");
	}
}
	
	@Then("^Check User navigated to \"([^\"]*)\" page$")
	public void checkUserNavigatedPage(String arg1) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsPage, 200);
			MIQActionsClass.isElementVisible(LoginObjects.transferReprot_ResultsPage, "Transfer Report Results page");	    
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to check User should be direced to the"+arg1+ " page");
		}
	   
	}
	
	@When("^User search for Street name in \"([^\"]*)\" \"([^\"]*)\" search field$")
	public void userSearchStretname(String sSearch, String arg2) throws Throwable {
		try {
			sStreetName=sSearch.toUpperCase();
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_StreetName_SearchField, 10);
			MIQActionsClass.typeInTextBox(LoginObjects.transferReprot_ResultsTable_StreetName_SearchField, sSearch, "Street Name");
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to enter values in "+arg2+ " search field");
		}
	}
	
	
	@Then("^Validate user enterd text filtering should function as expected for \"([^\"]*)\" search field$")
	public void validateUserEnterdText(String arg1) throws Throwable {
		String sOption = "";
		Thread.sleep(1000);
		try {
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//td[@aria-describedby='transfersResultTable_Street']"));
			for (int i = 0; i < getList.size(); i++) {
				sOption = getList.get(i).getText();
				Thread.sleep(1000);
				assertEquals(sOption, sStreetName);    
		} 
		}catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate user enterd text filtering");
		}
}
	
	@Then("^Select \"([^\"]*)\" from \"([^\"]*)\" dropdown$")
	public void selectDropdown(String sVisibletext, String sValue) throws Throwable {
		try {
			//sVisibletextValue=sVisibletext;
			if (sValue.equalsIgnoreCase("Suburbs")) {
				sSuburbValue=sVisibletext;
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_Suburb_Dropdown, 10);
			MIQActionsClass.selectByVisibleText(LoginObjects.transferReprot_ResultsTable_Suburb_Dropdown, sVisibletext);
			}
		else if (sValue.equalsIgnoreCase("Property Type")) {
			sPropertyTypeValue=sVisibletext;
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_PropertyType_Dropdown, 5);
			MIQActionsClass.selectByVisibleText(LoginObjects.transferReprot_ResultsTable_PropertyType_Dropdown, sVisibletext);
		
		}
	else if (sValue.equalsIgnoreCase("Official Description")) {
		sOfficialDescriptionValue=sVisibletext;
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_OfficilDescription_Dropdown, 5);
			MIQActionsClass.selectByVisibleText(LoginObjects.transferReprot_ResultsTable_OfficilDescription_Dropdown, sVisibletext);
		
		}
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to select "+sVisibletext+  " from" +sValue);
		}
	}

	@Then("^Validate Dynamic filtering list dropdown for \"([^\"]*)\" dropdown$")
	public void validateDynamicFilteringList(String arg1) throws Throwable {
		
		Thread.sleep(3000);
		String sOption = "";
		
		try {
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//td[@aria-describedby='transfersResultTable_Suburb']"));
			for (int i = 0; i < getList.size(); i++) {
				sOption = getList.get(i).getText();
				assertEquals(sOption, sSuburbValue);    
		} 
		}catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate Dynamic filtering list dropdown fo");
		}
	}

	@Then("^Validate all the list containing \"([^\"]*)\" in the Transfer Report Page Filter for \"([^\"]*)\" dropdown$")
	public void validateListForSuburbDropdown(String sValue, String arg2) throws Throwable {
		try {

			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_Suburb_Dropdown, 5);
			MIQActionsClass.clickOnElement(LoginObjects.transferReprot_ResultsTable_Suburb_Dropdown, "Suburb Dropdown");
			List<String> optionList = MIQActionsClass.selectGetAllOptions(LoginObjects.transferReprot_ResultsTable_Suburb_Dropdown, "Suburb Dropdown");
			System.out.println("optionList"+optionList);
			
			if (optionList.toString().contains(sValue)) {
				MIQLog.info("suburb dropdown contains " +sValue);
			} else {
				MIQLog.info("Failed to verify Suburb dropdown contains " +sValue);
				Assert.fail("Failed to verify suburb dropdown contains " +sValue);		
			}
		} catch (Exception e) {			
			MIQExceptionHandle.HandleException(e, "Failed to Validate all the list containing in Suburb dropdown contains ");
		}
	}
	

	@Then("^Check The filtering option \"([^\"]*)\" should be present in the \"([^\"]*)\" dropdown and it should be at the bottom of the list$")
	public void checkFilteringOption(String sValue, String arg2) throws Throwable {
		try {
			Select selectBox = new Select(MIQBase.driver.findElement(By.xpath("//select[@id='gs_Suburb']")));
		    int selectOptions = selectBox.getOptions().size();
		    selectBox.selectByIndex(selectOptions - 1);
		    MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_Suburb_Dropdown, 5);
			String Text = MIQActionsClass.GetSelectedValue(LoginObjects.transferReprot_ResultsTable_Suburb_Dropdown);
			assertEquals(Text, sValue);
	
	} catch (Exception e) {			
		MIQExceptionHandle.HandleException(e, "Failed to Validate all the list containing in Suburb dropdown contains ");
	}
}
	
	@Then("^Validate all the list containing \"([^\"]*)\" in the Transfer Report Page Filter for Property Type dropdown$")
	public void validateListForPropertyTypeDropdown(String sValue) throws Throwable {
		try {

			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_PropertyType_Dropdown, 5);
			MIQActionsClass.clickOnElement(LoginObjects.transferReprot_ResultsTable_PropertyType_Dropdown, "Suburb Dropdown");
			List<String> optionList = MIQActionsClass.selectGetAllOptions(LoginObjects.transferReprot_ResultsTable_PropertyType_Dropdown, "Suburb Dropdown");
			System.out.println("optionList"+optionList);
			
			if (optionList.toString().contains(sValue)) {
				MIQLog.info("suburb dropdown contains " +sValue);
			} else {
				MIQLog.info("Failed to verify Suburb dropdown contains " +sValue);
				Assert.fail("Failed to verify suburb dropdown contains " +sValue);		
			}
		} catch (Exception e) {			
			MIQExceptionHandle.HandleException(e, "Failed to Validate all the list containing in Suburb dropdown contains ");
		}
	}
	
	@Then("^Validate Dynamic filtering list dropdown \"([^\"]*)\" for Official description dropdown$")
	public void validateDynamicFilteringOfficalDescriptionDropdown(String sValue) throws Throwable {
		
		Thread.sleep(2000);
		String sOption = "";
		
		try {
			List<WebElement> getList = MIQActionsClass.getElements(By.xpath("//td[@aria-describedby='transfersResultTable_OfficialDescription']"));
			for (int i = 0; i < getList.size(); i++) {
				sOption = getList.get(i).getText();
				assertEquals(sOption, sValue);    
		} 
		}catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate Dynamic filtering list dropdown for Official description dropdown");
		}
	}
	
	@Then("^Validate all the list containing \"([^\"]*)\" in the Transfer Report Page Filter for Official description dropdown$")
	public void validateListForOfficialDescriptionDropdown(String sValue) throws Throwable {
		
		try {

			MIQActionsClass.waitForElement(LoginObjects.transferReprot_ResultsTable_OfficilDescription_Dropdown, 5);
			MIQActionsClass.clickOnElement(LoginObjects.transferReprot_ResultsTable_OfficilDescription_Dropdown, "Official Description");
			List<String> optionList = MIQActionsClass.selectGetAllOptions(LoginObjects.transferReprot_ResultsTable_OfficilDescription_Dropdown, "Official Description");

			
			if (optionList.toString().contains(sValue)) {
				MIQLog.info("suburb dropdown contains " +sValue);
			} else {
				MIQLog.info("Failed to verify Suburb dropdown contains " +sValue);
				Assert.fail("Failed to verify suburb dropdown contains " +sValue);		
			}
		} catch (Exception e) {		
			e.printStackTrace();
		
		}
	}
	@Then("^Check the Trasnfer report result grid summary section \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" fields are displayed$")
	public void checkTrasnferReportResultGridSummary(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12) throws Throwable {
		try {

			if (MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_OfficialDescription_Label, "Official Description")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_ErfPortion_Label," Erf Portion")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_Type_Label, " Summary Section")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_FarmNameORSchemeYear_Label, " FarmName/SchemeYear")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_StreetName_Label," Street Name")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_StreetAddress_Label," Street Address")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_Suburb_Label, " Suburb")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_TitleDeed_Label, " Title Deed")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_ExtentSQM_Label," Extent SQM")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_Price_Label,	" Price")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_PurchaseDate_Label, " Purchase Date")
					&& MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_RegistrationDate_Label," Registration Date"));
				
			
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Trasnfer report result grid summary section");
		}
	}
	@Then("^Check that at the bottom of the page there is a total number of records and page scrolling functionality$")
	public void checkTotalNumberRecordsPageScrollingFunctionality() throws Throwable {
		try {

			MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_TotalNumberofRecords_Label, "Total number of records");
					MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_Nextpage_Scroll,"Next page scroll");
					MIQActionsClass.isElementVisible(LoginObjects.transferReport_SummarySection_LastPage_Scroll," Last page scroll");
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to Check total number of records and page scrolling functionality");
		}
	}
	
	
	@Then("^Select \"([^\"]*)\"  from the  \"([^\"]*)\" field Dropdown$")
	public void select_from_the_field_Dropdown(String arg1, String arg2) throws Throwable {
	    
	}

	@Then("^Validate \"([^\"]*)\" should be selected for \"([^\"]*)\"$")
	public void validate_should_be_selected_for(String sValue, String arg2) throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SummarySection_Export_Dropdown, 5);
			String Text = MIQActionsClass.GetSelectedValue(LoginObjects.transferReprot_SummarySection_Export_Dropdown);
			assertEquals(Text, sValue);

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate"+sValue+" be selected");
		}
	}

	@Then("^Select any property form the Transfer report result page$")
	public void select_any_property_form_the_Transfer_report_result_page() throws Throwable {
		try {
			if(!(MIQActionsClass.isCheckBoxChecked(LoginObjects.transferReprot_SummarySection_Property_CheckBox))) {
				Thread.sleep(3000);
				MIQActionsClass.clickOnElement(LoginObjects.transferReprot_SummarySection_Property_CheckBox, "Property Checkbox");
			} 

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to Select any property form the Transfer report result page");
		}
	}

	@Then("^Verify \"([^\"]*)\" dowloaded by Clicking on \"([^\"]*)\" button to \"([^\"]*)\" page$")
	public void verify_dowloaded_by_Clicking_on_button_to_page(String sDoc, String sValue, String arg3) throws Throwable {
		try {
			if (sValue.equalsIgnoreCase("PDF")) {
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SummarySection_Export_PDF_Button, 5);			
				MIQActionsClass.clickOnElement(LoginObjects.transferReprot_SummarySection_Export_PDF_Button, "PDF Button");

				Thread.sleep(10000);
				docName = VerifyDownloadedFile.isFileDownloadedName(System.getProperty("user.home") + "//Downloads", sDoc);
				System.out.println(docName);
				Assert.assertFalse(docName.isEmpty());
				System.out.println("PDF report downlaoded");
			} else if(sValue.equalsIgnoreCase("CSV")) {
				MIQActionsClass.waitForElement(LoginObjects.transferReprot_SummarySection_Export_CSV_Button, 5);			
				MIQActionsClass.clickOnElement(LoginObjects.transferReprot_SummarySection_Export_CSV_Button, "PDF Button");
			}
		} catch (Exception e) {
			e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Failed to click on" +sValue);
		}
	}

	@Then("^Check filters set in the previous step should reflect in the downloaded files$")
	public void check_filters_set_in_the_previous_step_should_reflect_in_the_downloaded_files() throws Throwable {
		try {
			Thread.sleep(3000);
			String contentInPdf =MIQActionsClass.checkDataFromPDF(docName);
			String ActualText = contentInPdf.replace("\r\n", "");
			System.out.println("ActualText"+ActualText);
			Assert.assertTrue(ActualText.contains(sOfficialDescriptionValue.toUpperCase()));
			Assert.assertTrue(ActualText.contains(sPropertyTypeValue.toUpperCase()));
			//Assert.assertTrue(ActualText.contains(sStreetName.toUpperCase()));
			Assert.assertTrue(ActualText.contains(sSuburbValue.toUpperCase()));
			
			VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
		} catch (Exception e) {
			VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
            e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Content of pdf is not matched");
		}
	}
	@Then("^Verify the error bar's behaviour and it should disappear$")
	public void verifyErrorBarBehaviour() throws Throwable {
		try {
			MIQActionsClass.waitForElement(LoginObjects.transferReprot_SummarySection_Export_Dropdown, 5);
			MIQActionsClass.isElementVisible(LoginObjects.transferReprot_SummarySection_Export_CSV_ErrorMessage, "Error message appear");
			Thread.sleep(10000);
			MIQActionsClass.isElementNotVisible(LoginObjects.transferReprot_SummarySection_Export_CSV_ErrorMessageDisappear, "Error message disappear");

		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to verify the error bar's behaviour and it should disappear");
		} 
	}
	
	@Then("^Check notification table consists of \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void checknotificationtable(String sType, String sNewEntries, String sLastNotificationDate) throws Throwable {
	 try {
		 	MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_Type_Lable, 5);
		 	String Type=MIQActionsClass.getElementText(MIQ_PropertyListObjects.notifications_Type_Lable, "New Entries");
		 	String NewEntries=MIQActionsClass.getElementText(MIQ_PropertyListObjects.notifications_NewEntries_Label, "New Entries");
		 	String LastNotificationDate=MIQActionsClass.getElementText(MIQ_PropertyListObjects.notifications_LastNotificationDate_Label, "Last Notification Date");
		 	assertEquals(Type,sType);
		 	assertEquals(NewEntries,sNewEntries);
		 	assertEquals(LastNotificationDate,sLastNotificationDate);
		
	 }catch (Exception e) {
		 MIQExceptionHandle.HandleException(e, "Failed to check Notification table");
	 }
	}

	@Then("^Check User should be able to see \"([^\"]*)\" count should be visible for Transfer$")
	public void checkUserCountVisibleForTransfer(String sCount) throws Throwable {
	 
		try {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_TransferType_link, 5);
			String Count=MIQActionsClass.getElementText(MIQ_PropertyListObjects.notifications_TransferType_link, "Transfer Count");
			assertEquals(Count,sCount);
		} catch (Exception e) {
			 MIQExceptionHandle.HandleException(e, "Failed to check user should be able to see" +sCount+ " shouble be visbile for Transfer");
			
		}
	}
	@Then("^Click on \"([^\"]*)\" link at All notification page$")
	public void click_on_link_at_All_notification_page(String arg1) throws Throwable {
	   try {
		   MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_Transfer_Link, 5);
		   MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.notifications_Transfer_Link, "Transfer Link");
	   }catch (Exception e) {
			 MIQExceptionHandle.HandleException(e, "Failed to click on " +arg1+ "link at All notification page");
		 }
	}

	@Then("^Select any checkbox at Transfer result table$")
	public void select_any_checkbox_at_Transfer_result_table() throws Throwable {
	   
		try {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Checkbox, 5);
			sSelectedCheckbox=MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Checkbox,"Checkbox");
			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to validate");
			}
	}

	@Then("^Select Mulitple checkboxes at Tranfer result table$")
	public void selectMultipleCheckBox_table() throws Throwable {
	   
		try {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Checkbox, 5);
			sSelectedCheckbox1=	MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Checkbox,"");
			sSelectedCheckbox2=MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Second_Checkbox,"");
			
//				sTextFirstReport=MIQActionsClass.getElementText(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_FirstReport, "First Reprot");
//			sTextSecondReport=MIQActionsClass.getElementText(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_SecondReport, "Second Reprot");
////			
//		 sTextSelectedCheckbox1=	MIQActionsClass.breakLines(sTextFirstReport,20);
//			

			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to select multiple checkbox at Tranfer result table");
			}
	}
	
	@Given("^Get text from the first \"([^\"]*)\" checkbox and Second \"([^\"]*)\" checkbox at Tranfer result table$")
	public void get_text_from_the_first_checkbox_and_Second_checkbox_at_Tranfer_result_table(String sRecord, String sSecondRecord) throws Throwable {
		try {
			FirstRecordPDFOfficialDescriptionText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_OfficialDescription_Label), "First Official Description");
			String[] parts = FirstRecordPDFOfficialDescriptionText.split(" ");
			String part1 = parts[0]; 
			String part2 = parts[1];
		//	String part3 = parts[2];
			System.out.println(FirstRecordOfficialDescriptionText + part2 + "---------");
		//	System.out.println("part3"+part3);
			
			//FirstRecordOfficialDescriptionText= part1+" "+part2 + " ";
			
			FirstRecordOfficialDescriptionText= part1;
			
			 ErfPart  = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ErfPortion_Label), "Erf Portion");
			
			String[] Erf = ErfPart.split("/");
			FirstRecordErfPortionText = Erf[0]; // 004
			String ErfPart2 = Erf[1];
			
			FirstRecordPropertyTypeText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PropertyType_Label), "Property Type");
			FirstRecordStreetText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Street_Label), "Street Name");
			System.out.println("FirstRecordStreetText"+FirstRecordStreetText);
			FirstRecordStreetAddressText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_StreetAddress_Label), "Street Address");
			FirstRecordSuburbText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Suburb_Label), "Suburb");
			
			FirstRecordPDFCapitalSuburbText=FirstRecordSuburbText.toUpperCase();
			FirstRecordTitleDeedText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_TitleDeed_Label), "Title Deed");
			FirstRecordPDFExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Extent_Label), "Extent");
			FirstRecordExtentText=FirstRecordPDFExtentText+"."+"0000";
			FirstRecordPDFRemainingExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RemainingExtent_Label), "RemainingExtent");
			System.out.println("FirstRecordPDFRemainingExtentText"+FirstRecordPDFRemainingExtentText);
			
			FirstRecordRemainingExtentText=FirstRecordPDFRemainingExtentText.replaceAll("f","F");
			FirstRecordPDFRemainingExtentText=FirstRecordPDFRemainingExtentText.toUpperCase();
			
			FirstRecordPDFPriceText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Price_Label), "Price");
			System.out.println("FirstRecordPriceText"+FirstRecordPriceText);

			
			String[] PriceText = FirstRecordPDFPriceText.split(" ");
			String PriceText1  = PriceText[0]; // 004
			String PriceText2 = PriceText[1];
			String PriceText3 = PriceText[2];
			FirstRecordPriceText=PriceText1+PriceText2+PriceText3;

			System.out.println("FirstRecordPriceText"+FirstRecordPriceText);
			
			FirstRecordPriceText=FirstRecordPriceText.substring(0, FirstRecordPriceText.length() - 3);
	
			System.out.println("FirstRecordPriceText"+FirstRecordPriceText);
			
			
			FirstRecordPDFPurchaseDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PurchaseDate_Label), "Purchase Date");
			System.out.println("FirstRecordPurchaseDateText"+FirstRecordPDFPurchaseDateText);
			
//			2004/01/29;
//			01/29/2004;
//			2004-01-29;
			
//			String[] PurchaseDate = FirstRecordPDFPurchaseDateText.split("-");
//			String PurchaseDate1  = PurchaseDate[0]; 
//			String PurchaseDate2  = PurchaseDate[1]+" "; 
//			String PurchaseDate3  = PurchaseDate[2]+" ";
//			
//			String PurchaseDat=PurchaseDate2+PurchaseDate3+PurchaseDate1;
//			FirstRecordPurchaseDateText =PurchaseDat.replaceAll(" ","/");
//			System.out.println("FirstRecordPurchaseDateText"+FirstRecordPurchaseDateText);
			
			FirstRecordPDFRegistrationDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RegistrationDate_Label), "Registration Date");
			System.out.println("FirstRecordRegistrationDateText"+FirstRecordPDFRegistrationDateText);
			
			
//			String[] RegistrationDate = FirstRecordPDFRegistrationDateText.split("-");
//			String RegistrationDate1  = RegistrationDate[0]; 
//			String RegistrationDate2  = RegistrationDate[1]+" "; 
//			String RegistrationDate3  = RegistrationDate[2]+" ";
//			
//			//String RegistrationDat=RegistrationDate2+RegistrationDate3+RegistrationDate1;
//			String RegistrationDat=RegistrationDate2+RegistrationDate3+RegistrationDate1;
//			FirstRecordRegistrationDateText =RegistrationDat.replaceAll(" ","-");
//			System.out.println("FirstRecordRegistrationDateText"+FirstRecordRegistrationDateText);
			
			
			
			
			FirstRecordPDFCaptureDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_CaptureDate_Label), "CaptureDate");
			System.out.println("FirstRecordCaptureDateText"+FirstRecordPDFCaptureDateText);
			
//			String[] CaptureDate = FirstRecordPDFCaptureDateText.split("-");
//			String CaptureDate1  = CaptureDate[0]; 
//			String CaptureDate2  = CaptureDate[1]+" "; 
//			String CaptureDate3  = CaptureDate[2]+" ";
//			
//			String CaptureDat=CaptureDate2+CaptureDate3+CaptureDate1;
//			FirstRecordCaptureDateText =CaptureDat.replaceAll(" ","/");
//			System.out.println("FirstRecordCaptureDateText"+FirstRecordCaptureDateText);
			
			
			SecondRecordOfficialDescriptionText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_OfficialDescription_Label), "First Official Description");
//			System.out.println("SecondRecordOfficialDescription"+SecondRecordOfficialDescription);
//			String[] OfficialDescription = SecondRecordOfficialDescription.split(" ");
//			String OfficialDescription1 = OfficialDescription[0]; // 004
//			String OfficialDescription2 = OfficialDescription[1];
//			String OfficialDescription3= OfficialDescription[2];// 034556		
//			SecondRecordOfficialDescriptionText= OfficialDescription1+" "+OfficialDescription2 + " ";
//			System.out.println("SecondRecordOfficialDescriptionText"+SecondRecordOfficialDescriptionText);			
			 SecondErfPart = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ErfPortion_Label), "Erf Portion");			
			String[] SecondErf = SecondErfPart.split("/");
			SecondRecordErfPortionText = SecondErf[0]; // 004
			String SecondErfPart2 = SecondErf[1];
		
			
			SecondRecordPropertyTypeText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PropertyType_Label), "Property Type");
			SecondRecordStreetText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Street_Label), "Street Name");
			SecondRecordStreetAddressText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_StreetAddress_Label), "Street Address");
			SecondRecordSuburbText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Suburb_Label), "Suburb");
			System.out.println("SecondRecordSuburbText:"+SecondRecordSuburbText);
			SecondRecordPDFCapitalSuburbText=SecondRecordSuburbText.toUpperCase();
			SecondRecordTitleDeedText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_TitleDeed_Label), "Title Deed");
			SecondRecordPDFExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Extent_Label), "Extent");		
			SecondRecordExtentText=SecondRecordPDFExtentText+"."+"0000";		
			SecondRecordPDFRemainingExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RemainingExtent_Label), "RemainingExtent");			
			SecondRecordRemainingExtentText=SecondRecordPDFRemainingExtentText.replaceAll("f","F");
			SecondRecordPDFRemainingExtentText=SecondRecordPDFRemainingExtentText.toUpperCase();	
			SecondRecordPriceText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Price_Label), "Price");
			
			
			
//			String[] SecondPriceText = SecondRecordPriceText.split(" ");
//			String SecondPriceText1  = SecondPriceText[0]; // 004
//			String SecondPriceText2 = SecondPriceText[1];
//		//	String SecondPriceText3 = SecondPriceText[2];
//		//	SecondRecordPriceText=SecondPriceText1+SecondPriceText2+SecondPriceText3;
//			SecondRecordPriceText=SecondPriceText1+SecondPriceText2;

			System.out.println("SecondRecordPriceText"+SecondRecordPriceText);
			
			SecondRecordPriceText=SecondRecordPriceText.substring(0, SecondRecordPriceText.length() - 3);
	
			SecondRecordPurchaseDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PurchaseDate_Label), "Purchase Date");
			System.out.println("SecondRecordPurchaseDateText" +SecondRecordPurchaseDateText);
//			
//			String[] SecondPurchaseDate = SecondRecordPurchaseDateText.split("-");
//			String SecondPurchaseDate1  = SecondPurchaseDate[0]; 
//			String SecondPurchaseDate2  = SecondPurchaseDate[1]+" "; 
//			String SecondPurchaseDate3  = SecondPurchaseDate[2]+" ";
//			
//			String SecondPurchaseDat=SecondPurchaseDate2+SecondPurchaseDate3+SecondPurchaseDate1;
//			SecondRecordPurchaseDateText =SecondPurchaseDat.replaceAll(" ","/");
//			System.out.println("SecondRecordPurchaseDateText"+SecondRecordPurchaseDateText);
			
			
			SecondRecordRegistrationDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RegistrationDate_Label), "Registration Date");
			System.out.println("SecondRecordRegistrationDateText" +SecondRecordRegistrationDateText);
//			String[] SecondRegistrationDate = SecondRecordRegistrationDateText.split("-");
//			String SecondRegistrationDate1  = SecondRegistrationDate[0]; 
//			String SecondRegistrationDate2  = SecondRegistrationDate[1]+" "; 
//			String SecondRegistrationDate3  = SecondRegistrationDate[2]+" ";
//			
//			String SecondRegistrationDat=SecondRegistrationDate2+SecondRegistrationDate3+SecondRegistrationDate1;
//			SecondRecordRegistrationDateText =SecondRegistrationDat.replaceAll(" ","/");
//			System.out.println("SecondRecordRegistrationDateText"+SecondRecordRegistrationDateText);
		
			SecondRecordCaptureDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_CaptureDate_Label), "CaptureDate");
			System.out.println("SecondRecordCaptureDateText" +SecondRecordCaptureDateText);
//			String[] SecondCaptureDate = SecondRecordCaptureDateText.split("-");
//			String SecondCaptureDate1  = SecondCaptureDate[0]; 
//			String SecondCaptureDate2  = SecondCaptureDate[1]+" "; 
//			String SecondCaptureDate3  = SecondCaptureDate[2]+" ";
//			
//			String SecondCaptureDat=SecondCaptureDate2+SecondCaptureDate3+SecondCaptureDate1;
//			SecondRecordCaptureDateText =SecondCaptureDat.replaceAll(" ","/");
//			System.out.println("SecondRecordCaptureDateText"+SecondRecordCaptureDateText);
			
			
				
			} catch (Exception e) {
				e.printStackTrace();
				MIQExceptionHandle.HandleException(e, "Failed to select multiple checkbox at Tranfer result table");
			}
	}

	@Then("^Click on \"([^\"]*)\" button at All notifications page$")
	public void click_on_button(String arg1) throws Throwable {
		 try {
			   MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_Transfer_UpdateNotificationDate_Button, 5);
			   MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.notifications_Transfer_UpdateNotificationDate_Button, "Transfer Link");
		   }catch (Exception e) {
				 MIQExceptionHandle.HandleException(e, "Failed to click on " +arg1+ "link at All notification page");
			 }
	}
	
	@Then("^Validate multiple checkbox are checked$")
	public void validateMultipleCheckedCheckbox() throws Throwable {
		try {
			
		assertEquals(sSelectedCheckbox1,true);
		assertEquals(sSelectedCheckbox2,true);
		} catch (Exception e) {
			MIQExceptionHandle.HandleException(e, "Failed to validate multiple checkboxes");
		}
	}
	
	
	
	@Then("^Check the Only the selected transfer records should be should reflect in the downloaded files$")
	public void check_the_Only_the_selected_transfer_records_should_be_should_reflect_in_the_downloaded_files() throws Throwable {

        try {
        	
			List<String> CSVData=MIQActionsClass.readCSVAllDataAtOnceWithOutHeader(MIQ_PropertyList.CSV_FILE_PATH); 
			System.out.println(CSVData); 
			Thread.sleep(3000);
			//Assert.assertTrue(CSVData.contains(FirstRecordOfficialDescriptionText));
			Assert.assertTrue(CSVData.contains(FirstRecordErfPortionText));
			Assert.assertTrue(CSVData.contains(FirstRecordPropertyTypeText));
			//Assert.assertTrue(CSVData.contains(FirstRecordStreetText));
			//Assert.assertTrue(CSVData.contains(FirstRecordStreetAddressText));
			Assert.assertTrue(CSVData.contains(FirstRecordSuburbText));
			Assert.assertTrue(CSVData.contains(FirstRecordTitleDeedText));
			Assert.assertTrue(CSVData.contains(FirstRecordExtentText));
			Assert.assertTrue(CSVData.contains(FirstRecordRemainingExtentText));
			Assert.assertTrue(CSVData.contains(FirstRecordPriceText));
			Assert.assertTrue(CSVData.contains(FirstRecordPDFRegistrationDateText));
			Assert.assertTrue(CSVData.contains(FirstRecordPDFPurchaseDateText));
			Assert.assertTrue(CSVData.contains(FirstRecordPDFCaptureDateText));
			
			
		//Assert.assertTrue(CSVData.contains(SecondRecordOfficialDescriptionText));
			Assert.assertTrue(CSVData.contains(SecondRecordErfPortionText));
			Assert.assertTrue(CSVData.contains(SecondRecordPropertyTypeText));
			//Assert.assertTrue(CSVData.contains(SecondRecordStreetText));
			//Assert.assertTrue(CSVData.contains(SecondRecordStreetAddressText));
			//Assert.assertTrue(CSVData.contains(SecondRecordSuburbText));
			Assert.assertTrue(CSVData.contains(SecondRecordTitleDeedText));
			Assert.assertTrue(CSVData.contains(SecondRecordExtentText));
			Assert.assertTrue(CSVData.contains(SecondRecordRemainingExtentText));
			Assert.assertTrue(CSVData.contains(SecondRecordPriceText));
			Assert.assertTrue(CSVData.contains(SecondRecordPurchaseDateText));
			Assert.assertTrue(CSVData.contains(SecondRecordRegistrationDateText));
			Assert.assertTrue(CSVData.contains(SecondRecordCaptureDateText));
			
		
		} catch (Exception e) {
		
            e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Content of pdf is not matched");
		}
		}
	@Then("^Select all checkboxes at Transfer result table$")
	public void selectAllCheckBoxTable() throws Throwable {
	   
		try {
			MIQActionsClass.waitForElement(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Checkbox, 25);
				MIQActionsClass.clickOnElement(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_SelectAll_Checkbox,"");
		

			} catch (Exception e) {
				MIQExceptionHandle.HandleException(e, "Failed to select multiple checkbox at Tranfer result table");
			}
	}
	
	@Then("^Get text from the first \"([^\"]*)\" checkbox and Second \"([^\"]*)\" checkbox at \"([^\"]*)\" result table$")
	public void get_text_from_the_first_checkbox_and_Second_checkbox_at_result_table(String sRecord, String sSecondRecord, String arg3) throws Throwable {
		try {
			ThirdRecordPDFOfficialDescriptionText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_OfficialDescription_Label), "First Official Description");
			String[] parts = ThirdRecordPDFOfficialDescriptionText.split(" ");
			String part1 = parts[0]; 
			String part2 = parts[1];
			//String part3 = parts[2];
			
			
			//ThirdRecordOfficialDescriptionText= part1+" "+part2 + " ";
			ThirdRecordOfficialDescriptionText= part1+ " ";
			 ThirdRecordErfPart  = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ErfPortion_Label), "Erf Portion");
			
			String[] Erf = ThirdRecordErfPart.split("/");
			ThirdRecordErfPortionText = Erf[0]; // 004
			String ErfPart2 = Erf[1];
			
			ThirdRecordPropertyTypeText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PropertyType_Label), "Property Type");
			ThirdRecordStreetText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Street_Label), "Street Name");
			ThirdRecordStreetAddressText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_StreetAddress_Label), "Street Address");
			ThirdRecordSuburbText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Suburb_Label), "Suburb");
			ThirdRecordCapitalPDFSuburbText=ThirdRecordSuburbText.toUpperCase();
			ThirdRecordTitleDeedText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_TitleDeed_Label), "Title Deed");
			ThirdRecordPDFExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Extent_Label), "Extent");
			ThirdRecordExtentText=ThirdRecordPDFExtentText+"."+"000";
			System.out.println("ThirdRecordPDFExtentText" +ThirdRecordPDFExtentText);
			System.out.println("ThirdRecordExtentText"+ThirdRecordExtentText);
			ThirdRecordPDFRemainingExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RemainingExtent_Label), "RemainingExtent");
			
			
			ThirdRecordRemainingExtentText=ThirdRecordPDFRemainingExtentText.replaceAll("f","F");
			ThirdRecordPDFRemainingExtentText=ThirdRecordPDFRemainingExtentText.toUpperCase();
			
			ThirdRecordPDFPriceText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Price_Label), "Price");
			System.out.println("ThirdRecordPDFPriceText"+ThirdRecordPDFPriceText);

			
//			String[] PriceText = ThirdRecordPDFPriceText.split(" ");
//			String PriceText1  = PriceText[0]; // 004
//			String PriceText2 = PriceText[1];
//			//String PriceText3=PriceText[2];
//			//ThirdRecordPriceText=PriceText1+PriceText2+PriceText3;
//			ThirdRecordPriceText=PriceText1+PriceText2;

			
			
			ThirdRecordPriceText=ThirdRecordPDFPriceText.substring(0, ThirdRecordPDFPriceText.length() - 3);
			System.out.println("ThirdRecordPriceText"+ThirdRecordPriceText);
			
			ThirdRecordPDFPurchaseDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PurchaseDate_Label), "Purchase Date");
			
			
//			String[] PurchaseDate = ThirdRecordPDFPurchaseDateText.split("-");
//			String PurchaseDate1  = PurchaseDate[0]; 
//			String PurchaseDate2  = PurchaseDate[1]+" "; 
//			String PurchaseDate3  = PurchaseDate[2]+" ";
//			
//			String PurchaseDat=PurchaseDate2+PurchaseDate3+PurchaseDate1;
//			ThirdRecordPurchaseDateText =PurchaseDat.replaceAll(" ","/");
			
			ThirdRecordPDFRegistrationDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RegistrationDate_Label), "Registration Date");
			
			
//			
//			String[] RegistrationDate = ThirdRecordPDFRegistrationDateText.split("-");
//			String RegistrationDate1  = RegistrationDate[0]; 
//			String RegistrationDate2  = RegistrationDate[1]+" "; 
//			String RegistrationDate3  = RegistrationDate[2]+" ";
//			
//			String RegistrationDat=RegistrationDate2+RegistrationDate3+RegistrationDate1;
//			ThirdRecordRegistrationDateText =RegistrationDat.replaceAll(" ","/");
			
			
			ThirdRecordPDFCaptureDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_CaptureDate_Label), "CaptureDate");
			
			
//			String[] CaptureDate = ThirdRecordPDFCaptureDateText.split("-");
//			String CaptureDate1  = CaptureDate[0]; 
//			String CaptureDate2  = CaptureDate[1]+" "; 
//			String CaptureDate3  = CaptureDate[2]+" ";
//			
//			String CaptureDat=CaptureDate2+CaptureDate3+CaptureDate1;
//			ThirdRecordCaptureDateText =CaptureDat.replaceAll(" ","/");
			
			
			
			FourthRecordOfficialDescriptionText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_OfficialDescription_Label), "First Official Description");
//			System.out.println("SecondRecordOfficialDescription"+SecondRecordOfficialDescription);
//			String[] OfficialDescription = SecondRecordOfficialDescription.split(" ");
//			String OfficialDescription1 = OfficialDescription[0]; // 004
//			String OfficialDescription2 = OfficialDescription[1];
//			String OfficialDescription3= OfficialDescription[2];// 034556		
//			SecondRecordOfficialDescriptionText= OfficialDescription1+" "+OfficialDescription2 + " ";
//			System.out.println("SecondRecordOfficialDescriptionText"+SecondRecordOfficialDescriptionText);			
			FourthRecordErfPart = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ErfPortion_Label), "Erf Portion");			
			String[] SecondErf = FourthRecordErfPart.split("/");
			FourthRecordErfPortionText = SecondErf[0]; // 004
			String SecondErfPart2 = SecondErf[1];
		
			
			FourthRecordPropertyTypeText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PropertyType_Label), "Property Type");
			FourthRecordStreetText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Street_Label), "Street Name");
			FourthRecordStreetAddressText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_StreetAddress_Label), "Street Address");
			FourthRecordSuburbText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Suburb_Label), "Suburb");
			FourthRecordTitleDeedText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_TitleDeed_Label), "Title Deed");
			FourthRecordPDFExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Extent_Label), "Extent");		
			FourthRecordExtentText=FourthRecordPDFExtentText+"."+"000";		
			FourthRecordPDFRemainingExtentText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RemainingExtent_Label), "RemainingExtent");			
			FourthRecordRemainingExtentText=FourthRecordPDFRemainingExtentText.replaceAll("f","F");
			FourthRecordPDFRemainingExtentText=FourthRecordPDFRemainingExtentText.toUpperCase();	
			FourthRecordPriceText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_Price_Label), "Price");
			
			
//			
//			String[] SecondPriceText = FourthRecordPriceText.split(" ");
//			String SecondPriceText1  = SecondPriceText[0]; // 004
//			String SecondPriceText2 = SecondPriceText[1];
//			//String SecondPriceText3 = SecondPriceText[2];
//			//FourthRecordPriceText=SecondPriceText1+SecondPriceText2+SecondPriceText3;
//			FourthRecordPriceText=SecondPriceText1+SecondPriceText2;
//
//			System.out.println("SecondRecordPriceText"+SecondRecordPriceText);
//			
			FourthRecordPriceText=FourthRecordPriceText.substring(0, FourthRecordPriceText.length() - 3);
	
			FourthRecordPurchaseDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_PurchaseDate_Label), "Purchase Date");
			
			
			String[] SecondPurchaseDate = FourthRecordPurchaseDateText.split("-");
//			String SecondPurchaseDate1  = SecondPurchaseDate[0]; 
//			String SecondPurchaseDate2  = SecondPurchaseDate[1]+" "; 
//			String SecondPurchaseDate3  = SecondPurchaseDate[2]+" ";
//			
//			String SecondPurchaseDat=SecondPurchaseDate2+SecondPurchaseDate3+SecondPurchaseDate1;
//			FourthRecordPurchaseDateText =SecondPurchaseDat.replaceAll(" ","/");
//			
			
			
			FourthRecordRegistrationDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_RegistrationDate_Label), "Registration Date");
			
//			String[] SecondRegistrationDate = FourthRecordRegistrationDateText.split("-");
//			String SecondRegistrationDate1  = SecondRegistrationDate[0]; 
//			String SecondRegistrationDate2  = SecondRegistrationDate[1]+" "; 
//			String SecondRegistrationDate3  = SecondRegistrationDate[2]+" ";
//			
//			String SecondRegistrationDat=SecondRegistrationDate2+SecondRegistrationDate3+SecondRegistrationDate1;
//			FourthRecordRegistrationDateText =SecondRegistrationDat.replaceAll(" ","/");
			
		
			FourthRecordCaptureDateText = MIQActionsClass.getElementText(By.xpath(MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_ConstantLabel+sSecondRecord+MIQ_PropertyListObjects.notifications_Transfer_TransfersResultTable_Report_CaptureDate_Label), "CaptureDate");

//			String[] SecondCaptureDate = FourthRecordCaptureDateText.split("-");
//			String SecondCaptureDate1  = SecondCaptureDate[0]; 
//			String SecondCaptureDate2  = SecondCaptureDate[1]+" "; 
//			String SecondCaptureDate3  = SecondCaptureDate[2]+" ";
//			
//			String SecondCaptureDat=SecondCaptureDate2+SecondCaptureDate3+SecondCaptureDate1;
//			FourthRecordCaptureDateText =SecondCaptureDat.replaceAll(" ","/");
//			
			
			
	
			} catch (Exception e) {
				e.printStackTrace();
				MIQExceptionHandle.HandleException(e, "Failed to select multiple checkbox at Tranfer result table");
			}
	}
	
	@Then("^Check the all the selected records should be should reflect in the downloaded files$")
	public void check_the_Only_the_selected_transfer_records_() throws Throwable {

        try {
        	
			List<String> CSVData=MIQActionsClass.readCSVAllDataAtOnceWithOutHeader(MIQ_PropertyList.CSV_FILE_PATH); 
			System.out.println(CSVData); 
			Thread.sleep(3000);
			///Assert.assertTrue(CSVData.contains(FirstRecordOfficialDescriptionText));
			Assert.assertTrue(CSVData.contains(ThirdRecordErfPortionText));
			Assert.assertTrue(CSVData.contains(ThirdRecordPropertyTypeText));
		//	Assert.assertTrue(CSVData.contains(FirstRecordStreetText));
		//	Assert.assertTrue(CSVData.contains(ThirdRecordStreetAddressText));
			Assert.assertTrue(CSVData.contains(ThirdRecordSuburbText));
			Assert.assertTrue(CSVData.contains(ThirdRecordTitleDeedText));
			Assert.assertTrue(CSVData.contains(ThirdRecordExtentText));
			Assert.assertTrue(CSVData.contains(ThirdRecordRemainingExtentText));
			Assert.assertTrue(CSVData.contains(ThirdRecordPriceText));
			Assert.assertTrue(CSVData.contains(ThirdRecordPDFRegistrationDateText));
			Assert.assertTrue(CSVData.contains(ThirdRecordPDFPurchaseDateText));
			Assert.assertTrue(CSVData.contains(ThirdRecordPDFCaptureDateText));
			
			
		//Assert.assertTrue(CSVData.contains(SecondRecordOfficialDescriptionText));
			Assert.assertTrue(CSVData.contains(FourthRecordErfPortionText));
			Assert.assertTrue(CSVData.contains(FourthRecordPropertyTypeText));
		//	Assert.assertTrue(CSVData.contains(SecondRecordStreetText));
		//	Assert.assertTrue(CSVData.contains(FourthRecordStreetAddressText));
			Assert.assertTrue(CSVData.contains(FourthRecordSuburbText));
			Assert.assertTrue(CSVData.contains(FourthRecordTitleDeedText));
			Assert.assertTrue(CSVData.contains(FourthRecordExtentText));
			Assert.assertTrue(CSVData.contains(FourthRecordRemainingExtentText));
			Assert.assertTrue(CSVData.contains(FourthRecordPriceText));
			Assert.assertTrue(CSVData.contains(FourthRecordPurchaseDateText));
			Assert.assertTrue(CSVData.contains(FourthRecordRegistrationDateText));
			Assert.assertTrue(CSVData.contains(FourthRecordCaptureDateText));
			
			VerifyDownloadedFile.deleteLatestReportfromDir(System.getProperty("user.home") + "//Downloads");

			
			VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
		} catch (Exception e) {
			VerifyDownloadedFile.deleteLatestFilefromDir(System.getProperty("user.home") + "//Downloads");
			VerifyDownloadedFile.deleteLatestReportfromDir(System.getProperty("user.home") + "//Downloads");
            e.printStackTrace();
			MIQExceptionHandle.HandleException(e, "Content of pdf is not matched");
		}
		}
	}
	



